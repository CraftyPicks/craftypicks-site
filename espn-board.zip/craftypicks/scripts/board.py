#!/usr/bin/env python3
"""Price every game on the board, not only the ones worth betting."""
from __future__ import annotations

import statistics
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import config    # noqa: E402
import fair      # noqa: E402
import form_store # noqa: E402
import leagues   # noqa: E402
import odds_math as om  # noqa: E402
import rate_mlb  # noqa: E402
import ratings   # noqa: E402

# Which outcome is side "a" for each market:
#   h2h/spreads — a is the home team, b is the away team
#   totals      — a is the over, b is the under
# Side A is NOT the home team everywhere: on a total it is the over, and the
# fair_home/fair_away keys below are named for the h2h/spreads case only.
# Every market entry therefore carries an explicit "side_a" so a consumer can
# read the orientation off the data instead of guessing from the key names.
SIDE_A = {"h2h": "home", "spreads": "home", "totals": "over"}

# The play-picker's book floor is a betting gate. A visitor-facing board
# cannot inherit the six-book floor or half the slate would vanish, but it
# cannot go below three either: each side's consensus excludes the book
# holding that side's best price, so two quotes leave a one-book "consensus"
# on a card that still says "2 books". Three is the smallest floor that puts
# at least two books behind every benchmark.
BOARD_MIN_BOOKS = 3


def _outcomes(game: dict, book: dict, market: str) -> list[dict] | None:
    for m in book.get("markets") or []:
        if m.get("key") == market:
            return m.get("outcomes") or []
    return None


def _modal_point(points: list[float]) -> float:
    """The line most books hang, chosen the same way on every run.

    Counter.most_common breaks a tie by insertion order, which here is the
    API's bookmaker order — so four books at 8.5/9.5/9.5/8.5 returned 8.5 or
    9.5 depending on how the feed happened to be sorted, and the whole board
    flipped between runs. A 2-2 tie on totals is common. Ties go to the line
    closest to the median of every quoted point, and to the lower point if
    that is still tied.
    """
    counts = Counter(points)
    top = max(counts.values())
    tied = [p for p in counts if counts[p] == top]
    if len(tied) == 1:
        return tied[0]
    median = statistics.median(points)
    return min(tied, key=lambda p: (abs(p - median), p))


def _points_agree(market: str, a_point, b_point) -> bool:
    """Do the two sides of this book's quote describe the same line?"""
    if a_point is None or b_point is None:
        return False
    if market == "totals":
        return b_point == a_point
    return b_point == -a_point


def quotes_for(game: dict, market: str) -> tuple[list[dict], float | None]:
    """One market projected into fair.py's flat quote shape.

    For spreads and totals the books do not all hang the same number, so the
    modal line is chosen and only the books quoting it are returned. Devigging
    a -1.5 against a -2.5 produces a fair price for a market nobody offers,
    which is worse than no price at all.

    Deliberately does not fall back to a nearby line when a book is off the
    modal number. A book quoting a different line is evidence about a
    different market; borrowing it would quietly widen the sample with the
    wrong data.
    """
    home, away = game.get("home_team"), game.get("away_team")
    if market == "totals":
        want_a, want_b = "over", "under"
    else:
        if not home or not away:
            return [], None
        want_a, want_b = home, away

    raw = []
    for book in game.get("bookmakers") or []:
        outcomes = _outcomes(game, book, market)
        if not outcomes:
            continue
        by_name = {}
        duplicate = False
        for o in outcomes:
            name = (o.get("name") or "")
            key = name.lower() if market == "totals" else name
            if key in by_name:
                # The same outcome name twice means this payload carries
                # alternate lines. An alternate line is a different market,
                # and keeping the last pair silently discards the book's
                # honest main line — enough to swing the modal line and drop
                # the market entirely. Skip the book instead.
                duplicate = True
                break
            by_name[key] = o
        if duplicate:
            continue
        # A market that is not two-way is not this market. A three-outcome
        # h2h (a draw league) devigged as if the two remaining sides summed
        # to the book's margin fabricates an edge out of the side that was
        # dropped; the reviewer's probe produced +34.7% that way.
        if len(by_name) != 2:
            continue
        a = by_name.get(want_a.lower() if market == "totals" else want_a)
        b = by_name.get(want_b.lower() if market == "totals" else want_b)
        if not a or not b:
            continue
        if a.get("price") is None or b.get("price") is None:
            continue
        if market != "h2h" and not _points_agree(market, a.get("point"),
                                                 b.get("point")):
            # A book quoting home -1.5 / away +2.5 is quoting two different
            # markets. Mixing it into the -1.5 group would devig it against
            # books that are not offering what it is offering, which is
            # exactly what this function promises never to do.
            continue
        raw.append({
            "book": book.get("title") or book.get("key") or "",
            "price_a": int(a["price"]),
            "price_b": int(b["price"]),
            "point": a.get("point"),
        })

    if market == "h2h":
        return [{k: q[k] for k in ("book", "price_a", "price_b")}
                for q in raw], None

    points = [q["point"] for q in raw if q["point"] is not None]
    if not points:
        return [], None
    modal = _modal_point(points)
    kept = [{k: q[k] for k in ("book", "price_a", "price_b")}
            for q in raw if q["point"] == modal]
    return kept, modal


def _price_market(quotes: list[dict]) -> dict | None:
    """fair.price_market with the board's own book floor.

    Does not change config.MIN_BOOKS for the rest of the process. The daily
    job imports both find_plays and board; leaking a lower floor into the
    play picker would put thin markets on the card.
    """
    saved = config.MIN_BOOKS
    config.MIN_BOOKS = BOARD_MIN_BOOKS
    try:
        return fair.price_market(quotes)
    finally:
        config.MIN_BOOKS = saved


def price_game(game: dict, short: str) -> dict | None:
    """Every market of one game, priced, or None if nothing could be priced.

    A game reaches the board only if at least one market cleared
    BOARD_MIN_BOOKS. Showing a game with no number on it invites the reader
    to supply their own, which is the opposite of what this page is for.

    Does not rate the game. The model's win probability is merged in later by
    whatever knows that league's ratings; this function only reads the market.
    """
    # A game missing either team name cannot be labelled. h2h and spreads
    # bail on their own, but totals would still price and emit a row with
    # "home": null, which every consumer downstream has to special-case.
    if not game.get("home_team") or not game.get("away_team"):
        return None

    markets: dict[str, dict] = {}
    for market in config.MARKETS:
        quotes, point = quotes_for(game, market)
        priced = _price_market(quotes)
        if not priced:
            continue
        entry = {
            "point": point,
            # Which outcome fair_a/best_a/edge_a were reported for. "home"
            # for h2h and spreads, "over" for totals — the *_home/*_away key
            # names below are the h2h/spreads reading of side A and side B.
            "side_a": SIDE_A[market],
            "fair_home": priced["fair_a"],
            "fair_away": priced["fair_b"],
            "fair_price_home": priced["fair_price_a"],
            "fair_price_away": priced["fair_price_b"],
            "best_home": priced["best_a"],
            "best_away": priced["best_b"],
            "edge_home": priced["edge_a"],
            "edge_away": priced["edge_b"],
            # Books hanging this line, not the consensus-after-exclusion
            # count fair.py reports. The card says "{n} books".
            "books": len(quotes),
            "width": priced["width"],
        }
        if market == "totals":
            # There is no scoring model. Elo gives a win probability, not a
            # run distribution, so this stays None until one exists and is
            # validated. See the spec: the row reads "market only".
            entry["model"] = None
        markets[market] = entry

    if not markets:
        return None

    return {
        "event_id": game.get("id"),
        "league": short,
        "commence_time": game.get("commence_time"),
        "home": game.get("home_team"),
        "away": game.get("away_team"),
        "markets": markets,
        "model": None,
    }


def build(games: list[dict], short: str) -> list[dict]:
    """Every priceable game in one league, in start-time order.

    Does not filter by edge, price or book count beyond what pricing itself
    requires. This is a board: a game the site would never bet is exactly as
    interesting as one it would, and leaving it out is how a tipster site
    hides its misses.

    One malformed game does not take the league with it. run_daily.py wraps
    the whole build() call in a single try/except, so before this guard a
    price of 0, a string where an outcome dict belongs, or a non-numeric
    price dropped all fifteen games and the 9am job committed the truncated
    file with nothing visibly wrong. The failure is logged to stderr with the
    event id rather than swallowed: an unattended job that hides its own data
    loss is the thing this guard exists to prevent.
    """
    rows = []
    for game in games:
        try:
            row = price_game(game, short)
        except Exception as e:                              # noqa: BLE001
            print(f"!! board: skipped {short} game "
                  f"{game.get('id') if isinstance(game, dict) else game!r}: "
                  f"{type(e).__name__}: {e}", file=sys.stderr)
            continue
        if row:
            rows.append(row)
    rows.sort(key=lambda r: (r.get("commence_time") or "", r.get("home") or ""))
    return rows


def document(boards: dict[str, list[dict]], generated_at: str,
             date: str) -> dict:
    """The whole board as one JSON-serialisable document.

    Leagues with no games are omitted rather than written empty, so a page can
    ask whether a league is on tonight by asking whether it is present.

    Does not embed the ratings or the schedule for leagues that are out of
    season; an absent league means no games today, not an error.
    """
    out = {}
    for short in leagues.ORDER:
        rows = boards.get(short) or []
        if not rows:
            continue
        out[short] = {"label": leagues.LEAGUES[short].label, "games": rows}
    return {
        "generated_at": generated_at,
        "date": date,
        "leagues": out,
        "counts": {short: len(v["games"]) for short, v in out.items()},
    }


def keep_started(boards: dict[str, list[dict]], old_doc: dict | None,
                 date: str, now) -> int:
    """Carry over games from the board already published for `date` that
    have started and are missing from this fetch. The odds feed drops a
    game once it is under way, so a late re-run (10:30 PM on Nov 10)
    replaced 62 college games with one NBA game. Fresh rows win; an
    unstarted game the feed no longer lists is dropped. Returns rows kept."""
    from datetime import datetime  # noqa: PLC0415
    if not old_doc or old_doc.get("date") != date:
        return 0
    n = 0
    for short, league in (old_doc.get("leagues") or {}).items():
        have = {r.get("event_id") for r in boards.get(short) or []}
        for row in league.get("games") or []:
            try:
                tip = datetime.fromisoformat(str(row.get("commence_time")).replace("Z", "+00:00"))
            except ValueError:
                continue
            if tip <= now and row.get("event_id") not in have:
                boards.setdefault(short, []).append(row)
                n += 1
        if boards.get(short):
            boards[short].sort(key=lambda r: r.get("commence_time") or "")
    return n


def _book(key: str, title: str, h2h: tuple[int, int],
          spread: tuple[int, int, float] | None = None,
          total: tuple[int, int, float] | None = None,
          home: str = "Milwaukee Brewers",
          away: str = "Chicago Cubs") -> dict:
    """One bookmaker payload, for the fixtures below."""
    markets = [{"key": "h2h", "outcomes": [
        {"name": home, "price": h2h[0]}, {"name": away, "price": h2h[1]}]}]
    if spread:
        markets.append({"key": "spreads", "outcomes": [
            {"name": home, "price": spread[0], "point": spread[2]},
            {"name": away, "price": spread[1], "point": -spread[2]}]})
    if total:
        markets.append({"key": "totals", "outcomes": [
            {"name": "Over", "price": total[0], "point": total[2]},
            {"name": "Under", "price": total[1], "point": total[2]}]})
    return {"key": key, "title": title, "markets": markets}


# The sport-specific extras a card may show beneath a club's name. Kept apart
# from `model` on purpose: every league has a win probability, only baseball
# has a starting pitcher, and mixing them would make the general path carry
# baseball's vocabulary into leagues that have no use for it.
DETAIL_KEYS = (
    "home_record", "away_record",
    "home_form", "away_form",
    "series",
    "home_starter", "away_starter",
    "home_starter_era", "away_starter_era",
    "home_starter_wl", "away_starter_wl",
    "home_hand", "away_hand",
    "home_vs_opp", "away_vs_opp",
    # slate.py has written these since the starter adjustment was added, and
    # render has had a table to draw them in for as long -- but they were not
    # on this list, so merge_model never copied them onto a board row and the
    # comparison has never once appeared on the site. Everything else in the
    # chain was already built.
    "home_sp", "away_sp",
    # The same omission, found the same way and costing more: slate.py has
    # fetched every hitter's career line against the opposing starter -- one
    # request per hitter, every morning -- and render has had a table for it,
    # and it has never reached a board card either. Paid for daily, displayed
    # never.
    "home_bats", "away_bats",
    "venue",
)


def merge_model(rows: list[dict], rated: list[dict], source: str) -> int:
    """Attach a rating to each board row that has one, by event id.

    Returns the number of rows matched. A rated game missing from the board is
    ignored rather than appended — the board is the list of games we could
    price, and a game with no price has nothing to compare a number against.

    Deliberately does not invent a rating for an unmatched row. A card with no
    percentage is honest; a card showing the market's number in our colour, or
    a neighbour's number, is not.

    market_home_prob comes from the rating when the rating supplies one — the
    slate devigs its own book set and that number wins. When it does not (the
    Elo path knows nothing about prices) it is filled from the row's own h2h
    fair price, which is already on the row. Without it the card draws a bare
    fill with no tick and no footer, and the comparison between the two
    numbers is the entire point of the card.
    """
    by_id = {}
    for r in rated:
        eid = r.get("event_id")
        if eid:
            by_id[eid] = r

    matched = 0
    for row in rows:
        rating = by_id.get(row.get("event_id"))
        if not rating:
            continue

        hp, ap = rating.get("home_win_prob"), rating.get("away_win_prob")
        if hp is None or ap is None:
            continue
        # A pair that does not sum to 1 means something upstream went wrong.
        # Better to show no number than a number we cannot explain. Logged,
        # not merely skipped: this gate is the only thing standing between a
        # genuine upstream bug and a board that is quietly one card short.
        if abs(hp + ap - 1.0) > 1e-6:
            print(f"!! {source} rating for {row.get('event_id')} does not sum "
                  f"to 1 ({hp} + {ap}); no number on that card",
                  file=sys.stderr)
            continue

        market = rating.get("market_home_prob")
        if market is None:
            market = ((row.get("markets") or {}).get("h2h") or {}).get("fair_home")

        h2h = (row.get("markets") or {}).get("h2h") or {}
        row["model"] = {
            "home_win_prob": hp,
            "away_win_prob": ap,
            "market_home_prob": market,
            # The slate supplies its own; Elo and BPI do not, so it is
            # worked out here from the market, in points, home side.
            "disagreement": (rating.get("disagreement")
                             if rating.get("disagreement") is not None
                             else round((hp - market) * 100, 1)
                             if market is not None and hp is not None else None),
            "suspect": bool(rating.get("suspect")),
            "source": source,
            **({"proj": rating["proj"]} if rating.get("proj") else {}),
            **({"margin": rating["margin"]}
               if rating.get("margin") is not None else {}),
            **({"edge": rating["edge"]} if rating.get("edge") is not None else {}),
            "ev_home": model_ev(hp, h2h.get("best_home")),
            "ev_away": model_ev(ap, h2h.get("best_away")),
        }
        detail = {k: rating[k] for k in DETAIL_KEYS if rating.get(k) is not None}
        if detail:
            row["detail"] = detail
        matched += 1
    return matched


def model_ev(prob, best) -> float | None:
    """EV of backing this side at the best posted price, on OUR number.

    Deliberately a different quantity from the market edges already on the
    card. Those compare a book's price against the devigged consensus and
    answer "is this book off the market". This asks "does our own
    probability say this price is worth taking", which is the only version
    a reader can act on and the only one that is ever wrong in a way that
    matters.

    Returns None rather than a number when either half is missing: no model
    for the game, or no book pricing that side. A zero would read as a fair
    price rather than as an absence.
    """
    if prob is None or not best:
        return None
    price = best.get("price")
    if price is None:
        return None
    return round(om.expected_value_pct(prob, price), 1)


def merge_form(rows: list[dict], games: list[dict]) -> int:
    """Attach record, streak, last ten and the season series to each row.

    For the three leagues MLB's free API does not cover. ESPN answers a
    GitHub runner with 403 and the paid scores endpoint reaches back three
    days, not a season, so these come from the finals this project stores for
    itself -- which costs nothing further and depends on no outside party
    staying friendly.

    A club we have stored no finished games for is left alone entirely: an
    empty form block renders as a panel with three blank rows, which reads as
    a broken page rather than as a young season.
    """
    if not games:
        return 0
    form = form_store.table(games)
    matched = 0
    for row in rows:
        home, away = row.get("home"), row.get("away")
        if home not in form or away not in form:
            continue
        detail = row.setdefault("detail", {})
        detail["home_form"] = form[home]
        detail["away_form"] = form[away]
        detail["series"] = form_store.series(games, home, away)
        matched += 1
    return matched


# A club needs this many games of its own before its rating means anything.
# The league-wide min_games gate cannot stand in for it: one day of ESPN's
# college-basketball scoreboard is 100+ rows, so a 100-row store is satisfied
# on its very first morning while every club in it has played exactly once —
# and ratings.run() calls setdefault on both clubs before the tie check, so
# even a club whose only appearance was a draw sits in the table at the 1500
# starting value with zero information behind it. Ten games is where a K of
# 20-24 has moved a rating far enough from 1500 to be saying something.
MIN_CLUB_GAMES = 10


# College basketball before Elo is ready (both clubs under MIN_CLUB_GAMES).
# ESPN BPI is points better than an average D-I team on a neutral court, so:
# expected margin = BPI(home) - BPI(away) + BPI_HOME_EDGE (0 at a neutral
# site), win probability = normal CDF of margin / BPI_SD. Both constants are
# starting values; the league's own Brier record grades them.
BPI_HOME_EDGE = 3.5
BPI_SD = 11.0
# Not Elo's 15-85%: a 20-point college favourite really does win ~96% of
# the time, and capping it at 85 printed a fake "fade" on every big spread.
BPI_FLOOR, BPI_CEIL = 0.01, 0.99


def _et_day(stamp):
    from datetime import datetime          # noqa: PLC0415
    from zoneinfo import ZoneInfo          # noqa: PLC0415
    try:
        t = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
    except ValueError:
        return None
    return t.astimezone(ZoneInfo("America/New_York")).date()


NCAAB_MONTHS = (11, 12, 1, 2, 3, 4)


def espn_board_needed(boards: dict, day) -> bool:
    """Start an empty college basketball board when the odds bought none --
    the monthly credits ran out, or the feed failed -- so espn_fill builds
    the day's whole slate from ESPN's free lines instead of the site showing
    yesterday's games. In season only. True when the board is to be filled
    from ESPN alone."""
    if day.month not in NCAAB_MONTHS:
        return False
    if boards.get("ncaab"):
        return False
    boards["ncaab"] = []
    return True


def espn_fill(rows: list[dict], espn_games: list[dict], day) -> list[dict]:
    """The whole day's college basketball slate, not just what the Odds API
    still lists. The Odds API drops a game once it tips off, so a board priced
    late in the day lost every game already under way. ESPN's scoreboard keeps
    them all, each with ESPN's own line.

    Priced rows keep their Odds API line and learn their ESPN id (for scores).
    ESPN games the Odds API did not list come back as new rows carrying
    ESPN's spread and total; games with no line at all are skipped.
    Returns the new rows; the caller appends them.
    """
    import ncaab_system  # noqa: PLC0415 -- name_key
    key = ncaab_system.name_key
    # Unordered: the two feeds sometimes disagree on who is home (a neutral
    # site), and that is still one game.
    by_pair = {frozenset((key(r.get("away")), key(r.get("home")))): r for r in rows}

    def minute(stamp):
        try:
            from datetime import datetime  # noqa: PLC0415
            return datetime.fromisoformat(str(stamp).replace("Z", "+00:00")).replace(
                second=0, microsecond=0)
        except ValueError:
            return None

    added = []
    for g in espn_games:
        if _et_day(g.get("commence_time")) != day:
            continue
        home, away = g["home"]["name"], g["away"]["name"]
        priced = by_pair.get(frozenset((key(away), key(home))))
        if priced is None:
            # Spelled differently by the two feeds ("UMKC" / "Kansas City"):
            # the same tip-off with one school in common is the same game.
            # The row takes ESPN's names, in its own home/away order.
            tip, names = minute(g.get("commence_time")), {key(home): home, key(away): away}
            for r in rows:
                if tip is None or minute(r.get("commence_time")) != tip:
                    continue
                rk = {"home": key(r.get("home")), "away": key(r.get("away"))}
                hit = [side for side, k in rk.items() if k in names]
                if len(hit) != 1:
                    continue
                other = "away" if hit[0] == "home" else "home"
                r[other] = next(n for k, n in names.items() if k != rk[hit[0]])
                r[hit[0]] = names[rk[hit[0]]]
                priced = r
                break
        if priced is not None:
            priced["espn_id"] = str(g["event_id"])
            continue
        if g.get("spread_home") is None:
            continue
        markets = {"spreads": {"point": g["spread_home"], "side_a": "home"}}
        if g.get("total") is not None:
            markets["totals"] = {"point": g["total"]}
        added.append({"event_id": f"espn-{g['event_id']}", "espn_id": str(g["event_id"]),
                      "league": "ncaab", "commence_time": g.get("commence_time", ""),
                      "home": home, "away": away, "markets": markets,
                      "model": None, "line_source": "espn"})
    added.sort(key=lambda r: r["commence_time"])
    return added


def attach_ats(rows: list[dict], sd: float, stretch: float | None = None,
               season: dict | None = None) -> int:
    """Our side against the market spread, for rows whose rating carries an
    expected margin (BPI does; Elo does not). Returns rows given a pick.

    The margin is first stretched to the market's scale -- `stretch`, else
    fitted on these rows, else ats.STRETCH_DEFAULT -- then blended with
    `season` ({name_key: (games, margin per game)}) when both clubs have
    played enough. See ats.py for why."""
    import ats  # noqa: PLC0415
    import ncaab_system  # noqa: PLC0415 -- name_key
    priced = []
    for row in rows:
        margin = (row.get("model") or {}).get("margin")
        sp = (row.get("markets") or {}).get("spreads") or {}
        if margin is None or sp.get("point") is None:
            continue
        home_pt = sp["point"] if sp.get("side_a", "home") == "home" else -sp["point"]
        priced.append((row, margin, home_pt))
    k = stretch if stretch is not None else ats.fit_stretch(
        [(m, -hp) for _, m, hp in priced], ats.STRETCH_DEFAULT["ncaab"])
    key = ncaab_system.name_key
    n = 0
    for row, margin, home_pt in priced:
        m = margin * k
        if season:
            edge = (row.get("model") or {}).get("edge", BPI_HOME_EDGE)
            m = ats.blend(m, season.get(key(row.get("home"))),
                          season.get(key(row.get("away"))), edge)
        p = ats.pick(m, home_pt, sd, row.get("home", ""), row.get("away", ""))
        if p:
            p["stretch"] = k
            row["ats"] = p
            n += 1
    return n


def season_margins(teams_doc: dict | None) -> dict:
    """{name_key: (games, points for minus against per game)} from the
    Team Stats sheet (ncaab_teams.json or ncaaf's), for ats.blend."""
    out = {}
    for k, t in ((teams_doc or {}).get("teams") or {}).items():
        st = t.get("stats") or {}
        if st.get("pts") is not None and st.get("opp") is not None and t.get("games"):
            out[k] = (t["games"], round(st["pts"] - st["opp"], 1))
    return out


def bpi_model(rows: list[dict], doc: dict) -> list[dict]:
    """Rate board rows from data/ncaab_bpi.json, by team name.

    A row is rated only when BOTH clubs are found: the board's names come
    from the Odds API and BPI's from ESPN, and a half-matched game must not
    be guessed. Probabilities clamped and rounded exactly as elo_model does.
    """
    import math              # noqa: PLC0415
    import ncaab_system      # noqa: PLC0415  -- name_key
    values = (doc or {}).get("values") or {}
    neutral = set((doc or {}).get("neutral") or [])
    key = ncaab_system.name_key
    out = []
    for row in rows:
        h, a = key(row.get("home")), key(row.get("away"))
        if h not in values or a not in values:
            continue
        # Either order: ESPN flags the site, the Odds API may list the
        # clubs the other way round.
        edge = 0.0 if (f"{a}@{h}" in neutral or f"{h}@{a}" in neutral) else BPI_HOME_EDGE
        margin = values[h] - values[a] + edge
        hp = 0.5 * (1 + math.erf(margin / BPI_SD / math.sqrt(2)))
        hp = round(max(BPI_FLOOR, min(BPI_CEIL, hp)), 4)
        rated = {"event_id": row.get("event_id"), "home_win_prob": hp,
                 "away_win_prob": round(1.0 - hp, 4), "margin": round(margin, 1),
                 "edge": edge}
        # Projected score: each offence against the other defence, around
        # the league's points per team per game, home edge split evenly.
        # Its margin equals the BPI margin above by construction.
        od, avg = (doc or {}).get("offdef") or {}, (doc or {}).get("avg_pts")
        if h in od and a in od and avg:
            (oh, dh), (oa, da) = od[h], od[a]
            rated["proj"] = [round(avg + oh - da + edge / 2, 1),
                             round(avg + oa - dh - edge / 2, 1)]
        out.append(rated)
    return out


def elo_model(rows: list[dict], history: list[dict], short: str,
              min_games: int = 100) -> tuple[list[dict], int]:
    """Rate a league's upcoming games from its stored results.

    Returns (rating rows shaped for merge_model, rows skipped for want of
    history). A league with fewer than min_games of history is not rated at
    all: Elo needs a season to say anything, and a number built on a handful
    of games is noise wearing a percentage sign. A game is skipped unless
    BOTH clubs appear in at least MIN_CLUB_GAMES stored games — presence in
    the rating table is not evidence, only participation is.

    The skip count is returned rather than swallowed because the most likely
    cause is not a thin store but a name mismatch: the store is filled from
    ESPN and the board from the Odds API, and results.py's own docstring
    flags that spelling question as unresolved. A total mismatch makes the
    feature silently absent and a partial one rates half a board, so the
    caller gets a number it can print.

    Probabilities are clamped to rate_mlb's floor and ceiling. An Elo with no
    regression, no margin of victory and no backtest behind it is not
    trustworthy at the tails: the gap that produces 95% is a handful of
    results away from the gap that produces 80%, and printing the extreme
    number states a confidence this model has not earned.

    Deliberately carries no market comparison. merge_model fills
    market_home_prob from whatever rated the game, falling back to the row's
    own h2h fair price; Elo alone does not know what the market thinks.
    """
    cfg = ratings.LEAGUE_CONFIG.get(short)
    if not cfg or len(history) < min_games:
        return [], 0

    played: Counter = Counter()
    for g in history:
        played[g.get("home")] += 1
        played[g.get("away")] += 1

    table = ratings.run(history, cfg)
    out, skipped = [], 0
    for row in rows:
        home, away = row.get("home"), row.get("away")
        if (home not in table or away not in table
                or played[home] < MIN_CLUB_GAMES
                or played[away] < MIN_CLUB_GAMES):
            skipped += 1
            continue
        hp = ratings.win_probability(table[home], table[away], cfg)
        hp = max(rate_mlb.PROB_FLOOR, min(rate_mlb.PROB_CEIL, hp))
        # Rounded to the same 4dp the slate path uses: full-precision floats
        # would rewrite board.json every morning on noise in the last digit.
        hp = round(hp, 4)
        out.append({
            "event_id": row.get("event_id"),
            "home_win_prob": hp,
            "away_win_prob": round(1.0 - hp, 4),
        })
    return out, skipped


def _test_bpi_model() -> None:
    import math  # noqa: PLC0415
    doc = {"values": {"duke blue devils": 8.0, "texas longhorns": 2.0,
                      "st johns red storm": 5.0},
           "neutral": ["texas longhorns@st johns red storm"]}
    rows = [{"event_id": "a", "home": "Duke Blue Devils", "away": "Texas Longhorns"},
            {"event_id": "b", "home": "St. John's Red Storm", "away": "Texas Longhorns"},
            {"event_id": "c", "home": "Nowhere State", "away": "Texas Longhorns"}]
    rated = bpi_model(rows, doc)
    assert [r["event_id"] for r in rated] == ["a", "b"], "unknown team: unrated"
    # Home by 6 + 3.5 = 9.5 over an 11-point spread of outcomes.
    want = round(0.5 * (1 + math.erf(9.5 / BPI_SD / math.sqrt(2))), 4)
    assert rated[0]["home_win_prob"] == want == 0.8061, rated[0]
    assert rated[0]["away_win_prob"] == round(1 - want, 4)
    # Neutral site: no home edge; matched despite "St." vs "St".
    want_b = round(0.5 * (1 + math.erf(3.0 / BPI_SD / math.sqrt(2))), 4)
    assert rated[1]["home_win_prob"] == want_b
    assert bpi_model(rows, {}) == []
    # A neutral site flagged in ESPN's order still drops the home edge when
    # the Odds API lists the two clubs the other way round.
    flip_doc = dict(doc, neutral=["st johns red storm@texas longhorns"])
    assert bpi_model(rows[1:2], flip_doc)[0]["home_win_prob"] == want_b
    # A 25-point favourite is not capped at Elo's 85%: that cap turned every
    # big college favourite into a fake "fade". BPI is capped at 99%.
    big = bpi_model([{"event_id": "z", "home": "Duke Blue Devils",
                      "away": "Texas Longhorns"}],
                    {"values": {"duke blue devils": 25.0, "texas longhorns": 3.5}})
    assert 0.97 < big[0]["home_win_prob"] <= BPI_CEIL == 0.99, big
    # Projected score from offence vs defence around the league average.
    doc_p = dict(doc, offdef={"duke blue devils": [5.0, 3.0],
                              "texas longhorns": [1.0, 1.0]}, avg_pts=72.0)
    pr = bpi_model(rows[:1], doc_p)[0]["proj"]
    # Duke 72 + 5 - 1 + 1.75 = 77.75; Texas 72 + 1 - 3 - 1.75 = 68.25.
    assert pr == [77.8, 68.2], pr
    assert "proj" not in bpi_model(rows[:1], doc)[0], "no off/def, no projection"
    # merge_model computes the edge from the market when a rating has none,
    # so a BPI or Elo card says "+9.9 EDGE" rather than always "NO EDGE".
    board_rows = [{"event_id": "a", "home": "H", "away": "A",
                   "markets": {"h2h": {"fair_home": 0.70}}}]
    merge_model(board_rows, [{"event_id": "a", "home_win_prob": 0.80,
                              "away_win_prob": 0.20}], "bpi")
    assert board_rows[0]["model"]["disagreement"] == 10.0
    assert board_rows[0]["model"]["source"] == "bpi"
    merge_model(board_rows, [{"event_id": "a", "home_win_prob": 0.8,
                              "away_win_prob": 0.2, "proj": [77.8, 68.2]}], "bpi")
    assert board_rows[0]["model"]["proj"] == [77.8, 68.2], "projection reaches the card"
    # The expected margin travels too, and attach_ats turns it plus the
    # market spread into our side against the number.
    assert rated[0]["margin"] == 9.5 and rated[0]["edge"] == BPI_HOME_EDGE
    ats_rows = [{"event_id": "a", "home": "Ohio State Buckeyes",
                 "away": "Marshall Thundering Herd",
                 "markets": {"spreads": {"point": -25.5, "side_a": "home"},
                             "h2h": {"fair_home": 0.99}}}]
    merge_model(ats_rows, [{"event_id": "a", "home_win_prob": 0.97,
                            "away_win_prob": 0.03, "margin": 21.0, "edge": 3.5}], "bpi")
    assert ats_rows[0]["model"]["edge"] == 3.5, "home edge travels with the margin"
    assert attach_ats(ats_rows, 11.0, stretch=1.0) == 1
    assert ats_rows[0]["ats"]["team"] == "Marshall Thundering Herd"
    assert ats_rows[0]["ats"]["line"] == 25.5 and ats_rows[0]["ats"]["raw"] == 4.5
    # Stretched by the default when the day is too thin to fit: 21 x 1.24
    # = 26.0 against 25.5, so Ohio State by half a point.
    ats_rows[0].pop("ats")
    attach_ats(ats_rows, 11.0)
    assert ats_rows[0]["ats"]["side"] == "home" and ats_rows[0]["ats"]["raw"] == 0.5
    assert ats_rows[0]["ats"]["stretch"] == 1.24
    # Fitted from the day when there are enough games: every market line
    # 1.1x ours, so the stretched line equals the market's -- no pick.
    day = [{"event_id": f"e{i}", "home": f"H{i}", "away": f"A{i}",
            "model": {"home_win_prob": 0.7, "margin": 10.0 + i},
            "markets": {"spreads": {"point": -round(1.1 * (10.0 + i), 1), "side_a": "home"}}}
           for i in range(12)]
    assert attach_ats(day, 11.0) == 0
    # Season blend: both clubs with 10 games, half the margin from the
    # season (halved margins plus the home edge carried on the rating).
    season = {"h": (10, 20.0), "a": (10, -10.0)}
    one = [{"event_id": "s", "home": "H", "away": "A",
            "model": {"home_win_prob": 0.7, "margin": 10.0, "edge": 3.5},
            "markets": {"spreads": {"point": -10.0, "side_a": "home"}}}]
    attach_ats(one, 11.0, stretch=1.0, season=season)
    assert season_margins({"teams": {"x": {"games": 6, "stats": {"pts": 80.0, "opp": 70.5}},
                                     "y": {"games": 0, "stats": {"pts": None}}}}) == {"x": (6, 9.5)}
    assert one[0]["ats"]["raw"] == 4.2     # 0.5 x 10 + 0.5 x (15 + 3.5) = 14.2, less 10
    # Spread quoted on the away side is turned to the home side first.
    away_q = [dict(ats_rows[0], markets={"spreads": {"point": 25.5, "side_a": "away"}})]
    away_q[0].pop("ats")
    attach_ats(away_q, 11.0, stretch=1.0)
    assert away_q[0]["ats"]["line"] == 25.5 and away_q[0]["ats"]["side"] == "away"
    # No margin (Elo-rated): nothing attached.
    plain = [{"event_id": "b", "home": "H", "away": "A", "model": {"home_win_prob": 0.6},
              "markets": {"spreads": {"point": -3.0, "side_a": "home"}}}]
    assert attach_ats(plain, 11.0) == 0 and "ats" not in plain[0]


def _test_espn_fill() -> None:
    from datetime import date as _d
    # No odds bought (credits out): an empty college board is started so the
    # ESPN fill can build the whole slate. Never out of season, never over a
    # board the odds did buy.
    b = {"nba": [{"event_id": "n"}]}
    assert espn_board_needed(b, _d(2026, 11, 22)) is True and b["ncaab"] == [], b
    kept = {"ncaab": [{"event_id": "odds"}]}
    assert espn_board_needed(kept, _d(2026, 11, 22)) is False and len(kept["ncaab"]) == 1
    summer = {}
    assert espn_board_needed(summer, _d(2026, 7, 4)) is False and "ncaab" not in summer
    empty = {"ncaab": []}
    assert espn_board_needed(empty, _d(2027, 1, 10)) is True, "an empty odds board is filled too"
    odds = [{"event_id": "odds1", "league": "ncaab", "home": "Ohio State Buckeyes",
             "away": "Marshall Thundering Herd", "commence_time": "2026-11-09T23:00:00Z",
             "markets": {"spreads": {"point": -25.5, "side_a": "home"}}}]
    def eg(eid, home, away, when, spread, total=None):
        return {"event_id": eid, "commence_time": when, "home": {"name": home},
                "away": {"name": away}, "spread_home": spread, "total": total}
    espn = [eg("401", "Ohio State Buckeyes", "Marshall Thundering Herd",
               "2026-11-09T23:00Z", -24.5),
            eg("402", "Duke Blue Devils", "Army Black Knights", "2026-11-09T21:00Z",
               -30.5, 145.5),
            eg("403", "Kansas Jayhawks", "X", "2026-11-11T00:00Z", -20.0),   # tomorrow ET
            eg("404", "Y", "Z", "2026-11-09T22:00Z", None)]                   # no line
    added = espn_fill(odds, espn, _d(2026, 11, 9))
    assert odds[0]["espn_id"] == "401", "priced game learns its ESPN id"
    assert odds[0]["markets"]["spreads"]["point"] == -25.5, "the Odds API line wins"
    assert [r["event_id"] for r in added] == ["espn-402"], added
    r = added[0]
    assert r["espn_id"] == "402" and r["league"] == "ncaab"
    assert r["markets"]["spreads"] == {"point": -30.5, "side_a": "home"}
    assert r["markets"]["totals"] == {"point": 145.5}
    assert r["line_source"] == "espn"
    # The feeds can disagree on who is home (Seton Hall / Charlotte, a
    # neutral-site game, 2026-11-09): still one game, not two.
    flipped = [{"event_id": "o2", "league": "ncaab", "home": "Seton Hall Pirates",
                "away": "Charlotte 49ers", "commence_time": "2026-11-10T02:00:00Z",
                "markets": {"spreads": {"point": -4.5, "side_a": "home"}}}]
    extra = espn_fill(flipped, [eg("401920887", "Charlotte 49ers", "Seton Hall Pirates",
                                   "2026-11-10T02:00Z", 4.5)], _d(2026, 11, 9))
    assert extra == [] and flipped[0]["espn_id"] == "401920887"
    # The feeds spell some schools differently ("UMKC Kangaroos" / "Kansas
    # City Roos", "Loyola (Chi)" / "Loyola Chicago": ten games doubled on
    # 2026-11-11). Same tip-off and one school in common is the same game;
    # the row takes ESPN's names, which BPI, the team sheets and the live
    # scores all use.
    umkc = [{"event_id": "o3", "league": "ncaab", "home": "Florida A&M Rattlers",
             "away": "UMKC Kangaroos", "commence_time": "2026-11-11T17:00:00Z",
             "markets": {"spreads": {"point": 7.5, "side_a": "home"}}}]
    extra = espn_fill(umkc, [eg("501", "Florida A&M Rattlers", "Kansas City Roos",
                                "2026-11-11T17:00Z", 7.5)], _d(2026, 11, 11))
    assert extra == [] and umkc[0]["espn_id"] == "501"
    assert umkc[0]["away"] == "Kansas City Roos" and umkc[0]["home"] == "Florida A&M Rattlers"
    # Flipped home/away AND a spelling difference: names follow the row's order.
    lb = [{"event_id": "o4", "league": "ncaab", "home": "Pacific Tigers",
           "away": "Long Beach St 49ers", "commence_time": "2026-11-12T03:00:00Z",
           "markets": {}}]
    espn_fill(lb, [eg("502", "Long Beach State Beach", "Pacific Tigers",
                      "2026-11-12T03:00Z", -3.0)], _d(2026, 11, 11))
    assert lb[0]["away"] == "Long Beach State Beach" and lb[0]["home"] == "Pacific Tigers"
    # One school in common but a different start: a different game.
    other = [{"event_id": "o5", "league": "ncaab", "home": "Florida A&M Rattlers",
              "away": "Somebody", "commence_time": "2026-11-11T23:00:00Z", "markets": {}}]
    assert len(espn_fill(other, [eg("503", "Florida A&M Rattlers", "Kansas City Roos",
                                    "2026-11-11T17:00Z", 7.5)], _d(2026, 11, 11))) == 1


def _test_keep_started() -> None:
    from datetime import datetime, timezone  # noqa: PLC0415
    now = datetime(2026, 11, 11, 3, 30, tzinfo=timezone.utc)   # 10:30 PM ET
    old = {"date": "2026-11-10", "leagues": {
        "ncaab": {"games": [{"event_id": "x", "commence_time": "2026-11-11T00:00:00Z"},
                            {"event_id": "late", "commence_time": "2026-11-11T05:00:00Z"}]},
        "nba": {"games": [{"event_id": "n1", "commence_time": "2026-11-11T00:30:00Z"},
                          {"event_id": "n2", "commence_time": "2026-11-11T03:00:00Z"}]}}}
    # A late re-run: the odds feed has dropped every game already under way.
    boards = {"nba": [{"event_id": "n2", "commence_time": "2026-11-11T03:00:00Z", "fresh": True}]}
    assert keep_started(boards, old, "2026-11-10", now) == 2
    assert [r["event_id"] for r in boards["ncaab"]] == ["x"], "started game kept"
    assert "late" not in [r["event_id"] for r in boards["ncaab"]], "unstarted, gone: dropped"
    assert {r["event_id"] for r in boards["nba"]} == {"n1", "n2"}
    assert next(r for r in boards["nba"] if r["event_id"] == "n2")["fresh"], "fresh row wins"
    # A new day: yesterday's board is not carried.
    b2: dict = {}
    assert keep_started(b2, old, "2026-11-11", now) == 0 and b2 == {}
    assert keep_started({}, None, "2026-11-10", now) == 0


def _self_test() -> None:
    _test_keep_started()
    _test_bpi_model()
    _test_espn_fill()
    import io                        # noqa: PLC0415
    import contextlib                # noqa: PLC0415

    # A four-book game. Caesars is best on both moneyline sides and hangs a
    # different total from everyone else.
    game = {
        "id": "evt1", "sport_key": "baseball_mlb",
        "commence_time": "2026-08-31T23:05:00Z",
        "home_team": "Milwaukee Brewers", "away_team": "Chicago Cubs",
        "bookmakers": [
            _book("fanduel", "FanDuel", (-130, 110),
                  spread=(130, -155, -1.5), total=(-105, -115, 8.5)),
            _book("draftkings", "DraftKings", (-128, 108),
                  spread=(134, -160, -1.5), total=(-108, -112, 8.5)),
            _book("betmgm", "BetMGM", (-132, 112),
                  spread=(128, -152, -1.5), total=(-112, -108, 8.5)),
            # Caesars hangs a different total. It must not be devigged
            # against the other three — that would price a market nobody
            # is offering.
            _book("caesars", "Caesars", (-125, 114), total=(-110, -110, 9.5)),
        ],
    }

    quotes, point = quotes_for(game, "h2h")
    assert point is None, "a moneyline has no line to hang"
    assert len(quotes) == 4, quotes
    assert quotes[0]["book"] == "FanDuel", "the display title, not the key"
    assert quotes[0]["price_a"] == -130 and quotes[0]["price_b"] == 110, \
        "side a is the home team"

    # The modal total is 8.5 (three books); Caesars' 9.5 is excluded.
    tq, tpoint = quotes_for(game, "totals")
    assert tpoint == 8.5, tpoint
    assert len(tq) == 3, "only the books hanging the modal line are priced"
    assert tq[0]["price_a"] == -105, "side a is the over"

    # Three books post a spread, and all hang -1.5.
    sq, spoint = quotes_for(game, "spreads")
    assert spoint == -1.5, "the line is quoted from the home team's side"
    assert len(sq) == 3

    # A market no book posts yields nothing rather than raising.
    bare = {"id": "e", "home_team": "A", "away_team": "B", "bookmakers": []}
    assert quotes_for(bare, "h2h") == ([], None)

    row = price_game(game, "mlb")
    assert row is not None
    assert row["event_id"] == "evt1"
    assert row["league"] == "mlb"
    assert row["home"] == "Milwaukee Brewers"
    assert set(row["markets"]) <= {"h2h", "spreads", "totals"}

    # The monkeypatch in _price_market must put config.MIN_BOOKS back. The
    # daily job runs find_plays in this same process; a lost restore would
    # silently drop the betting card's floor to the board's.
    assert config.MIN_BOOKS == 6, \
        "_price_market must restore the play picker's book floor"

    ml = row["markets"]["h2h"]
    assert ml["side_a"] == "home" and row["markets"]["totals"]["side_a"] == "over", \
        "side A is the over on a total, not the home team"
    assert ml["best_home"]["book"] == "Caesars", \
        "-125 is the best price on the home side"
    assert ml["best_away"]["book"] == "Caesars" and ml["best_away"]["price"] == 114, \
        "+114 is the best price on the away side"
    assert 0.0 < ml["fair_home"] < 1.0
    assert 0.0 < ml["fair_away"] < 1.0
    # The away side's edge is measured against the away side's own fair
    # number and the away side's own best price. Reporting edge_a here would
    # go unnoticed without this.
    assert abs(ml["edge_away"]
               - om.expected_value_pct(ml["fair_away"], 114)) < 1e-9
    assert ml["edge_away"] != ml["edge_home"]
    assert ml["books"] == 4

    tot = row["markets"]["totals"]
    assert tot["point"] == 8.5
    assert tot["books"] == 3, "Caesars hung 9.5 and is not counted"
    assert tot["model"] is None, \
        "there is no scoring model; a total must never carry our own number"
    # Every quoted total here is 20 cents wide, so the median width is 20.
    # width is the typical single book's width, not the best-of-market pair's.
    assert tot["width"] == 20, tot["width"]

    # --- the two sides are NOT a probability distribution -----------------
    # Each side's consensus deliberately excludes the book holding THAT
    # side's best price, so with different books best on the two sides the
    # two numbers come from different samples and do not sum to 1. They are
    # two independent per-side benchmarks. NEVER normalise them: dividing
    # them by their sum would silently undo the leave-one-out exclusion,
    # which is the whole point of the estimator.
    split = {
        "id": "evt3", "commence_time": "2026-08-31T23:05:00Z",
        "home_team": "Milwaukee Brewers", "away_team": "Chicago Cubs",
        "bookmakers": [
            _book("alpha", "Alpha", (-125, 105)),     # best on the home side
            _book("bravo", "Bravo", (-140, 130)),     # best on the away side
            _book("charlie", "Charlie", (-134, 114)),
        ],
    }
    sml = price_game(split, "mlb")["markets"]["h2h"]
    assert sml["best_home"]["book"] == "Alpha"
    assert sml["best_away"]["book"] == "Bravo"
    assert sml["best_home"]["book"] != sml["best_away"]["book"], \
        "the two sides must come from different exclusions here"
    total = sml["fair_home"] + sml["fair_away"]
    assert total > 1.0 + 1e-9, total
    assert 1.0 <= total < 1.10, total

    # --- BOARD_MIN_BOOKS --------------------------------------------------
    # Pinned, because at 2 each side's "consensus" is one book's opinion on
    # a card that says "2 books".
    assert BOARD_MIN_BOOKS == 3, BOARD_MIN_BOOKS
    two = dict(game, id="evt4", bookmakers=game["bookmakers"][:2])
    assert price_game(two, "mlb") is None, \
        "two quotes leave a one-book consensus per side"
    three = dict(game, id="evt5", bookmakers=game["bookmakers"][:3])
    assert price_game(three, "mlb") is not None, "three quotes are enough"

    # --- one-sided books --------------------------------------------------
    # A book posting only the over is not half a quote; it is no quote.
    one_sided = {"key": "onesided", "title": "OneSided", "markets": [
        {"key": "totals", "outcomes": [{"name": "Over", "price": -110,
                                        "point": 8.5}]}]}
    lopsided = dict(game, id="evt6",
                    bookmakers=game["bookmakers"] + [one_sided])
    lq, _lp = quotes_for(lopsided, "totals")
    assert len(lq) == 3, "a book quoting one side is not counted"

    # --- duplicate outcome names (alternate lines) ------------------------
    # Four books send one payload carrying both -1.5 and -2.5; three send
    # only the honest -1.5. Keeping the last pair per name turns those four
    # into -2.5 quotes, which outvotes the main line, discards the -1.5 the
    # same books actually posted, and can push the market under the floor.
    def _alt(key, title, main, alt):
        return {"key": key, "title": title, "markets": [
            {"key": "spreads", "outcomes": [
                {"name": "Milwaukee Brewers", "price": main[0], "point": -1.5},
                {"name": "Chicago Cubs", "price": main[1], "point": 1.5},
                {"name": "Milwaukee Brewers", "price": alt[0], "point": -2.5},
                {"name": "Chicago Cubs", "price": alt[1], "point": 2.5}]}]}

    alts = [_alt(f"alt{i}", f"Alt{i}", (130 + i, -155 - i), (210 + i, -260 - i))
            for i in range(4)]
    dup = dict(game, id="evt7", bookmakers=game["bookmakers"] + alts)
    dq, dpoint = quotes_for(dup, "spreads")
    assert dpoint == -1.5, \
        "an alternate-line payload must not outvote the main line"
    names = [q["book"] for q in dq]
    assert len(dq) == 3 and not any(n.startswith("Alt") for n in names), \
        "a book repeating an outcome name is skipped, not last-one-wins"

    # --- deterministic modal line ----------------------------------------
    # Four books, 8.5/9.5/9.5/8.5: a 2-2 tie. Insertion order must not
    # decide it, so both permutations answer the same.
    def tie(order):
        books = {
            "a": _book("a", "A", (-110, -110), total=(-110, -110, 8.5)),
            "b": _book("b", "B", (-110, -110), total=(-110, -110, 9.5)),
            "c": _book("c", "C", (-110, -110), total=(-110, -110, 9.5)),
            "d": _book("d", "D", (-110, -110), total=(-110, -110, 8.5)),
        }
        return quotes_for({"home_team": "Milwaukee Brewers",
                           "away_team": "Chicago Cubs",
                           "bookmakers": [books[k] for k in order]},
                          "totals")[1]
    assert tie("abcd") == tie("bcda") == tie("dcba") == 8.5, \
        "the modal line must not depend on bookmaker order"

    # --- both sides must describe the same line ---------------------------
    mixed = {"key": "mix", "title": "Mixed", "markets": [
        {"key": "spreads", "outcomes": [
            {"name": "Milwaukee Brewers", "price": 130, "point": -1.5},
            {"name": "Chicago Cubs", "price": -155, "point": 2.5}]}]}
    mx = dict(game, id="evt8", bookmakers=game["bookmakers"] + [mixed])
    mq, _mp = quotes_for(mx, "spreads")
    assert "Mixed" not in [q["book"] for q in mq], \
        "home -1.5 / away +2.5 is two markets, not one quote"

    # --- a three-way market is not this market ----------------------------
    draw = {"key": "three", "title": "Three", "markets": [
        {"key": "h2h", "outcomes": [
            {"name": "Milwaukee Brewers", "price": -125},
            {"name": "Chicago Cubs", "price": 114},
            {"name": "Draw", "price": 260}]}]}
    tw = dict(game, id="evt9", bookmakers=game["bookmakers"] + [draw])
    twq, _twp = quotes_for(tw, "h2h")
    assert "Three" not in [q["book"] for q in twq], \
        "dropping the draw and devigging the rest fabricates an edge"

    # A game with too few books to price at all is dropped from the board
    # rather than shown with an invented number.
    thin = dict(game, id="evt2", bookmakers=game["bookmakers"][:1])
    assert price_game(thin, "mlb") is None

    # A game missing a team name is skipped outright — totals would
    # otherwise price and emit a row with "home": null.
    nameless = dict(game, id="evt10", home_team=None)
    assert price_game(nameless, "mlb") is None
    assert quotes_for(nameless, "totals")[0], "totals alone would still price"

    rows = build([game, thin], "mlb")
    assert len(rows) == 1, "only the priceable game reaches the board"

    # Sorted by start time, not by input order.
    early = dict(game, id="early", commence_time="2026-08-31T17:05:00Z")
    late = dict(game, id="late", commence_time="2026-08-31T23:05:00Z")
    assert [r["event_id"] for r in build([late, early], "mlb")] \
        == ["early", "late"], "the board is in start-time order"

    # --- one bad game must not take the league with it --------------------
    broken = [
        dict(game, id="bad-zero", bookmakers=[
            _book("x", "X", (0, 110)), _book("y", "Y", (-128, 108)),
            _book("z", "Z", (-132, 112))]),
        dict(game, id="bad-string-outcome", bookmakers=[
            {"key": "s", "title": "S", "markets": [
                {"key": "h2h", "outcomes": ["Milwaukee Brewers", "Chicago Cubs"]}]},
            _book("y", "Y", (-128, 108)), _book("z", "Z", (-132, 112))]),
        dict(game, id="bad-price", bookmakers=[
            _book("x", "X", ("even", 110)), _book("y", "Y", (-128, 108)),
            _book("z", "Z", (-132, 112))]),
    ]
    err = io.StringIO()
    with contextlib.redirect_stderr(err):
        survivors = build(broken + [game], "mlb")
    assert [r["event_id"] for r in survivors] == ["evt1"], \
        "a malformed game must not delete the rest of the league"
    logged = err.getvalue()
    for bad in ("bad-zero", "bad-string-outcome", "bad-price"):
        assert bad in logged, f"{bad} was swallowed silently: {logged!r}"

    doc = document({"mlb": rows}, "2026-08-31T13:00:00", "2026-08-31")
    assert doc["date"] == "2026-08-31"
    assert doc["leagues"]["mlb"]["label"] == "MLB"
    assert doc["leagues"]["mlb"]["games"][0]["event_id"] == "evt1"
    assert doc["counts"]["mlb"] == 1

    # An empty league is absent, not present-and-empty: the pages ask
    # "is this league on tonight?" by asking whether the key exists.
    nba_rows = [dict(r, league="nba") for r in rows]
    empty = document({"mlb": [], "nba": nba_rows}, "2026-08-31T13:00:00",
                     "2026-08-31")
    assert "mlb" not in empty["leagues"] and "mlb" not in empty["counts"], \
        "a league with no games must be omitted, not written empty"
    assert empty["counts"] == {"nba": 1}

    # --- merging a rating onto a priced board -------------------------------
    board_rows = [
        {"event_id": "e1", "league": "mlb", "home": "H", "away": "A",
         "commence_time": "2026-09-01T23:00:00Z", "markets": {}, "model": None},
        {"event_id": "e2", "league": "mlb", "home": "H2", "away": "A2",
         "commence_time": "2026-09-01T23:00:00Z", "markets": {}, "model": None},
    ]
    rated = [
        {"event_id": "e1", "home_win_prob": 0.4425, "away_win_prob": 0.5575,
         "market_home_prob": 0.4376, "disagreement": 0.5, "suspect": False,
         "home_record": {"w": 70, "l": 60}, "away_record": {"w": 65, "l": 65},
         "home_starter": "Hunter Greene", "home_starter_era": 3.11,
         "home_hand": "R", "away_starter": "Yu Darvish",
         "away_starter_era": 4.02, "away_hand": "R",
         "home_vs_opp": None, "away_vs_opp": None,
         "home_sp": {"w": 11, "l": 6, "era": 3.11, "whip": 1.09,
                     "innings": 168.0, "h": 140, "k": 190, "bb": 44, "hr": 18},
         "away_sp": {"w": 7, "l": 9, "era": 4.02, "whip": 1.24,
                     "innings": 151.0, "h": 148, "k": 141, "bb": 43, "hr": 21}},
        # A rated game that is not on the board at all — a postponement, or a
        # game the pricing dropped for want of books. It must be ignored, not
        # appended: the board is the list of games we can price.
        {"event_id": "gone", "home_win_prob": 0.5, "away_win_prob": 0.5},
    ]

    matched = merge_model(board_rows, rated, "slate")
    assert matched == 1, matched
    assert len(board_rows) == 2, "merging must not add or drop rows"

    m = board_rows[0]["model"]
    assert m["home_win_prob"] == 0.4425 and m["away_win_prob"] == 0.5575
    assert m["market_home_prob"] == 0.4376
    assert m["disagreement"] == 0.5
    assert m["suspect"] is False
    assert m["source"] == "slate", "the card has to say where the number came from"

    d = board_rows[0]["detail"]
    assert d["home_starter"] == "Hunter Greene"
    assert d["home_record"] == {"w": 70, "l": 60}
    # The starters' season lines have to survive the merge. slate.py wrote
    # them, render has a table for them, and for months DETAIL_KEYS did not
    # name them -- so the comparison silently did not exist.
    assert d["home_sp"]["era"] == 3.11 and d["away_sp"]["k"] == 141, d
    assert set(d["home_sp"]) == {"w", "l", "era", "whip", "innings",
                                 "h", "k", "bb", "hr"}
    assert "home_win_prob" not in d, \
        "the general numbers live in model; detail is the sport-specific extra"

    # An unmatched game keeps its empty model rather than inheriting a
    # neighbour's. Showing one game's number on another is worse than none.
    assert board_rows[1]["model"] is None
    assert board_rows[1].get("detail") is None

    # A rating with no probability is not a rating.
    half = [{"event_id": "e2", "market_home_prob": 0.5}]
    assert merge_model(board_rows, half, "slate") == 0
    assert board_rows[1]["model"] is None

    # The probabilities must be a coherent pair; a rating that does not sum
    # to 1 is a bug upstream and must not reach a card — and must say so,
    # because a silently short board looks exactly like a quiet day.
    bad = [{"event_id": "e2", "home_win_prob": 0.6, "away_win_prob": 0.6}]
    sum_err = io.StringIO()
    with contextlib.redirect_stderr(sum_err):
        assert merge_model(board_rows, half + bad, "slate") == 0
    assert board_rows[1]["model"] is None
    assert "e2" in sum_err.getvalue(), \
        "a rejected rating must name the event it dropped"

    # The market's tick comes off the row itself when the rating has no
    # opinion about prices, which is every Elo-rated card.
    priced = [{"event_id": "e3", "league": "nba", "home": "H3", "away": "A3",
               "markets": {"h2h": {"fair_home": 0.62, "fair_away": 0.38}},
               "model": None}]
    assert merge_model(priced, [{"event_id": "e3", "home_win_prob": 0.55,
                                 "away_win_prob": 0.45}], "elo") == 1
    assert priced[0]["model"]["market_home_prob"] == 0.62, \
        "an Elo card must still get the market's tick from its own h2h price"

    # And the rating's own number wins when it has one: the slate devigs its
    # own book set and that is the number its card is about.
    priced[0]["model"] = None
    assert merge_model(priced, [{"event_id": "e3", "home_win_prob": 0.55,
                                 "away_win_prob": 0.45,
                                 "market_home_prob": 0.5}], "slate") == 1
    assert priced[0]["model"]["market_home_prob"] == 0.5

    # --- rating a league from its stored results ---------------------------
    # Built through results_store.merge rather than by hand, so the fixture is
    # a shape the store could actually hold: merge dedups on
    # (date, home, away), and the old fixture repeated one pairing on one date
    # sixty times — a history this module can never be handed in production.
    import results_store                                     # noqa: PLC0415

    raw = []
    for i in range(60):
        day = f"2026-{i // 28 + 4:02d}-{i % 28 + 1:02d}"
        # Alpha beats Bravo consistently; Charlie and Delta split.
        raw.append({"date": day, "home": "Alpha", "away": "Bravo",
                    "home_score": 5, "away_score": 3, "completed": True})
        raw.append({"date": day, "home": "Charlie", "away": "Delta",
                    "home_score": 4 + i % 2, "away_score": 5 - i % 2,
                    "completed": True})
    history = results_store.merge([], raw)
    assert len(history) == 120, "the fixture must survive the store's own rules"

    upcoming = [{"event_id": "n1", "league": "nba", "home": "Alpha",
                 "away": "Bravo", "markets": {}, "model": None}]

    rated, skipped = elo_model(upcoming, history, "nba", min_games=100)
    assert len(rated) == 1 and skipped == 0, (rated, skipped)
    r = rated[0]
    assert r["event_id"] == "n1"
    assert r["home_win_prob"] > 0.5, "Alpha has beaten Bravo sixty times"

    # The number is clamped. An unregressed Elo with no backtest behind it
    # runs past 92% on a fixture like this one, and printing that states a
    # confidence the model has not earned. (Asserting 0 < p < 1 could not
    # fail — the logistic is always in (0, 1) — and neither could a
    # sum-to-one check on a pair built as p and 1 - p.)
    assert r["home_win_prob"] == rate_mlb.PROB_CEIL, \
        "a sixty-game sweep must be clamped, not published at its raw value"
    assert rate_mlb.PROB_FLOOR <= r["away_win_prob"] <= rate_mlb.PROB_CEIL
    assert r["home_win_prob"] == round(r["home_win_prob"], 4), \
        "full-precision floats rewrite board.json every morning"

    # The direction survives the clamp: reverse the fixture's home and away
    # and it is the away side that sits at the ceiling.
    flipped = [{"event_id": "n1b", "league": "nba", "home": "Bravo",
                "away": "Alpha", "markets": {}, "model": None}]
    flip_rated, _flip_skipped = elo_model(flipped, history, "nba",
                                          min_games=100)
    fr = flip_rated[0]
    assert fr["away_win_prob"] > fr["home_win_prob"], fr
    assert fr["away_win_prob"] > 0.8, \
        "Alpha is still the strong club when it plays on the road"
    assert fr["away_win_prob"] <= rate_mlb.PROB_CEIL

    # The row gate is a boundary, so test it AT the boundary: min_games - 1
    # rows rate nothing, min_games rows rate.
    assert elo_model(upcoming, history[:99], "nba", min_games=100) == ([], 0)
    assert elo_model(upcoming, history[:100], "nba", min_games=100)[0] != []

    # A club can clear the row gate and still have played almost nothing.
    # One day of ESPN's college board is 100+ games with every club at a
    # single appearance, which is exactly the case that must NOT publish.
    one_each = results_store.merge(history, [
        {"date": "2026-11-10", "home": f"C{i}", "away": f"D{i}",
         "home_score": 70, "away_score": 65, "completed": True}
        for i in range(60)])
    assert len(one_each) >= 100, "the thin fixture must clear the row gate"
    single = [{"event_id": "n3", "league": "nba", "home": "C0",
               "away": "D0", "markets": {}, "model": None}]
    assert elo_model(single, one_each, "nba", min_games=100) == ([], 1), \
        "a club with one game must not be published at 1500"

    # Including a club whose only appearance was a tie: ratings.run puts it
    # in the table via setdefault before the tie check, so membership in the
    # table is not evidence that anything is known about it.
    drawn = results_store.merge(history, [
        {"date": "2026-11-11", "home": "Golf", "away": "Hotel",
         "home_score": 80, "away_score": 80, "completed": True}])
    tie_row = [{"event_id": "n4", "league": "nba", "home": "Golf",
                "away": "Hotel", "markets": {}, "model": None}]
    assert elo_model(tie_row, drawn, "nba", min_games=100) == ([], 1)

    # A game whose clubs are absent from the history is skipped, and the skip
    # is COUNTED: the likeliest cause is ESPN and the Odds API spelling the
    # clubs differently, and without a count that failure is invisible.
    stranger = [{"event_id": "n2", "league": "nba", "home": "Echo",
                 "away": "Foxtrot", "markets": {}, "model": None}]
    assert elo_model(stranger, history, "nba", min_games=100) == ([], 1)

    # An unknown league has no Elo settings and must not borrow another's.
    assert elo_model(upcoming, history, "cricket", min_games=1) == ([], 0)

    # And the output slots straight into merge_model.
    assert merge_model(upcoming, rated, "elo") == 1
    assert upcoming[0]["model"]["source"] == "elo"

    # The detail block has to carry every field the panel draws, or the
    # panel renders an empty section on a card whose rating merged fine.
    # Named one at a time rather than checked in a loop over the panel,
    # because the whole failure mode is a field nobody remembered to list:
    # home_sp went eight months unlisted and home_bats longer, each of them
    # fetched every morning and displayed never.
    for key in ("home_form", "away_form", "series",
                "home_sp", "away_sp", "home_bats", "away_bats", "venue"):
        assert key in DETAIL_KEYS, f"{key} missing from DETAIL_KEYS"
    rows = [{"event_id": "e1", "league": "mlb",
             "markets": {"h2h": {"fair_home": 0.5}}}]
    rated = [{"event_id": "e1", "home_win_prob": 0.6, "away_win_prob": 0.4,
              "home_form": {"w": 73, "l": 65, "streak": "W1",
                            "l10_w": 5, "l10_l": 5},
              "away_form": {"w": 65, "l": 73, "streak": "L1",
                            "l10_w": 4, "l10_l": 6},
              "venue": "Petco Park",
              "home_bats": [{"name": "Manny Machado", "pa": 14, "ab": 13,
                             "h": 4, "k": 3, "avg": 0.308}],
              "away_bats": [],
              "series": [{"date": "2026-06-08",
                          "away": "Cincinnati Reds", "away_runs": 2,
                          "home": "San Diego Padres", "home_runs": 6}]}]
    assert merge_model(rows, rated, "slate") == 1
    detail = rows[0]["detail"]
    assert detail["home_form"]["streak"] == "W1", detail
    assert detail["series"][0]["home"] == "San Diego Padres", detail["series"]
    assert detail["venue"] == "Petco Park", detail
    assert detail["home_bats"][0]["pa"] == 14, detail["home_bats"]
    # An EMPTY lineup is COPIED -- merge_model filters on "is not None", not
    # on truth, so [] survives. That is fine and is asserted rather than left
    # to chance: _lineup_table returns nothing for an empty list, so the
    # panel draws no section rather than a table with no rows.
    assert detail["away_bats"] == [], detail

    # Leagues with no free standings source take their form from the finals
    # the daily job stores. A league we have stored nothing for leaves the
    # rows untouched rather than attaching an empty block.
    nfl = [{"event_id": "n1", "league": "nfl",
            "home": "Chicago Bears", "away": "Green Bay Packers",
            "markets": {"h2h": {"fair_home": 0.5}}}]
    stored = [
        {"date": "2026-09-06", "away": "Chicago Bears", "away_score": 10,
         "home": "Green Bay Packers", "home_score": 24, "completed": True},
        {"date": "2026-09-13", "away": "Green Bay Packers", "away_score": 13,
         "home": "Chicago Bears", "home_score": 20, "completed": True},
    ]
    assert merge_form(nfl, stored) == 1
    d = nfl[0]["detail"]
    assert d["home_form"]["streak"] == "W1", d["home_form"]
    assert d["away_form"]["w"] == 1
    assert len(d["series"]) == 2
    assert d["series"][0]["home"] == "Green Bay Packers", d["series"]

    empty = [{"event_id": "n2", "league": "nfl", "home": "A", "away": "B",
              "markets": {}}]
    assert merge_form(empty, []) == 0
    assert "detail" not in empty[0], \
        "an empty store attaches nothing rather than an empty panel"

    print("board self-test: all invariants hold")


if __name__ == "__main__":
    _self_test()
