"""Render the site's data-driven pieces as HTML fragments.

Every function here takes plain dicts loaded from data/*.json and returns a
string. No template engine, no dependencies — that keeps the free hosting
story simple and the build instant.
"""
from __future__ import annotations

import math
import html
import re
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

import config          # noqa: E402
import leagues          # noqa: E402
import odds_math as om  # noqa: E402
import i18n             # noqa: E402

BOOK_NOTE = "Odds shown are the price at post time"

# The language of the page currently being rendered. build.py sets it once
# per pass and every string below reads it. A module-level value rather than
# a parameter on twenty signatures: the build is single-threaded and renders
# one language to completion before starting the next, so there is nothing
# for two languages to race over.
LANG = "en"


def set_lang(lang: str) -> None:
    global LANG
    LANG = lang if lang in i18n.LANGS else "en"


def _(key: str, **kw) -> str:
    """Shorthand for a translated string in the current language."""
    return i18n.t(key, LANG, **kw)


def _pl(n: int) -> str:
    return i18n.plural(n, LANG)


def esc(text) -> str:
    return html.escape(str(text), quote=False)


def u(value: float, decimals: int = 2) -> str:
    """Signed unit figure, using a real minus sign."""
    value = round(float(value), decimals)
    sign = "+" if value > 0 else ("−" if value < 0 else "")
    return f"{sign}{abs(value):.{decimals}f}u"


def pct(value: float, decimals: int = 1) -> str:
    value = round(float(value), decimals)
    sign = "+" if value > 0 else ("−" if value < 0 else "")
    return f"{sign}{abs(value):.{decimals}f}%"


def cls_for(value: float) -> str:
    return "g" if value > 0 else ("r" if value < 0 else "")


def game_time(iso: str | None) -> str:
    if not iso:
        return ""
    try:
        from zoneinfo import ZoneInfo
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone(
            ZoneInfo(config.TIMEZONE))
        return f"{dt:%-I:%M %p} ET"
    except Exception:
        return ""


# ------------------------------------------------------------------ play card
# --------------------------------------------------------------------- chips
# -------------------------------------------------------------------- tables
# The tag class is stable; the label is looked up at render time so it
# follows the page's language rather than being frozen at import.
RESULT_CLASS = {"win": "win", "loss": "loss", "push": "push"}
RESULT_KEY = {"win": "res_win", "loss": "res_loss", "push": "res_push"}


def _result_tag(result: str, fallback: str = "&mdash;") -> tuple[str, str]:
    cls = RESULT_CLASS.get(result, "")
    key = RESULT_KEY.get(result)
    return cls, (_(key) if key else fallback)


SOURCE_KEY = {"value": "src_value", "screen": "src_screen"}


def _short_date(play: dict) -> str:
    stamp = play.get("posted_date") or (play.get("commence_time") or "")[:10]
    try:
        return i18n.short_date(datetime.fromisoformat(stamp), LANG)
    except Exception:
        return stamp


# ---------------------------------------------------------------------- KPIs
# --------------------------------------------------------------------- chart
# -------------------------------------------------------------------- signup
# ------------------------------------------------------- screen methodology
# Labels for the screen thresholds. The page renders straight from
# screen_config.py, so the rules shown to readers can never drift from the
# rules the scanner actually applies — a published methodology that quietly
# disagrees with the code is worse than none.
# (label key, comparator key, number format). Both label and comparator are
# i18n keys rather than English text, so the published methodology translates
# with the rest of the page while still coming from screen_config.py.
SCREEN_LABELS = {
    "min_pitcher_k_pct": ("sl_min_pitcher_k_pct", "cmp_at_least", "pct"),
    "min_vs_pa": ("sl_min_vs_pa", "cmp_at_least", "int"),
    "min_vs_k_pct": ("sl_min_vs_k_pct", "cmp_at_least", "pct"),
    "max_vs_avg": ("sl_max_vs_avg", "cmp_under", "three"),
    "max_vs_woba": ("sl_max_vs_woba", "cmp_under", "three"),
    "min_opp_k_per_game": ("sl_min_opp_k_per_game", "cmp_at_least", "two"),
    "line_min": ("sl_line_min", "", "one"),
    "line_max": ("sl_line_max", "", "one"),
    "worst_juice": ("sl_worst_juice", "cmp_no_worse", "odds"),
    "min_k_per_9": ("sl_min_k_per_9", "cmp_at_least", "one"),
    "max_bets_per_day": ("sl_max_bets_per_day", "cmp_at_most", "int"),
    "max_line": ("sl_max_line", "cmp_never", "one"),
    "banned_line": ("sl_banned_line", "cmp_never", "one"),
}


def _fmt_threshold(value, kind: str) -> str:
    if kind == "pct":
        return f"{value * 100:.0f}%"
    if kind == "three":
        return f"{value:.3f}"
    if kind == "two":
        return f"{value:.2f}"
    if kind == "one":
        return f"{value:g}"
    if kind == "odds":
        return om.format_american(value)
    return str(value)


def _breakeven_note(need: float) -> str:
    if need > 0.5:
        return _("be_edge")
    if abs(need - 0.5) < 1e-9:
        return _("be_even")
    return _("be_profit")


# --------------------------------------------------------------- full slate
def _nickname(team: str | None) -> str:
    """'San Diego Padres' -> 'Padres'. Enough to name a side in a tight space."""
    parts = str(team or "").split()
    if not parts:
        return ""
    # Both Chicago and Boston end in "Sox", so the last word alone is ambiguous.
    if len(parts) > 1 and parts[-1].lower() == "sox":
        return " ".join(parts[-2:])
    return parts[-1]


# College leagues name clubs in full; "Tigers" alone is LSU, Auburn,
# Clemson, Memphis, Mizzou...
COLLEGE = ("ncaab", "ncaaf")


def _name(team: str | None, row: dict | None) -> str:
    """How a club is named on a card. College basketball in full -- "Flames"
    is Liberty and UIC, "Panthers" is Pitt, Georgia State, Northern Iowa and
    FIU -- and every other league by nickname, which is unambiguous there."""
    if (row or {}).get("league") in COLLEGE:
        return str(team or "")
    return _nickname(team)


def _record_line(rec: dict | None, at_home: bool) -> str:
    """'78–52 · 44–21 at home'. The venue split is the half that's relevant."""
    if not rec or (rec.get("w", 0) + rec.get("l", 0)) == 0:
        return ""
    overall = f"{rec['w']}&ndash;{rec['l']}"
    if at_home:
        w, l, label = rec.get("hw", 0), rec.get("hl", 0), _("at_home")
    else:
        w, l, label = rec.get("aw", 0), rec.get("al", 0), _("on_the_road")
    # An older stats file carries the overall record without the venue split.
    # Printing "0-0 on the road" beside a real record looks like the number is
    # broken; showing the overall record alone just looks shorter.
    if w + l == 0:
        return f'<div class="grec">{overall}</div>'
    return f'<div class="grec">{overall} &middot; {w}&ndash;{l} {label}</div>'


# Below this many career starts against a club, the split is noise wearing a
# number, and the card says so rather than letting it read as a trend.
THIN_VS_STARTS = 3


def _vs_line(vs: dict | None, opponent: str | None) -> str:
    if not vs:
        return ""
    who = _nickname(opponent) or _("them")
    starts = vs.get("starts") or 0
    # No starts but innings on the board means relief work — saying "0 GS"
    # reads like missing data rather than what it is.
    stint = f'{starts} {_("gs")} &middot; ' if starts else ""
    body = _("vs_body", team=esc(who), stint=stint,
             ip=f"{vs.get('innings', 0):.1f}", ipu=_("ip"),
             era=f"{vs.get('era', 0):.2f}", erau=_("era"))
    span = vs.get("span")
    tip = _("vs_tip", span=(_("span_season", v=span) if span else _("span_career")))
    if starts < THIN_VS_STARTS:
        return (f'<div class="gvs thin" title="{esc(_("vs_tip_thin", tip=tip))}">'
                f'{body} &middot; {_("vs_thin")}</div>')
    return f'<div class="gvs" title="{esc(tip)}">{body}</div>'


def _side(team, starter, era, prob, leading, rec=None, at_home=False,
          vs=None, opponent=None, wl=None) -> str:
    # No starter, no starter line. The old "TBA" was a hardcoded English
    # string — the only reader-facing word on a card not routed through _()
    # — and it is now reached by every Elo league, printing a pitcher slot on
    # a basketball card. slate_rows, the other caller, does not depend on the
    # line being present: .gsp is a margin-top only, so a baseball card whose
    # starter is not yet announced simply closes up. An ERA without a starter
    # cannot be labelled and goes with it.
    sp = f'<div class="gsp">{esc(starter)}' if starter else ""
    if sp:
        # Win-loss sits between the name and the ERA, the order every
        # scoreboard uses. It is display-only: a starter's record is mostly a
        # report on the lineup behind him, which is why the ERA follows it
        # immediately rather than the other way round.
        if wl and wl[0] is not None and wl[1] is not None:
            sp += f' &middot; <span class="gwl">{wl[0]}&ndash;{wl[1]}</span>'
        if era is not None:
            sp += f' &middot; {era:.2f} {_("era")}'
        sp += "</div>"
    # One decimal, not zero: at 49.8 vs 50.2 a rounded pair both read "50%"
    # while the footer reports a lean, which looks like a contradiction.
    # No probability means no model for this game yet — the club's name still
    # gets its slot, but the percentage is left off rather than faked as 0%.
    pc = f'<div class="pc">{prob*100:.1f}%</div>' if prob is not None else ""
    # The model's own EV used to print here. It is still computed and still
    # stored in board.json as ev_home / ev_away, because the record needs to
    # keep accumulating -- but it is not shown, and the reason is in the
    # numbers rather than in taste.
    #
    # On 165 graded games, backing the side the model preferred returned
    # +8.08% where it claimed +13.25% (n=72, se 13.21) on the games it
    # disagreed with the market by four points or more, and -3.03% where it
    # claimed +2.02% (n=93, se 10.45) on the rest. Both are indistinguishable
    # from zero. The win model is level with the market on Brier -- 0.2382
    # against 0.2402, CI [-0.0106, +0.0065] -- and "level with" does not
    # support an EV figure, which is a claim of being better.
    #
    # It also contradicted the page it sat on: the same run that printed
    # +17.9% on a card logged "0 qualifying edges, rejected -- EV below
    # 2.5%: 60". The market edge on the price rows stays, because it
    # compares a book against consensus and needs no model to be right.
    return f"""
        <div class="gside{' lead' if leading else ''}">
          <div class="tm">{_tdot(team)}{esc(team or '')}</div>
          {pc}
        </div>
        {_record_line(rec, at_home)}
        {sp}
        {_vs_line(vs, opponent)}"""


def _abbr(team: str | None) -> str:
    """MIL, CHC, NYY. Falls back to the nickname when a club isn't listed."""
    return TEAM_ABBR.get(_nickname(team).lower()) or _nickname(team).upper()[:3]


def _short_name(name: str | None) -> str:
    """'Freddy Peralta' -> 'F. Peralta'. A card has room for a surname."""
    parts = str(name or "").split()
    if len(parts) < 2:
        return parts[0] if parts else "TBA"
    return f"{parts[0][0]}. {' '.join(parts[1:])}"


def slate_rows(rows: list[dict]) -> str:
    """One card per game: both clubs, both numbers, the market's tick.

    Showing only our side of the number and abbreviating the clubs made the
    card shorter but cost the two things a reader actually compares — who is
    playing, and how far apart the two opinions are. Both sides are named in
    full and both percentages are printed; the bar carries the market's own
    number as a tick so the gap is visible without arithmetic.
    """
    if not rows:
        return f'<div class="empty-board">{_("empty_board")}</div>'
    out = []
    for r in rows:
        ph = r.get("home_win_prob") or 0.0
        pa = 1.0 - ph
        mkt_home = r.get("market_home_prob")
        gap = r.get("disagreement")
        suspect = bool(r.get("suspect"))
        home, away = r.get("home"), r.get("away")

        # The bar reads left-to-right as the away club's chance, so the
        # market's tick has to be expressed on that same side.
        tick = ("" if mkt_home is None else
                f'<div class="tick" style="left:{max(0.0, min(100.0, (1 - mkt_home) * 100)):.1f}%" '
                f'title="{_("market_tick")}"></div>')

        if mkt_home is None:
            foot_left = f'<span>{_("market_na")}</span>'
        else:
            # Name the club the market makes the favourite, rather than a bare
            # percentage the reader has to attach to a side themselves.
            fav, fav_pct = ((home, mkt_home) if mkt_home >= 0.5
                            else (away, 1 - mkt_home))
            foot_left = (f'<span>' + _("market_fav", pct=f"<b>{fav_pct * 100:.1f}%</b>",
                                        team=esc(_nickname(fav))) + '</span>')

        if gap is None:
            foot_right = ""
        elif suspect:
            foot_right = (f'<span class="flagged">'
                          f'{_("off_market", v=f"{abs(gap):.1f}")}</span>')
        elif abs(gap) < 1.0:
            # Under a point the two numbers are the same number wearing
            # different rounding. Calling that a lean would be noise.
            foot_right = f'<span>{_("in_line")}</span>'
        else:
            side = home if gap > 0 else away
            foot_right = ('<span class="lean">'
                          + _("lean_on", v=f"+{abs(gap):.1f}", team=esc(_nickname(side)))
                          + '</span>')

        when = esc(game_time(r.get("commence_time")) or "")
        # The left of the header already carries the start time. Repeating it
        # on the right for an ungraded game reads as a rendering fault, so the
        # right side says what state the game is in instead.
        final = (f'<span class="fin">{_("final", v=esc(r["final"]))}</span>'
                 if r.get("final") else
                 f'<span style="color:var(--muted)">{_("scheduled")}</span>')

        accent = team_color(home) or "var(--line-2)"
        out.append(f"""
        <div class="gcard{' flag' if suspect else ''}" style="--accent:{accent}">
          <div class="gcard-top">
            <span>{when}</span>
            {final}
          </div>
          <div class="gcard-body">
            {_side(away, r.get('away_starter'), r.get('away_starter_era'), pa,
                   pa > ph, r.get('away_record'), False,
                   r.get('away_vs_opp'), home)}
            <div class="gbar">
              <div class="seg on" style="left:0;width:{max(0.0, min(100.0, pa * 100)):.1f}%"></div>
              <div class="seg" style="left:{max(0.0, min(100.0, pa * 100)):.1f}%;right:0"></div>
              {tick}
            </div>
            {_side(home, r.get('home_starter'), r.get('home_starter_era'), ph,
                   ph >= pa, r.get('home_record'), True,
                   r.get('home_vs_opp'), away)}
            <div class="gfoot">
              {foot_left}
              {foot_right}
            </div>
          </div>
        </div>""")
    return "".join(out)


# The calibration plot is drawn on a fixed window so every row shares a scale
# and the dots line up down the page.
CALIB_LO, CALIB_HI = 25.0, 85.0


def _cpos(value: float) -> float:
    return max(0.0, min(100.0, (value - CALIB_LO) / (CALIB_HI - CALIB_LO) * 100))


def calibration_rows(rows: list[dict]) -> str:
    live = [r for r in rows if r.get("n")]
    if not live:
        return f'<div class="empty-board">{_("cal_empty")}</div>' 
    import math as _m
    out = []
    for r in live:
        gap, n = r["gap"], r["n"]
        said, actual = r["predicted"], r["actual"]
        # Within the noise band for this sample size, a gap means nothing.
        se = _m.sqrt(0.25 / n) * 100 * 1.96
        outside = abs(gap) > se
        verdict = (_("within_noise") if not outside else
                   (_("too_low") if gap > 0 else _("too_high")))
        band_l, band_r = _cpos(said - se), _cpos(said + se)
        label = (f"{r['lo']*100:.0f}%+" if r["hi"] > 1.0
                 else f"{r['lo']*100:.0f}–{r['hi']*100:.0f}%")
        out.append(f"""
        <div class="crow">
          <div class="cl">{label}</div>
          <div class="cn">{_("cal_games", n=n)}</div>
          <div class="ctrack" title="{_("cal_tip", a=f"{said:.1f}", b=f"{actual:.1f}")}">
            <div class="cband" style="left:{band_l:.1f}%;width:{max(0.0, band_r-band_l):.1f}%"></div>
            <div class="csaid" style="left:{_cpos(said):.1f}%"></div>
            <div class="cact{' out' if outside else ''}" style="left:{_cpos(actual):.1f}%"></div>
          </div>
          <div class="cverdict{' out' if outside else ''}">{esc(verdict)}<br>
            <span style="color:var(--muted)">{_("said_won", a=f"{said:.1f}", b=f"{actual:.1f}")}</span></div>
        </div>""")
    return "".join(out)


def calibration_section(summary: dict) -> str:
    """A league board's own calibration, or nothing at all.

    Returns the empty string until the league has a graded rating. An empty
    chart under the heading "Are we calibrated?" reads as a claim that we
    looked and found nothing, which is not the same as not having looked
    yet -- and in the opening weeks of a season it would be on every board.
    """
    if not (summary or {}).get("graded"):
        return ""
    return (
        f'<section class="pad-sm" id="calibration"><div class="wrap">'
        f'<div class="sec-head" style="margin-bottom:26px">'
        f'<div class="eyebrow">{_("cal_eyebrow")}</div>'
        f'<h2 style="font-size:26px;margin-top:10px">{_("cal_head")}</h2>'
        f'<p class="lead" style="margin-top:12px">{_("cal_lead")}</p></div>'
        f'<div class="calib">{calibration_rows(summary.get("calibration") or [])}</div>'
        f'<div class="clegend">'
        f'<span><i class="key-line"></i> {_("cal_said")}</span>'
        f'<span><i class="key-dot"></i> {_("cal_happened")}</span>'
        f'<span><i class="key-band"></i> {_("cal_band")}</span></div>'
        f'<div class="note" style="margin-top:26px">'
        f'<p class="disclaimer">{brier_line(summary)}</p>{_ats_line(summary)}</div>'
        f'</div></section>')


def _ats_line(summary: dict) -> str:
    """Our side against the closing spread, once any pick has been graded."""
    w, l, p = (summary or {}).get("ats") or [0, 0, 0]
    if not (w or l or p):
        return ""
    rec = f"{w}-{l}" + (f"-{p}" if p else "")
    return f'<p class="sys-rec" style="margin-top:12px"><b>{_("cal_ats", r=rec)}</b></p>'


def brier_line(summary: dict) -> str:
    ours, theirs = summary.get("brier"), summary.get("market_brier")
    if ours is None:
        return _("brier_empty")
    text = _("brier_main", n=summary.get("graded", 0), v=f"{ours:.4f}")
    if theirs is not None:
        rel = ("rel_better" if ours < theirs
               else ("rel_worse" if ours > theirs else "rel_level"))
        text += _("brier_market", v=f"{theirs:.4f}",
                  n=summary.get("market_compared", 0), rel=_(rel))
    return text


# ----------------------------------------------------------- pitchers prop
# The bar strip stays anchored at zero. Zooming the axis would make small
# differences look big, which is the opposite of what this page argues.
PITCH_MAX_K = 14


def _ordinal(n: int) -> str:
    if 10 <= n % 100 <= 20:
        return "th"
    return {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")


def _k_tip(game: dict, value) -> str:
    """The pitcher strip's tooltip, translated. Kept out of _strip so the
    generic version does not have to know what an inning is."""
    return _("pb_tip", when=esc(game.get("date") or ""),
             opp=esc(game.get("opponent") or ""), k=value,
             ip=game.get("innings", 0))


def _strip(recent: list[dict], line: float, *, key: str = "strikeouts",
           scale: float | None = None, label: str | None = None,
           fmt=None, tip=None) -> str:
    """The run of recent games, as bars against a reference line.

    Written for the pitcher board and now shared with the NFL boards, so
    the two things that were baked in are arguments: which field on a row
    holds the number, and what the y-axis tops out at. A yardage strip
    cannot use PITCH_MAX_K, and a touchdown strip's reference is half a
    touchdown rather than a posted price.

    `scale` defaults to whatever makes the tallest bar fill the box, with
    the reference line kept inside it -- a fixed ceiling works for
    strikeouts because they have a natural range and does not for yards.
    """
    if not recent:
        return f'<div class="pb-nostrip">{_("no_starts")}</div>' 
    fmt = fmt or (lambda v: f"{v:g}")
    vals = [(g.get(key) or 0) for g in recent]
    if scale is None:
        scale = max(max(vals), line) * 1.15 or 1.0
    bars, ticks = [], []
    for g, v in zip(recent, vals):
        h = max(6.0, min(100.0, v / scale * 100))
        when = esc(g.get("date") or (f'W{g.get("week")}' if g.get("week") else ""))
        opp = esc(g.get("opponent") or "")
        title = (tip(g, v) if tip
                 else f"{when} {opp} &middot; {fmt(v)}".strip())
        bars.append(f'<div class="pb-bar{" hit" if v > line else ""}" '
                    f'style="height:{h:.1f}%" '
                    f'title="{title}"></div>')
        ticks.append(f"<span>{fmt(v)}</span>")
    pos = max(0.0, min(100.0, line / scale * 100))
    lab = label if label is not None else f"{line:g}"
    return f"""
      <div class="pb-strip">
        <div class="pb-line" style="bottom:{pos:.1f}%"><span class="pb-linelab">{lab}</span></div>
        {''.join(bars)}
      </div>
      <div class="pb-ticks">{''.join(ticks)}</div>"""


def _roster_block(row: dict, who: str, team: str) -> str:
    """PA, K%, AVG, xwOBA against tonight's lineup.

    First in the panel, above the vs-opponent block, because it is the
    wider sample: a whole roster's career against this arm, rather than the
    two or three starts he has made against the club.

    The prose that used to sit under this grid is gone -- twice asked for
    and twice justified, which is one more time than a caveat gets. What it
    was protecting is real: xwOBA here often rests on twenty-odd plate
    appearances and a three-decimal number reads as precision when it is
    noise. So the protection stays, as DATA rather than as a paragraph --
    the xwOBA denominator prints as a mono caption, and a thin sample still
    dims the whole grid. A reader who wants to know the sample size can
    read the PA cell, which is the first thing on the row.
    """
    rs = row.get("vs_roster")
    if not rs or not rs.get("pa"):
        return ""

    def three(v):
        return f"{v:.3f}".lstrip("0") if v is not None else "&mdash;"

    k_txt = f'{rs["k_pct"] * 100:.1f}%' if rs.get("k_pct") is not None else "&mdash;"
    # The one thing the grid cannot say for itself: xwOBA's denominator is
    # not the PA cell beside it. StatsAPI gives the career line, Savant the
    # Statcast rows, and the two rarely cover the same plate appearances.
    cap = ""
    if rs.get("xwoba") is not None:
        cap = (f'<div class="mxcap">{_("rs_xwoba")} &middot; '
               f'{esc(rs.get("xwoba_span") or "")} &middot; '
               f'{format(rs.get("xwoba_pa") or 0, ",")} {_("rs_pa")}</div>')

    thin = ' dim' if rs.get("thin") else ''
    return (f'<div class="mxh">{_("rs_head", who=who, team=team)}</div>'
            f'<div class="mxg four{thin}">'
            f'<div><span>{_("rs_pa")}</span><b>{format(rs["pa"], ",")}</b></div>'
            f'<div><span>{_("rs_kpct")}</span><b>{k_txt}</b></div>'
            f'<div><span>{_("rs_avg")}</span><b>{three(rs.get("avg"))}</b></div>'
            f'<div><span>{_("rs_xwoba")}</span><b>{three(rs.get("xwoba"))}</b></div>'
            f'</div>{cap}')


def _matchup_inner(row: dict) -> str:
    """The prop card's collapsible detail.

    Three things, in this order: how this starter has done against this
    opponent, how that opponent strikes out against the hand he throws with,
    and the verdict. Only the applicable hand is shown -- printing both
    columns made the reader do the selection the card already knows how to do.
    """
    who = esc((row.get("name") or "").split()[-1] or "?")
    team = esc(_nickname(row.get("opponent")))
    parts = []

    # The roster line leads: it rests on hundreds of plate appearances where
    # the vs-opponent line below often rests on two starts.
    block = _roster_block(row, who, team)
    if block:
        parts.append(block)

    vs = row.get("vs_opp")
    if vs and vs.get("innings"):
        k9 = vs["strikeouts"] * 9 / vs["innings"]
        parts.append(
            f'<div class="mxh">'
            f'{_("mx_hist", who=who, team=team, span=esc(vs.get("span", "")))}'
            f'</div>'
            f'<div class="mxg">'
            f'<div><span>{_("mx_starts")}</span><b>{vs["starts"]}</b></div>'
            f'<div><span>{_("mx_innings")}</span><b>{vs["innings"]:g}</b></div>'
            f'<div><span>{_("mx_k")}</span><b>{vs["strikeouts"]}</b></div>'
            f'<div><span>{_("mx_k9")}</span><b>{k9:.1f}</b></div>'
            f'<div><span>{_("mx_era")}</span><b>{vs["era"]:.2f}</b></div>'
            f'</div>')
        # No sentence restating K/9 against them versus K/9 all season --
        # both numbers are already in the grid above, one of them twice.
        # A thin sample dims the grid instead of being narrated.
    else:
        parts.append(f'<div class="mxh">{_("mx_never", who=who, team=team)}</div>')

    split = row.get("opp_split")
    hand = row.get("hand") or ""
    if split and hand:
        row_label = _("mx_vs_l") if hand == "L" else _("mx_vs_r")
        rank = split.get("rank")
        of = split.get("of")
        # Every value is formatted before it enters the f-string. Python 3.11
        # cannot reuse the outer quote character inside an f-string
        # expression, so a nested f'{split["pa"]:,}' is a syntax error on the
        # runner even though it parses on 3.12.
        rank_cell = (_("pb_rank", r=rank, ord=_ordinal(rank), n=of)
                     if rank and of else "")
        pa_txt = format(split["pa"], ",")
        pct_txt = f'{split["k_pct"]:.1f}'
        mean_txt = f'{split.get("league_mean") or 0.0:.1f}'
        # The paragraph that used to explain which hand applies, and how the
        # club's overall rank compares with its rank against that hand, is
        # gone. The row is already labelled "vs right-handers", the rank is
        # already in the row, and the verdict chip below already prints the
        # gap against the league. It was three ways of saying one number.
        parts.append(
            f'<div class="mxh">{_("mx_how", team=team)}</div>'
            f'<table class="mxt">'
            f'<tr class="on"><th>{row_label}</th>'
            f'<td class="n">{pct_txt}%</td>'
            f'<td class="r">{rank_cell}</td>'
            f'<td class="p">{_("mx_pa", n=pa_txt)}</td></tr>'
            f'<tr class="avg"><th>{_("mx_league")}</th>'
            f'<td class="n">{mean_txt}%</td>'
            f'<td class="r"></td><td class="p"></td></tr>'
            f'</table>')

    verdict = row.get("matchup") or "neutral"
    delta = ""
    if split and split.get("league_mean") is not None:
        gap = split["k_pct"] - split["league_mean"]
        delta = f'<span class="vd">{_("mx_delta", v=f"{gap:+.1f}")}</span>'
    return (f'<div class="mxb">{"".join(parts)}</div>'
            f'<div class="verdict {MX_CLASS[verdict]}">'
            f'{_(MX_LABEL[verdict])}{delta}</div>')


# The axis every row on the list board is drawn against. One axis for the
# whole board rather than one per row: the point of a list is that fifteen
# bars are comparable, and a bar scaled to its own line moves the tick from
# row to row and makes them incomparable.
#
# Nine is the design doc's number and holds for almost every slate. It is a
# floor, not a fixed value, because a pegged bar is a lie -- an eleven-K
# projection drawn at 100% would read as the same call as a nine.
PL_AXIS_MIN = 9.0


def _pl_axis(rows) -> float:
    top = max([r.get("projection") or 0 for r in rows]
              + [r.get("line") or 0 for r in rows] + [0.0])
    return max(PL_AXIS_MIN, math.ceil(top))


def _pl_fixture(r: dict) -> tuple:
    away, home = _mlb_sides(r)
    return (r.get("commence_time") or "", frozenset({away, home}))


def _pl_edge(r: dict):
    """The number the list is sorted by, or None when there is nothing to sort.

    A starter with no posted line has no edge -- not a zero one. Returning
    None keeps him out of the sort's arithmetic and sinks him to the foot
    with the settled rows, which is where an unpriced projection belongs on
    a board whose headline is disagreement with the market.
    """
    gap = r.get("gap")
    if r.get("line") is None or gap is None or abs(gap) < 0.4:
        return None
    return gap


def board_head_meta(date_label: str, rows: list[dict]) -> str:
    """The board header's one meta line: the date, then what is on the board.

    Sentence case, not the wide-tracked uppercase mono this used to be. A
    date is a sentence; the design doc's rule is that caps and tracking
    belong to labels of a couple of words, and "Wednesday, September 9,
    2026" set in .16em uppercase mono was the single ugliest line on the
    site.
    """
    n = pitcher_head(rows)
    parts = [esc(date_label)]
    if rows:
        parts.append(_("bh_props", n=n["props"]))
        parts.append(_("bh_games", n=n["games"]))
    return " &middot; ".join(parts)


# ---------------------------------------------------------- the hit strip
# Seven steps, black at exactly 50%. The midpoint is deliberately colourless:
# a coin flip is not a signal, and tinting it would put a colour on every row
# whether or not there is anything to see. Taken from Outlier's prop grid,
# recoloured to this site's own green and red.
HIT_BANDS = ((0.80, "h3"), (0.66, "h2"), (0.5001, "h1"), (0.4999, "mid"),
             (0.30, "l1"), (0.15, "l2"), (0.0, "l3"))


def hit_band(pct: float | None) -> str:
    if pct is None:
        return "na"
    for floor, name in HIT_BANDS:
        if pct >= floor:
            return name
    return "l3"


def hit_rate(recent: list[dict], threshold: float | None, n: int,
             key: str) -> tuple[float | None, int, int]:
    """How often the last `n` games cleared `threshold`. (pct, cleared, of)."""
    if threshold is None:
        return None, 0, 0
    got = [g for g in (recent or [])[-n:] if g.get(key) is not None]
    if not got:
        return None, 0, 0
    over = sum(1 for g in got if float(g[key]) > float(threshold))
    return over / len(got), over, len(got)


def implied_prob(odds) -> float | None:
    """The market's own number, before anyone's model touches it."""
    if odds is None:
        return None
    o = float(odds)
    return (-o) / (-o + 100) if o < 0 else 100 / (o + 100)


def hit_strip(recent, threshold, *, key, odds=None, priced=True,
              spans=(5, 10)) -> str:
    """L5 / L10 against the line, then what the market says about it.

    The raw fraction is printed beside the percentage on purpose. "100%" off
    three starts and "100%" off ten are the same number and nothing like the
    same claim, and a board that shows only the percentage invites the reader
    to treat them alike.

    The last cell is the market's own implied probability, and it appears
    only where a price exists -- which is the comparison this whole site is
    about. There is deliberately no cell naming the number the percentages
    were measured against: that number is the posted line printed under the
    bar, or our projection printed in the rail beside it, and a third copy of
    a figure already twice on screen is clutter, not context.
    """
    # No games, no strip. A row of em-dashes looks like a player who has
    # done nothing rather than one we have no log for, and that is the same
    # lie the strip exists to avoid telling.
    if not recent:
        return ""
    cells = []
    for n in spans:
        pct, over, of = hit_rate(recent, threshold, n, key)
        body = (f'{pct * 100:.0f}% <u>({over}/{of})</u>' if pct is not None
                else "&mdash;")
        cells.append(f'<span class="hr {hit_band(pct)}">'
                     f'<i>{_("hr_last", n=n)}</i>{body}</span>')
    prob = implied_prob(odds) if priced else None
    if prob is not None:
        cells.append(f'<span class="hr mkt"><i>{_("hr_market")}</i>'
                     f'{prob * 100:.0f}%</span>')

    return f'<div class="hrs">{"".join(cells)}</div>' if cells else ""


def pitcher_head(rows: list[dict]) -> dict:
    """The three counts the board's header prints, as a dict of strings."""
    games = {_pl_fixture(r) for r in rows}
    edges = sum(1 for r in rows if _pl_edge(r) is not None
                and r.get("actual") is None)
    return {"props": str(len(rows)), "games": str(len(games)),
            "edges": str(edges)}


def pitcher_cards(rows: list[dict]) -> str:
    """Every probable starter as one row of a list, biggest edge first.

    Rewritten from a grid of cards after the design pass. The cards were
    honest but expensive: a phone showed two of them, most of that height
    spent on a disclosure button and a projection set at display size, and
    the reader's actual question -- where does our number disagree with the
    market tonight -- took a scroll per starter to answer.

    A list answers it in one screen. The edge moves to a fixed right rail
    in colour and size, the board sorts by it, and settled and unpriced
    rows sink to the foot dimmed. Nothing is lost: every card's panel is
    still here, one tap away, because the row IS the summary of a
    <details> rather than a card with a button in it.

    The fixture stays on every row's meta line and the picker above still
    filters by game, so the grouping asked for on the NFL boards is kept
    without spending a heading and a grid on each of eleven fixtures.
    """
    if not rows:
        return f'<div class="empty-board">{_("pitch_empty")}</div>'

    # The picker's chips, built from the same fixture key the rows carry, so
    # a chip and its rows cannot disagree about what a game is.
    order = sorted({_pl_fixture(r) for r in rows},
                   key=lambda g: (g[0], str(sorted(g[1]))))
    slug = {g: f"g{i}" for i, g in enumerate(order)}

    axis = _pl_axis(rows)

    def row(r):
        line = r.get("line")
        proj = r.get("projection") or 0
        gap = r.get("gap")
        reference = r.get("reference")
        if reference is None:
            reference = line if line is not None else proj
        actual = r.get("actual")
        settled = actual is not None
        edge = _pl_edge(r)

        # Colour says one thing: which way we disagree, and only when we do.
        # A settled row is grey whatever it once said -- it is a result now,
        # not a call, and leaving it green would put six loud rows on a
        # board whose live section is the part anyone can act on.
        # Prefixed, every one of them. "up" on its own is a utility class in
        # base.css -- mono, 11px, letterspaced caps -- so `class="pl up"` set
        # the whole positive-edge row in uppercase mono. It shipped invisible
        # because the board that morning was entirely settled rows, and would
        # have appeared the first time a priced edge did.
        if settled:
            tone = "pl-done"
        elif edge is None:
            tone = "pl-none"
        elif edge > 0:
            tone = "pl-up"
        else:
            tone = "pl-down"

        fill = max(0.0, min(100.0, proj / axis * 100))
        tick = (max(0.0, min(100.0, line / axis * 100))
                if line is not None else None)
        tick_html = (f'<i class="pl-tick" style="left:{tick:.1f}%"></i>'
                     if tick is not None else "")

        # The verdict moves onto the row. It was behind the disclosure, which
        # meant checking ten starters cost ten taps to read one word each.
        verdict = r.get("matchup")
        mx = (f'<i class="mxb {MX_CLASS.get(verdict, "")}">'
              f'{_(MXB_LABEL[verdict])}</i>' if verdict in MXB_LABEL else "")

        if settled:
            went = _("over") if actual > reference else _("under")
            badge_txt = _("final_k", n=actual, side=went)
            hit = (actual > reference) == (edge is not None and edge > 0)
            badge = (f'<i class="pl-badge {"hit" if hit and edge is not None else "miss"}">'
                     f'{badge_txt}</i>')
        elif r.get("suspect"):
            badge = f'<i class="pl-badge flag" title="{_("pb_flagtip")}">{_("pb_flag")}</i>'
        else:
            badge = ""

        if edge is None:
            edge_n, edge_lab = "&mdash;", (_("pl_settled") if settled
                                          else (_("cv_noedge") if line is not None
                                                else _("pl_noline")))
        else:
            edge_n = f"+{edge:.1f}" if edge > 0 else f"&minus;{abs(edge):.1f}"
            edge_lab = _("over") if edge > 0 else _("under")

        # Nothing in the middle when there is no line: the right rail
        # already says so, and printing it twice made the row read as
        # though the absence were the finding.
        scale_mid = f'{_("pl_line")} {line:g}' if line is not None else ""
        strip = hit_strip(r.get("recent"), reference, key="strikeouts",
                          odds=r.get("over_odds"), priced=line is not None)

        away, home = _mlb_sides(r)
        meta = (f'{esc(_nickname(away))} @ {esc(_nickname(home))} '
                f'&middot; {_("pl_ks")}'
                if away and home
                else f'{esc(_nickname(r.get("team","")))} &middot; {_("pl_ks")}')

        return (
            f'<details class="pl {tone}" data-game="{slug[_pl_fixture(r)]}"'
            f' data-edge="{0 if edge is None or settled else 1}"'
            f' data-close="{_("close")}">'
            f'<summary class="pl-row">'
            f'<div class="pl-main">'
            f'<div class="pl-name"><span>{esc(r.get("name",""))}</span>{mx}</div>'
            f'<div class="pl-meta"><span>{meta}</span>{badge}</div>'
            f'<div class="pl-bar"><i class="pl-fill" style="width:{fill:.1f}%"></i>'
            f'{tick_html}</div>'
            f'<div class="pl-scale"><span>0</span><span>{scale_mid}</span>'
            f'<span>{axis:g}</span></div>'
            f'{strip}'
            f'</div>'
            f'<div class="pl-edge"><b>{edge_n}</b><span>{edge_lab}</span>'
            f'<em>{proj:.1f}<i>{_("k_unit")}</i></em></div>'
            f'</summary>'
            f'<div class="gmore-in"><div class="pnl">{_pl_panel(r, reference)}'
            f'{_matchup_inner(r)}</div></div>'
            f'</details>')

    # Biggest disagreement first; unpriced and settled rows sink. Ties break
    # on first pitch so the order is stable from one build to the next.
    def sort_key(r):
        edge = _pl_edge(r)
        return (r.get("actual") is not None,
                edge is None,
                -abs(edge) if edge is not None else 0.0,
                r.get("commence_time") or "", r.get("name") or "")

    chips = [f'<a href="#" class="gchip on" data-filter="all">'
             f'{_("pl_all", n=len(rows))}</a>']
    # No edges tonight, no chip. A filter that empties the board and says
    # nothing about why reads as a broken page; on a morning when no props
    # were bought that would be every morning.
    if any(_pl_edge(r) is not None and r.get("actual") is None for r in rows):
        chips.append(f'<a href="#" class="gchip" data-filter="edges">'
                     f'{_("pl_edgesonly")}</a>')
    for g in order:
        away, home = _mlb_sides([r for r in rows if _pl_fixture(r) == g][0])
        label = (f"{_nickname(away)} @ {_nickname(home)}"
                 if away and home else (away or home))
        chips.append(f'<a href="#" class="gchip" data-game="{slug[g]}">'
                     f'{esc(label)}</a>')

    body = "".join(row(r) for r in sorted(rows, key=sort_key))
    return (f'<nav class="gsel" aria-label="{_("nfl_pickgame")}">'
            + "".join(chips) + '</nav><div class="pl-list">' + body + '</div>')


def _pl_panel(r: dict, reference: float) -> str:
    """What used to be behind the card's disclosure, unchanged in content."""
    line = r.get("line")
    proj = r.get("projection") or 0
    gap = r.get("gap")
    prices = []
    if r.get("over_odds") is not None:
        prices.append(f"o{om.format_american(r['over_odds'])}")
    if r.get("under_odds") is not None:
        prices.append(f"u{om.format_american(r['under_odds'])}")
    if line is None:
        lean = ""
    elif r.get("suspect"):
        lean = (f'<span class="flagged" title="{_("pb_flagtip")}">'
                f'{_("off_the_line", v=f"{abs(gap or 0):.1f}")}</span>')
    elif gap is None or abs(gap) < 0.4:
        lean = f'<span>{_("in_line")}</span>'
    else:
        key = "over_the_line" if gap > 0 else "under_the_line"
        lean = f'<span class="lean">{_(key, v=f"{abs(gap):.1f}")}</span>'
    price_sec = (
        f'<section class="pk"><h4>{_("pnl_prices")}</h4>'
        f'<div class="pb-foot"><span>{esc(" / ".join(prices)) or "&mdash;"}</span>'
        f'{lean}</div></section>') if line is not None else ""

    rank = r.get("opp_k_rank")
    rank_txt = (" &middot; " + _("pb_rank", r=rank, ord=_ordinal(rank),
                                 n=r.get("opp_teams_ranked", 30))
                if rank else "")
    opp_rate = r.get("opp_k_per_game")
    over_label = (_("over_line", v=f"{line:g}") if line is not None
                  else _("cv_clears", v=f"{proj:.1f}"))
    return (
        price_sec +
        f'<section class="pk"><h4>{_("last_n_starts", n=r.get("recent_n", 0))}</h4>'
        f'<div class="pb-striphead"><span></span>'
        f'<span class="pb-rec"><b>{r.get("recent_over",0)}&ndash;'
        f'{max(0,(r.get("recent_n",0)-r.get("recent_over",0)))}</b> '
        f'{over_label} &middot; {_("l5")} '
        f'<b>{r.get("last5_over",0)}&ndash;'
        f'{max(0,(r.get("last5_n",0)-r.get("last5_over",0)))}</b>'
        f'</span></div>'
        f'{_strip(r.get("recent") or [], reference, scale=PITCH_MAX_K, tip=_k_tip)}</section>'
        f'<section class="pk"><h4>{_("season")}</h4>'
        f'<div class="pb-rows">'
        f'<div class="pb-row"><span>{_("season")}</span><b>{_season_line(r)}</b></div>'
        f'<div class="pb-row"><span>'
        f'{_("opp_ks", team=esc(_nickname(r.get("opponent"))))}</span>'
        f'<b>{_("per_game", v=f"{opp_rate:.1f}") if opp_rate else "&mdash;"}'
        f'{rank_txt}</b></div></div></section>')


def _wl_tag(r: dict) -> str:
    """A starter's win-loss beside his name, the way a scoreboard prints it.

    Display-only. Cleveland's Bibee is 5-14 with a 3.88 ERA, which is the
    whole reason this number never reaches the projection.
    """
    w, l = r.get("w"), r.get("l")
    if w is None or l is None:
        return ""
    return f' <span class="pb-wl">{w}&ndash;{l}</span>'


def _season_line(r: dict) -> str:
    bits = []
    if r.get("k_pct") is not None:
        bits.append(_("k_rate", v=f"{r['k_pct']*100:.1f}"))
    if r.get("k_per_9") is not None:
        bits.append(f"{r['k_per_9']:.1f} K/9")
    if r.get("era") is not None:
        bits.append(f"{r['era']:.2f} {_('era')}")
    return " &middot; ".join(bits) or "&mdash;"


def pitcher_accuracy(summary: dict) -> str:
    """How far off the projections have been, against the line's own miss."""
    mae, line_mae = summary.get("mae"), summary.get("line_mae")
    if mae is None:
        return _("pa_empty")
    n = summary.get("graded", 0)
    text = _("pa_main", n=n, noun=_("pa_noun_one" if n == 1 else "pa_noun_many"),
             mae=f"{mae:.2f}", lmae=f"{line_mae:.2f}")
    if line_mae is not None:
        text += _("pa_closer") if mae < line_mae else _("pa_line_closer")
    called = summary.get("called_right")
    if called is not None:
        text += _("pa_called", n=summary.get("calls", 0), v=f"{called:.1f}")
    return text


def pitcher_bucket_rows(summary: dict) -> str:
    buckets = [b for b in summary.get("buckets", []) if b.get("n")]
    if not buckets:
        return f'<div class="empty-board">{_("pb_empty")}</div>' 
    import math as _m
    out = []
    for b in buckets:
        n, pct_right = b["n"], b["pct"]
        se = _m.sqrt(0.25 / n) * 100 * 1.96
        noise = abs(pct_right - 50.0) <= se
        if noise:
            verdict = _("within_noise")
        else:
            verdict = _("better_coin") if pct_right > 50 else _("worse_coin")
        width = max(0.0, min(100.0, pct_right))
        out.append(f"""
        <div class="crow">
          <div class="cl">{esc(_(b["id"]) if b.get("id") else b.get("label", ""))}</div>
          <div class="cn">{_("n_starts", n=n, s=_pl(n))}</div>
          <div class="ctrack" title="{_("bucket_tip", a=b['right'], b=n)}">
            <div class="cband" style="left:{max(0.0,50-se):.1f}%;width:{min(100.0,2*se):.1f}%"></div>
            <div class="csaid" style="left:50%"></div>
            <div class="cact{'' if noise else ' out'}"
                 style="left:{width:.1f}%"></div>
          </div>
          <div class="cverdict{'' if noise else ' out'}">{esc(verdict)}<br>
            <span style="color:var(--muted)">{_("pct_right", v=f"{pct_right:.0f}")}</span></div>
        </div>""")
    return "".join(out)


# ------------------------------------------------------------ team colour
# One primary per club, used only for a 2px card edge and a small dot beside
# the name. Keyed on the last word of the feed's team name, which is what
# _nickname() already returns, so a name the feed spells differently simply
# falls through to the neutral default instead of breaking.
TEAM_COLOR = {
    "diamondbacks": "#A71930", "braves": "#CE1141", "orioles": "#DF4601",
    "red sox": "#BD3039", "cubs": "#0E3386", "white sox": "#C4CED4",
    "reds": "#C6011F", "guardians": "#00385D", "rockies": "#33006F",
    "tigers": "#0C2340", "astros": "#EB6E1F", "royals": "#004687",
    "angels": "#BA0021", "dodgers": "#005A9C", "marlins": "#00A3E0",
    "brewers": "#12284B", "twins": "#002B5C", "mets": "#FF5910",
    "yankees": "#1C2841", "athletics": "#003831", "phillies": "#E81828",
    "pirates": "#FDB827", "padres": "#2F241D", "giants": "#FD5A1E",
    "mariners": "#005C5C", "cardinals": "#C41E3A", "rays": "#8FBCE6",
    "rangers": "#003278", "jays": "#134A8E", "nationals": "#AB0003",
}


# Some clubs wear a colour that all but disappears against the card. Rather
# than hand-picking substitutes and getting it subtly wrong, every colour is
# moved away from the card until it clears a contrast floor; clubs already
# legible are returned untouched. Which way "away" points depends on the card,
# so the panel colour is read from the palette rather than written out again
# here — two copies of one colour is how the bar tick ended up white on a
# white card. On the slate palette three clubs move: the White Sox' silver,
# the Pirates' gold and the Rays' light blue.
def _panel_rgb() -> tuple[int, int, int]:
    css = (Path(__file__).resolve().parent / "base.css").read_text(encoding="utf-8")
    m = re.search(r":root\s*\{.*?--panel\s*:\s*(#[0-9A-Fa-f]{6})", css, re.S)
    value = m.group(1) if m else "#FFFFFF"
    return tuple(int(value[i:i + 2], 16) for i in (1, 3, 5))


PANEL_RGB = _panel_rgb()
MIN_CONTRAST = 2.6


def _luminance(rgb) -> float:
    def channel(v):
        v /= 255.0
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (channel(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _contrast(a, b) -> float:
    la, lb = _luminance(a), _luminance(b)
    lo, hi = sorted((la, lb))
    return (hi + 0.05) / (lo + 0.05)


def _legible(hex_color: str) -> str:
    """Move a club's colour away from the card until it is legible on it.

    Which way is "away" depends on the card. On a dark panel the colour is
    lifted toward white; on a white one it is pushed toward black. The earlier
    version only ever lifted, because it was written when the panel was
    #101317 — run against a white card it made the palest clubs paler still.

    Does not preserve hue exactly. Mixing toward black or white desaturates, so
    a club needing heavy mixing stops looking quite like itself; legibility
    wins. Against a white card three clubs move at all: the White Sox, the
    Pirates and the Rays.
    """
    rgb = tuple(int(hex_color[i:i + 2], 16) for i in (1, 3, 5))
    target = (0, 0, 0) if _luminance(PANEL_RGB) > 0.5 else (255, 255, 255)
    for step in range(21):                       # up to 100% toward target
        mix = step / 20.0
        moved = tuple(round(c + (target[i] - c) * mix)
                      for i, c in enumerate(rgb))
        if _contrast(moved, PANEL_RGB) >= MIN_CONTRAST:
            return "#%02X%02X%02X" % moved
    return "#%02X%02X%02X" % target


# Three-letter codes, keyed the same way as TEAM_COLOR so both maps agree.
TEAM_ABBR = {
    "diamondbacks": "ARI", "braves": "ATL", "orioles": "BAL", "red sox": "BOS",
    "cubs": "CHC", "white sox": "CWS", "reds": "CIN", "guardians": "CLE",
    "rockies": "COL", "tigers": "DET", "astros": "HOU", "royals": "KC",
    "angels": "LAA", "dodgers": "LAD", "marlins": "MIA", "brewers": "MIL",
    "twins": "MIN", "mets": "NYM", "yankees": "NYY", "athletics": "ATH",
    "phillies": "PHI", "pirates": "PIT", "padres": "SD", "giants": "SF",
    "mariners": "SEA", "cardinals": "STL", "rays": "TB", "rangers": "TEX",
    "jays": "TOR", "nationals": "WSH",
}


def team_color(team: str | None) -> str | None:
    raw = TEAM_COLOR.get(_nickname(team).lower()) if team else None
    return _legible(raw) if raw else None


def _tdot(team: str | None) -> str:
    c = team_color(team)
    return f'<span class="tdot" style="--tc:{c}"></span>' if c else ""


def _prob_bar(model: dict | None) -> str:
    """The two numbers as one bar, with the market's own number as a tick.

    The bar fills left to right with the away club's chance, so the tick sits
    at 1 - market_home_prob. Printing the two percentages alone makes a reader
    do the subtraction; the distance between fill and tick is the disagreement
    without arithmetic.

    Does not scale the tick's prominence by how large the gap is. A two-point
    disagreement and a ten-point one are drawn identically, because the bar is
    a measurement and not an argument.

    Returns only the bar, not its caption — see _prob_foot() below. The two
    used to come back as one string that board_card rendered between the away
    and home clubs, which put the caption directly above the home club's name
    and made it read as that club's label rather than a caption on the bar.
    Two functions (instead of one returning a tuple) keep each call site
    reading as plain HTML-in, HTML-out, matching every other renderer here.
    board_card now places _prob_bar between the clubs and _prob_foot after
    both of them, which is the slot .gfoot's CSS (border-top, nothing below)
    was built for — the same slot slate_rows already uses.
    """
    if not model:
        return ""
    away = model.get("away_win_prob")
    if away is None:
        return ""
    fill = max(0.0, min(100.0, away * 100))

    market_home = model.get("market_home_prob")
    tick = ""
    if market_home is not None:
        at = max(0.0, min(100.0, (1.0 - market_home) * 100))
        tick = (f'<div class="tick" style="left:{at:.1f}%" '
                f'title="{_("market_tick")}"></div>')

    return (f'<div class="gbar"><div class="seg on" '
            f'style="width:{fill:.1f}%"></div>{tick}</div>')


def _prob_foot(model: dict | None) -> str:
    """The bar's caption: how far the model and market disagree.

    Companion to _prob_bar() — see that docstring for why the bar and its
    caption are returned separately. Renders after both clubs.
    """
    if not model:
        return ""
    if model.get("away_win_prob") is None:
        return ""
    gap = model.get("disagreement")
    if gap is None:
        return ""
    if abs(gap) < 1.0:
        # Under a point the two numbers are the same number wearing different
        # rounding, and calling that a disagreement would cry wolf.
        return f'<div class="gfoot"><span>{_("agree_market")}</span></div>'
    cls = " flagged" if model.get("suspect") else ""
    return (f'<div class="gfoot"><span class="lean{cls}">'
            f'{_("off_market", v=f"{abs(gap):.1f}")}</span></div>')


def _cv_edge(model: dict) -> str:
    """The card's one verdict, bottom right.

    Three states, because the canvas card has three: an edge worth naming,
    an edge pointing the other way, and nothing. Printing "+0.4 EDGE" on a
    game we agree with the market about is the kind of number that teaches a
    reader to stop believing the ones that matter.
    """
    gap = model.get("disagreement")
    if gap is None:
        return f'<span class="ge none">{_("cv_noedge")}</span>'
    if abs(gap) < 1.0:
        return f'<span class="ge none">{_("cv_noedge")}</span>'
    v = f"{abs(gap):.0f}" if abs(gap) >= 10 else f"{abs(gap):.1f}"
    if gap > 0:
        return f'<span class="ge up">{_("cv_edge", v="+" + v)}</span>'
    return f'<span class="ge down">{_("cv_fade", v="&minus;" + v)}</span>'


def _live_hooks(row: dict) -> str:
    """Data attributes board.js reads to fetch a started college game's live
    score from ESPN and judge the pick. Nothing for other leagues."""
    if row.get("league") not in COLLEGE:
        return ""
    a = row.get("ats") or {}
    attrs = {"sport": row["league"], "espn": row.get("espn_id") or "",
             "home": row.get("home", ""), "away": row.get("away", ""),
             "tip": row.get("commence_time", "")}
    if a:
        attrs["side"], attrs["line"] = a["side"], f'{a["line"]:g}'
    return "".join(f' data-{k}="{esc(str(v))}"' for k, v in attrs.items())


def _verdict(row: dict, away_pts, home_pts) -> str:
    a = row.get("ats")
    if not a:
        return ""
    mine, theirs = ((home_pts, away_pts) if a["side"] == "home"
                    else (away_pts, home_pts))
    edge = mine - theirs + a["line"]
    if edge > 0:
        return f'<b class="won">&#10003; {_("res_covered")}</b>'
    if edge < 0:
        return f'<b class="lost">&#10007; {_("res_missed")}</b>'
    return f'<b class="push">{_("res_push")}</b>'


def _result_strip(row: dict) -> str:
    """College cards: the final score and whether our pick covered, from the
    ESPN store at build time. Before that, an empty strip board.js fills with
    the live score. A pick posted after tip-off says it is not in the record."""
    if row.get("league") not in COLLEGE:
        return ""
    note = (f'<p class="cv-nc">{_("res_not_counted")}</p>'
            if row.get("counted") is False else "")
    f = row.get("final")
    if not f:
        labels = "|".join(_(k) for k in ("res_final", "res_live", "res_covered",
                                         "res_missed", "res_push", "res_covering",
                                         "res_not_covering"))
        return f'<div class="cv-res" hidden data-l="{esc(labels)}"></div>' + note
    an = f.get("away_short") or row.get("away", "")
    hn = f.get("home_short") or row.get("home", "")
    return (f'<div class="cv-res"><span><span class="st">{_("res_final")}</span>'
            f'{esc(an)} {f["away"]:g} &ndash; {esc(hn)} {f["home"]:g}</span>'
            f'{_verdict(row, f["away"], f["home"])}</div>' + note)


def _spread_body(row: dict) -> str:
    """College cards: our side against the market spread, its chance to
    cover, and the point gap between our line and the market's.

    The tick is the market's own chance for that side, from the devigged
    spread prices when the board has them (basketball, Odds API), else a
    coin flip (football, ESPN's single line)."""
    a = row["ats"]
    sp = (row.get("markets") or {}).get("spreads") or {}
    side_a = sp.get("side_a", "home")
    mkt = sp.get("fair_home" if a["side"] == side_a else "fair_away")
    mkt = 0.5 if mkt is None else mkt
    line = f'{a["line"]:+g}' if a["line"] else "PK"
    cover = max(0.0, min(100.0, a["cover"] * 100))
    return f"""
          <div class="cv-row">
            <span class="cv-lab">{_("cv_cover", team=esc(a["team"]), line=esc(line))}</span>
            <span class="cv-pct">{cover:.0f}%</span>
          </div>
          <div class="cv-bar"><i class="cv-fill" style="width:{cover:.1f}%"></i><i class="cv-tick" style="left:{mkt * 100:.1f}%"></i></div>
          <div class="cv-foot">
            <span class="gm">{_("cv_mkt_cover", v=f"{mkt * 100:.0f}%")}</span><span class="ge up">{_("cv_ptedge", v=f"+{a['gap']:g}")}</span>
          </div>"""


# ------------------------------------------------- Redesign B: pick card
TIER_LABEL = {"best": "pc_best", "lean": "pc_lean", "check": "pc_check",
              "pass": "pc_pass", "none": "pc_none"}


def _tier_of(a: dict | None) -> str:
    """The tier the pricing posted; rows from before tiers were stored fall
    back to their gap."""
    if not a:
        return "none"
    import ats as _ats  # noqa: PLC0415
    return a.get("tier") or _ats.tier(a.get("gap")) or "none"
LOGO = "https://a.espncdn.com/i/teamlogos/ncaa/500/{id}.png"


def _school(row: dict, side: str) -> str:
    t = ((row.get("teams") or {}).get(side)) or {}
    return t.get("school") or row.get(side, "")


def _logo(row: dict, side: str, size: int) -> str:
    """The school's logo over a badge in its colour. If the image fails to
    load, onerror removes it and the badge (colour + abbreviation) shows."""
    t = ((row.get("teams") or {}).get(side)) or {}
    col = (t.get("color") or "").lstrip("#")
    style = f"--s:{size}px" + (f";--c:#{esc(col)}" if len(col) == 6 else "")
    img = (f'<img src="{LOGO.format(id=esc(t["id"]))}" alt="" width="{size}" height="{size}" '
           f'loading="lazy" decoding="async" onerror="this.remove()">' if t.get("id") else "")
    return (f'<span class="pc-lg" style="{style}" aria-hidden="true">{img}'
            f'{esc((t.get("abbr") or "")[:4])}</span>')


def _pick_chips(row: dict) -> tuple[dict, list[str]]:
    """The home-side spread market and the card's chips: Edge, Line, Proj,
    Total. Shared by the pick card and the Simple tab's details."""
    a = row.get("ats")
    m = row.get("markets") or {}
    sp = m.get("spreads") or {}
    if sp.get("point") is None and row.get("spread_home") is not None:
        sp = {"point": row["spread_home"], "side_a": "home"}   # football (ESPN)
    chips = []
    if a:
        chips.append(f'{_("pc_edge")} <b>+{a["gap"]:g}</b>')
    if sp.get("point") is not None:
        hp = sp["point"] if sp.get("side_a", "home") == "home" else -sp["point"]
        fav, pt = ("home", hp) if hp <= 0 else ("away", -hp)
        chips.append(f'{_("pc_line")} <b>' + ("PK" if pt == 0 else
                     f'{esc(_school(row, fav))} {pt:g}') + "</b>")
    proj = (row.get("model") or {}).get("proj")
    if proj:
        chips.append(f'{_("pc_proj")} <b>{max(proj):.0f}-{min(proj):.0f}</b>')
    tot = (m.get("totals") or {}).get("point")
    if tot is None:
        tot = row.get("total")
    if tot is not None:
        chips.append(f'{_("pc_total")} <b>{tot:g}</b>')
    return sp, chips


def _pick_card(row: dict) -> str:
    a = row.get("ats")
    tier = _tier_of(a)
    # A flagged line gets no cover %: the number is the thing in doubt.
    eid = esc(str(row.get("event_id", "")))
    side = a["side"] if a else "home"
    if a:
        line = f'{a["line"]:+g}' if a["line"] else "PK"
        who = f'{esc(_school(row, side))} {esc(line)}'
        pct = ("" if tier == "check" else
               f'<span class="pc-pct">{a["cover"] * 100:.0f}%<small>{_("pc_to_cover")}</small></span>')
    else:
        who, pct = esc(_("pc_no_pick_sub")), ""
    sp, chips = _pick_chips(row)
    warn = ""
    if tier == "check" and a.get("raw") is not None and sp.get("point") is not None:
        warn = ('<p class="pc-warn">\u26a0 ' + esc(_("pc_check_note").format(
            raw=f'{a["raw"]:g}', sp=f'{abs(sp["point"]):g}')) + "</p>")
    ts = row.get("team_stats") or {}
    if ts.get("home") and ts.get("away"):
        # The panel header names schools too, like the rest of the card.
        ts = {side: dict(ts[side], name=_school(row, side)) for side in ("home", "away")}
    panel = _detail_panel(dict(row, team_stats=ts or None))
    more = (f'<button class="pc-more" aria-expanded="false" aria-controls="d-{eid}" '
            f'data-open="{esc(_("pc_hide"))}" data-shut="{esc(_("pc_details"))}">{_("pc_details")}</button>'
            f'<div class="pc-detail" id="d-{eid}" hidden>{panel}</div>' if panel else "")
    return f"""
      <article class="gcard pc pc-{tier}" id="g-{eid}" data-tier="{tier}"{_live_hooks(row)}>
        <div class="pc-ribbon">{_logo(row, side, 28)}<span class="pc-who"><span class="pc-tag">{_(TIER_LABEL[tier])}</span><strong>{who}</strong></span>{pct}</div>
        <div class="pc-body">
          <div class="pc-match">{_logo(row, "away", 20)}{esc(_school(row, "away"))} @ {_logo(row, "home", 20)}{esc(_school(row, "home"))}<span class="pc-time">{esc(game_time(row.get("commence_time")))}</span></div>
          {warn}<div class="pc-chips">{"".join(f"<span>{c}</span>" for c in chips)}</div>
          {_result_strip(row)}
          {more}
        </div>
      </article>"""


def college_board(rows: list[dict], summary: dict | None) -> str:
    """A college board: the tier records, the Best-bets-only filter, cards."""
    tiers = (summary or {}).get("ats_tiers") or {}
    today = {t: sum(1 for r in rows if _tier_of(r.get("ats")) == t)
             for t in ("best", "lean", "check", "pass")}
    tiles = "".join(
        f'<div><span>{_(lab)}</span><b>{today[t]} {_("pc_today")}</b>'
        f'{_("pc_record")} <em>{(tiers.get(t) or [0, 0, 0])[0]}-{(tiers.get(t) or [0, 0, 0])[1]}</em></div>'
        for t, lab in (("best", "pc_tile_best"), ("lean", "pc_tile_lean"),
                       ("check", "pc_tile_check"), ("pass", "pc_tile_pass")))
    head = (f'<div class="pc-tiers">{tiles}</div>'
            f'<div class="pc-filter" role="group" aria-label="{esc(_("pc_show"))}">'
            f'<button type="button" data-f="best" aria-pressed="false">{_("pc_only_best")}</button>'
            f'<button type="button" data-f="all" aria-pressed="true">{_("pc_all")}</button></div>')
    rank = {"best": 0, "lean": 1, "check": 2, "pass": 3}
    ordered = sorted(rows, key=lambda r: (
        rank.get(_tier_of(r.get("ats")), 4),
        r.get("commence_time") or ""))
    if not ordered:
        return head + board_cards(ordered)
    return head + _spread_groups(ordered)


def _tip(r: dict) -> float:
    """Start time as a number: "...T17:00Z" and "...T17:00:00Z" sort alike."""
    try:
        return datetime.fromisoformat(str(r.get("commence_time")).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return float("inf")


LIVE_LABELS = ("res_final", "res_live", "res_covered", "res_missed", "res_push",
               "res_covering", "res_not_covering")


def _gm_team(logo: str, name: str, sub: str, side: str, pts=None, win: bool = False) -> str:
    """One club's line on a game card: badge, name, the small facts under
    it, and the score. The score cell is always there (empty before the
    game) so board.js can fill it live."""
    sc = "" if pts is None else f"{pts:g}"
    return (f'<div class="gm-tm">{logo}<span class="gm-nm"><b>{name}</b>'
            + (f'<small>{sub}</small>' if sub else "")
            + f'</span><span class="gm-sc{" w" if win else ""}" data-sc="{side}">{sc}</span></div>')


def _gm_card(row: dict, *, tier: str, teams: str, pick: str, detail: str,
             tag: str = "", final: bool = False, lead: str = "", when: str = "",
             sys: bool = False) -> str:
    """The game card every list on the site shares (Scoreboard style): a
    status line, the two clubs, the pick box, Details. A stripe down the
    left edge says best bet or live; both are also written in words."""
    eid = esc(str(row.get("event_id", "")))
    when = when or (_("res_final") if final
                    else game_time(row.get("commence_time")).replace(" ET", ""))
    hooks = "".join(f' data-{k}="{esc(str(v))}"' for k, v in (
        ("sport", row.get("league", "")), ("espn", row.get("espn_id") or ""),
        ("home", row.get("home", "")), ("away", row.get("away", "")),
        ("tip", row.get("commence_time", ""))))
    a = row.get("ats") or {}
    if a:
        hooks += f' data-side="{esc(a["side"])}" data-line="{a["line"]:g}"'
    # The hidden strip carries the words board.js needs for a live game.
    live = ("" if final else
            f'<span class="cv-res" hidden data-l="{esc("|".join(_(k) for k in LIVE_LABELS))}"></span>')
    more = ""
    if detail:
        more = (f'<button class="pc-more gm-more" aria-expanded="false" aria-controls="ld-{eid}" '
                f'data-open="{esc(_("pc_hide"))}" data-shut="{esc(_("pc_details"))}">'
                f'{_("pc_details")}</button>'
                f'<div class="gm-detail" id="ld-{eid}" hidden>{detail}</div>')
    return (f'<article class="gm gm-{tier}{" is-final" if final else ""}" id="l-{eid}"'
            f'{" data-sys=" + chr(34) + "1" + chr(34) if sys else ""}{hooks}>'
            f'<header class="gm-h">'
            + (f'<span class="gm-lg">{esc(lead)}</span>' if lead else "")
            + f'<span class="gm-st">{esc(when)}</span>{tag}</header>'
            f'{teams}{pick}{live}{more}</article>')


def _gm_summary(items: list[tuple[int, str]]) -> str:
    return ('<div class="gm-sum">' + "".join(
        f'<div><b>{n}</b><span>{esc(label)}</span></div>' for n, label in items) + "</div>")


_TIER_TAG = {"best": "pc_best", "lean": "pc_lean", "check": "pc_check"}


SYS_REASON = {"small": "sys_small", "defense": "sys_defense"}


def _home_spread(r: dict):
    sp = (r.get("markets") or {}).get("spreads") or {}
    if sp.get("point") is not None:
        return sp["point"] if sp.get("side_a", "home") == "home" else -sp["point"]
    return r.get("spread_home")


def _row_total(r: dict):
    t = ((r.get("markets") or {}).get("totals") or {}).get("point")
    return t if t is not None else r.get("total")


def _sys_grade(r: dict) -> dict:
    """W/L/P for a row's System play once it is final. "tt" is tracked, not
    played: when the defense rule fires, the favourite's team total (from the
    spread and total, as books set it) going under."""
    play, f = r.get("system") or {}, r.get("final")
    out = {"spread": None, "tt": None}
    if not f:
        return out
    hp, tot = _home_spread(r), _row_total(r)
    if play.get("side") and hp is not None:
        e = f["home"] - f["away"] + hp
        e = -e if play["side"] == "away" else e
        out["spread"] = "W" if e > 0 else "L" if e < 0 else "P"
        if "defense" in (play.get("reasons") or []) and tot is not None and hp:
            fav = "away" if play["side"] == "home" else "home"
            line = tot / 2 + abs(hp) / 2
            d = f[fav] - line
            out["tt"] = "W" if d < 0 else "L" if d > 0 else "P"
    return out


def _sys_box(r: dict) -> str:
    """The System's plays on a game card, each with why and, once final,
    whether it won. Empty when the game has none."""
    play = r.get("system") or {}
    hp = _home_spread(r)
    g = _sys_grade(r)
    words = {"W": ("won", "✓ " + _("res_covered")), "L": ("lost", "✗ " + _("res_missed")),
             "P": ("push", _("res_push"))}
    lines = []
    if play.get("side") and hp is not None:
        pt = hp if play["side"] == "home" else -hp
        why = " · ".join(_(SYS_REASON[k]) for k in play.get("reasons") or [] if k in SYS_REASON)
        res = (f'<b class="{words[g["spread"]][0]}">{words[g["spread"]][1]}</b>' if g["spread"] else "")
        lines.append(f'<div class="gm-sys-l"><span><b>{esc(_school(r, play["side"]))} {pt:+g}</b>'
                     f'<small>{esc(why)}</small></span>{res}</div>')
    if not lines:
        return ""
    return f'<div class="gm-sys"><span class="gm-sys-tag">{_("sys_tag")}</span>{"".join(lines)}</div>'


def rules_record(days: dict[str, list[dict]], since: str) -> dict:
    """The System's record from `since` on (games it had not been tested on),
    graded on each saved day's finals."""
    out = {"spread": [0, 0, 0], "tt": [0, 0, 0], "days": 0}
    for d, rows in days.items():
        if d < since:
            continue
        counted = False
        for r in rows:
            g = _sys_grade(r)
            for k in ("spread", "tt"):
                if g[k]:
                    out[k]["WLP".index(g[k])] += 1
                    counted = True
        out["days"] += counted
    return out


def rules_section(days: dict[str, list[dict]], since: str) -> str:
    """History's System block: the rules in a line each, the record since it
    went live, and the backtest it was built on, labelled as such."""
    import ncaab_rules as _nr  # noqa: PLC0415
    rec = rules_record(days, since)
    bt = _nr.BACKTEST

    def cell(v):
        n = v[0] + v[1]
        return (f'<td>{v[0]}-{v[1]}' + (f"-{v[2]}" if v[2] else "")
                + (f'<small>{round(100 * v[0] / n)}%</small>' if n else "<small>&ndash;</small>") + "</td>")

    rows = "".join(f'<tr><th scope="row">{_(lab)}</th>{cell(rec[k])}{cell(bt[k])}</tr>'
                   for k, lab in (("spread", "sys_spread_plays"), ("tt", "sys_tt_plays")))
    return (f'<section class="sys-sec"><h2 class="sc-h">{_("sys_head")}</h2>'
            f'<ul class="sys-rules"><li>{_("sys_rule_small")}</li><li>{_("sys_rule_defense")}</li>'
            f'</ul>'
            f'<table class="ha"><caption>{_("sys_caption")}</caption><thead><tr>'
            f'<th scope="col"><span class="ts-vh">{_("sys_plays")}</span></th>'
            f'<th scope="col">{_("sys_live", d=_short_day(since))}</th>'
            f'<th scope="col">{_("sys_backtest")}</th></tr></thead><tbody>{rows}</tbody></table>'
            f'<p class="ha-note">{_("sys_note")}</p></section>')


def _short_day(iso: str) -> str:
    from datetime import date as _date  # noqa: PLC0415
    d = _date.fromisoformat(iso)
    return f'{_("hc_months").split(",")[d.month - 1][:3]} {d.day}'


def _college_card(r: dict, lead: str = "") -> tuple[str, str]:
    """One college game as a Scoreboard card, and its tier."""
    tag = _TIER_TAG
    f = r.get("final")
    a = r.get("ats")
    t = _tier_of(a)
    top = max(f["away"], f["home"]) if f else None
    teams = ""
    for side in ("away", "home"):
        sheet = ((r.get("team_stats") or {}).get(side)) or {}
        rk = sheet.get("bpi") or sheet.get("fpi")
        rec = (sheet.get("stats") or {}).get("ats") or []
        bits = [f"#{rk}"] if rk else []
        if len(rec) == 3 and sum(rec):
            bits.append(f'ATS {rec[0]}-{rec[1]}' + (f"-{rec[2]}" if rec[2] else ""))
        pts = f[side] if f else None
        teams += _gm_team(_logo(r, side, 34), esc(_school(r, side)), esc("  ".join(bits)),
                          side, pts, f is not None and pts == top and f["away"] != f["home"])
    if a:
        line = f'{a["line"]:+g}' if a["line"] else "PK"
        cover = a["cover"] * 100
        pct = ("" if t == "check" else
               f'<span class="gm-pc">{cover:.0f}<small>%</small></span>'
               f'<span class="gm-meter" aria-hidden="true"><i style="width:{cover:.0f}%"></i></span>')
        res = _verdict(r, f["away"], f["home"]) if f else ""
        pick = (f'<div class="gm-pk"><span class="gm-lb">{_("cl_pick")}</span>'
                f'<span class="gm-pv">{esc(_school(r, a["side"]))} {esc(line)}</span>{pct}'
                f'<span class="gm-res">{res}</span></div>')
    else:
        pick = (f'<div class="gm-pk gm-nopick"><span class="gm-lb">{_("cl_pick")}</span>'
                f'<span class="gm-pv">{_("pc_none")}</span><span class="gm-res"></span></div>')
    _sp, chips = _pick_chips(r)
    ts = r.get("team_stats") or {}
    if ts.get("home") and ts.get("away"):
        ts = {sd: dict(ts[sd], name=_school(r, sd)) for sd in ("home", "away")}
    panel = _detail_panel(dict(r, team_stats=ts or None))
    detail = ((f'<div class="pc-chips">{"".join(f"<span>{c}</span>" for c in chips)}</div>'
               if chips else "") + (panel or ""))
    tag_html = f'<span class="gm-tier gm-tier-{t}">{_(tag[t])}</span>' if t in tag else ""
    sys_html = _sys_box(r)
    return _gm_card(r, tier=t, teams=teams, pick=pick + sys_html, detail=detail,
                    tag=tag_html, final=bool(f), lead=lead, sys=bool(sys_html)), t


def college_list(rows: list[dict]) -> str:
    """The college board: one card per game by start time. Both schools with
    logo, power rank (BPI, FPI for football), ATS record and score; our pick
    with its chance to cover and, once final, whether it covered; Details
    with the chips and the Team Stats panel."""
    if not rows:
        return board_cards([])
    cards, tiers = [], []
    for r in sorted(rows, key=lambda r: (_tip(r), r.get("home") or "")):
        html_, t = _college_card(r)
        cards.append(html_)
        tiers.append(t)
    n_sys = sum(1 for r in rows if (r.get("system") or {}).get("side"))
    head = _gm_summary([(len(rows), _("gm_games")), (n_sys, _("sys_tile")),
                        (tiers.count("best"), _("pc_tile_best"))])
    if n_sys:
        head += (f'<div class="pc-filter sys-filter" role="group" aria-label="{esc(_("pc_show"))}">'
                 f'<button type="button" data-sf="all" aria-pressed="true">{_("sys_all")}</button>'
                 f'<button type="button" data-sf="sys" aria-pressed="false">{_("sys_only")}</button></div>')
    return (head + f'<p class="gm-key">{_("gm_key")}</p>'
            + '<div class="gm-list">' + "".join(cards) + "</div>")


# ------------------------------------------------------------ pro game list
# NBA (and MLB next): the day's games as one list, like the college boards.
# Details opens the game's markets as collapsed sections -- Game lines, then
# one per player-prop board -- each with its count, a sportsbook's layout.
NBA_ABBR = {
    "ATL": "Atlanta Hawks", "BOS": "Boston Celtics", "BKN": "Brooklyn Nets",
    "CHA": "Charlotte Hornets", "CHI": "Chicago Bulls", "CLE": "Cleveland Cavaliers",
    "DAL": "Dallas Mavericks", "DEN": "Denver Nuggets", "DET": "Detroit Pistons",
    "GS": "Golden State Warriors", "HOU": "Houston Rockets", "IND": "Indiana Pacers",
    "LAC": "Los Angeles Clippers", "LAL": "Los Angeles Lakers", "MEM": "Memphis Grizzlies",
    "MIA": "Miami Heat", "MIL": "Milwaukee Bucks", "MIN": "Minnesota Timberwolves",
    "NO": "New Orleans Pelicans", "NY": "New York Knicks", "OKC": "Oklahoma City Thunder",
    "ORL": "Orlando Magic", "PHI": "Philadelphia 76ers", "PHX": "Phoenix Suns",
    "POR": "Portland Trail Blazers", "SAC": "Sacramento Kings", "SA": "San Antonio Spurs",
    "TOR": "Toronto Raptors", "UTAH": "Utah Jazz", "WSH": "Washington Wizards",
    # Spellings other feeds use for the same clubs.
    "GSW": "Golden State Warriors", "NOP": "New Orleans Pelicans", "NYK": "New York Knicks",
    "SAS": "San Antonio Spurs", "UTA": "Utah Jazz", "WAS": "Washington Wizards",
    "PHO": "Phoenix Suns", "BRK": "Brooklyn Nets", "CHO": "Charlotte Hornets",
}
_NBA_BY_NAME = {}
for _ab, _nm in NBA_ABBR.items():
    _NBA_BY_NAME.setdefault(_nm, _ab)          # first spelling is ESPN's
_NBA_BY_NAME["LA Clippers"] = "LAC"


NFL_ABBR = {
    "ARI": "Arizona Cardinals", "ATL": "Atlanta Falcons", "BAL": "Baltimore Ravens",
    "BUF": "Buffalo Bills", "CAR": "Carolina Panthers", "CHI": "Chicago Bears",
    "CIN": "Cincinnati Bengals", "CLE": "Cleveland Browns", "DAL": "Dallas Cowboys",
    "DEN": "Denver Broncos", "DET": "Detroit Lions", "GB": "Green Bay Packers",
    "HOU": "Houston Texans", "IND": "Indianapolis Colts", "JAX": "Jacksonville Jaguars",
    "KC": "Kansas City Chiefs", "LV": "Las Vegas Raiders", "LAC": "Los Angeles Chargers",
    "LAR": "Los Angeles Rams", "MIA": "Miami Dolphins", "MIN": "Minnesota Vikings",
    "NE": "New England Patriots", "NO": "New Orleans Saints", "NYG": "New York Giants",
    "NYJ": "New York Jets", "PHI": "Philadelphia Eagles", "PIT": "Pittsburgh Steelers",
    "SF": "San Francisco 49ers", "SEA": "Seattle Seahawks", "TB": "Tampa Bay Buccaneers",
    "TEN": "Tennessee Titans", "WSH": "Washington Commanders",
}
PRO_ABBR = {"nba": _NBA_BY_NAME, "nfl": {name: ab for ab, name in NFL_ABBR.items()}}
LEAGUE_TAG = {"nba": "NBA", "nfl": "NFL", "mlb": "MLB", "ncaab": "NCAAB", "ncaaf": "NCAAF"}

# The NFL projection boards use nflverse's abbreviations, which differ from
# ESPN's for two clubs: full name by nflverse abbreviation, the ESPN one
# for the logo, and a colour dark enough for white text.
NFL_VERSE = {
    "ARI": "Arizona Cardinals", "ATL": "Atlanta Falcons", "BAL": "Baltimore Ravens",
    "BUF": "Buffalo Bills", "CAR": "Carolina Panthers", "CHI": "Chicago Bears",
    "CIN": "Cincinnati Bengals", "CLE": "Cleveland Browns", "DAL": "Dallas Cowboys",
    "DEN": "Denver Broncos", "DET": "Detroit Lions", "GB": "Green Bay Packers",
    "HOU": "Houston Texans", "IND": "Indianapolis Colts", "JAX": "Jacksonville Jaguars",
    "KC": "Kansas City Chiefs", "LV": "Las Vegas Raiders", "LAC": "Los Angeles Chargers",
    "LA": "Los Angeles Rams", "MIA": "Miami Dolphins", "MIN": "Minnesota Vikings",
    "NE": "New England Patriots", "NO": "New Orleans Saints", "NYG": "New York Giants",
    "NYJ": "New York Jets", "PHI": "Philadelphia Eagles", "PIT": "Pittsburgh Steelers",
    "SF": "San Francisco 49ers", "SEA": "Seattle Seahawks", "TB": "Tampa Bay Buccaneers",
    "TEN": "Tennessee Titans", "WAS": "Washington Commanders",
}
NFL_LOGO = {"LA": "lar", "WAS": "wsh"}        # nflverse -> ESPN, where they differ
NFL_PAIR = {name: ab for ab, name in NFL_VERSE.items()}   # full name -> nflverse
NFL_COLOR = {
    "ARI": "97233F", "ATL": "A71930", "BAL": "241773", "BUF": "00338D", "CAR": "101820",
    "CHI": "0B162A", "CIN": "101820", "CLE": "311D00", "DAL": "003594", "DEN": "002244",
    "DET": "0076B6", "GB": "203731", "HOU": "03202F", "IND": "002C5F", "JAX": "006778",
    "KC": "E31837", "LV": "111111", "LAC": "002A5E", "LA": "003594", "MIA": "005778",
    "MIN": "4F2683", "NE": "002244", "NO": "101820", "NYG": "0B2265", "NYJ": "125740",
    "PHI": "004C54", "PIT": "101820", "SF": "AA0000", "SEA": "002244", "TB": "D50A0A",
    "TEN": "0C2340", "WAS": "5A1414",
}


def week_games(props: dict[str, list[dict]], board: list[dict]) -> list[dict]:
    """The NFL games the projection boards cover that are not on today's
    board, as bare rows (no line) for the rest-of-the-week list. nflverse
    game ids read season_week_away_home."""
    on_board = {frozenset((NFL_PAIR.get(g.get("home")), NFL_PAIR.get(g.get("away"))))
                for g in board}
    seen, out = set(), []
    for rows in (props or {}).values():
        for r in rows:
            gid = str(r.get("game_id") or "")
            parts = gid.split("_")
            if gid in seen or len(parts) != 4:
                continue
            seen.add(gid)
            away, home = parts[2], parts[3]
            if frozenset((home, away)) in on_board or home not in NFL_VERSE or away not in NFL_VERSE:
                continue
            out.append({"event_id": gid, "league": "nfl", "week_game": True,
                        "commence_time": r.get("commence_time") or "",
                        "home": NFL_VERSE[home], "away": NFL_VERSE[away], "markets": {}})
    out.sort(key=lambda g: (_tip(g), g["home"]))
    return out


def tonight_list(rows: list[dict], props: dict[str, dict] | None = None) -> str:
    """Tonight: every league's games in one list by start time, each card
    saying its league. College games are pick cards, NBA and NFL line
    cards (`props`: league -> that league's projection boards); a league
    without a Scoreboard card yet keeps its own."""
    if not rows:
        return board_cards([])
    cards, count = [], {}
    for r in sorted(rows, key=lambda r: (_tip(r), r.get("home") or "")):
        lg = r.get("league", "")
        count[lg] = count.get(lg, 0) + 1
        lead = LEAGUE_TAG.get(lg, lg.upper())
        if lg in COLLEGE:
            cards.append(_college_card(r, lead)[0])
        elif lg in PRO_ABBR:
            cards.append(_pro_card(r, (props or {}).get(lg), PRO_ABBR[lg], lead,
                                   pair=NFL_PAIR if lg == "nfl" else None)[0])
        else:
            cards.append(board_card(r))
    head = _gm_summary([(len(rows), _("gm_games"))]
                       + [(n, LEAGUE_TAG.get(lg, lg.upper())) for lg, n in count.items()][:3])
    return head + '<div class="gm-list">' + "".join(cards) + "</div>"


def _price(v) -> str:
    """An American price as books write it: +360, -110."""
    if v is None:
        return ""
    return f"+{v:g}" if v > 0 else f"{v:g}"


def _game_lines(row: dict) -> tuple[str, int]:
    """The Game lines section: spread, moneyline, total, each side at the
    best price on the board. Returns (html, markets shown)."""
    m = row.get("markets") or {}
    away, home = esc(_nickname(row.get("away"))), esc(_nickname(row.get("home")))
    out = []
    sp = m.get("spreads") or {}
    if sp.get("point") is not None:
        hp = sp["point"] if sp.get("side_a", "home") == "home" else -sp["point"]
        bh, ba = sp.get("best_home") or {}, sp.get("best_away") or {}
        if sp.get("side_a", "home") != "home":
            bh, ba = ba, bh
        out.append((_("mk_spread"), f"{-hp:+g}", _price(ba.get("price")),
                    f"{hp:+g}", _price(bh.get("price"))))
    h2h = m.get("h2h") or {}
    if (h2h.get("best_home") or {}).get("price") is not None:
        out.append((_("mk_ml"), _price(h2h["best_away"]["price"]) if h2h.get("best_away") else "", "",
                    _price(h2h["best_home"]["price"]), ""))
    tot = m.get("totals") or {}
    if tot.get("point") is not None:
        over, under = tot.get("best_home") or {}, tot.get("best_away") or {}
        if tot.get("side_a", "over") != "over":
            over, under = under, over
        out.append((_("mk_total"), f'O {tot["point"]:g}', _price(over.get("price")),
                    f'U {tot["point"]:g}', _price(under.get("price"))))
    if not out:
        return "", 0

    def cell(main, price):
        return f'<td>{esc(main)}' + (f'<small>{esc(price)}</small>' if price else "") + "</td>"

    body = "".join(f'<tr><th scope="row">{esc(lab)}</th>{cell(a, ap)}{cell(h, hp_)}</tr>'
                   for lab, a, ap, h, hp_ in out)
    return (f'<table class="mk-t"><thead><tr><th scope="col"><span class="ts-vh">{_("mk_market")}</span></th>'
            f'<th scope="col">{away}</th><th scope="col">{home}</th></tr></thead>'
            f'<tbody>{body}</tbody></table>'
            f'<p class="mk-note">{_("mk_lines_note")}</p>'), len(out)


# Each club's main colour, dark enough for white text on top (a club whose
# first colour is too light uses its darker one).
NBA_COLOR = {
    "ATL": "C8102E", "BOS": "007A33", "BKN": "111111", "CHA": "1D1160", "CHI": "CE1141",
    "CLE": "860038", "DAL": "00538C", "DEN": "0E2240", "DET": "1D42BA", "GS": "1D428A",
    "HOU": "CE1141", "IND": "002D62", "LAC": "1D428A", "LAL": "552583", "MEM": "12173F",
    "MIA": "98002E", "MIL": "00471B", "MIN": "0C2340", "NO": "0C2340", "NY": "006BB6",
    "OKC": "002D62", "ORL": "0077C0", "PHI": "006BB6", "PHX": "1D1160", "POR": "111111",
    "SAC": "5A2D81", "SA": "111111", "TOR": "CE1141", "UTAH": "002B5C", "WSH": "002B5C",
}
POS_ONE_WORD = {"G": "pos_one_g", "F": "pos_one_f", "C": "pos_one_c"}


def _last5(recent: list[dict], ref, label: str | None = None, strict: bool = False) -> str:
    """The last games (five at most) as boxes, each showing its number:
    `hit` at or above the reference (the projection), `near` within 15%
    under it, `miss` below that. `strict` has no middle: a touchdown was
    scored or it was not. The number is always printed; colour repeats it."""
    vals = [g.get("value") for g in (recent or [])[-5:] if g.get("value") is not None]
    if not vals:
        return ""
    def cls(v):
        if not ref:
            return "near"
        if v >= ref:
            return "hit"
        return "near" if not strict and v >= 0.85 * ref else "miss"
    boxes = "".join(f'<i class="pp-{cls(v)}">{v:g}</i>' for v in vals)
    return f'<div class="pp-l5"><span>{label or _("pp_last5")}</span>{boxes}</div>'


def _prop_cards(rows: list[dict], stat_key: str, league: str = "nba") -> str:
    """One prop board's players for one game as cards, best projection
    first: who and against whom on the club's colour, the projection beside
    the season average, what this opponent gives up, and recent games.
    A touchdown board (rows with `chance`) shows the chance to score."""
    nfl = league == "nfl"
    names = NFL_VERSE if nfl else NBA_ABBR
    colors = NFL_COLOR if nfl else NBA_COLOR
    stat = _(stat_key)
    cards = []
    for r in sorted(rows, key=lambda r: -(r.get("chance") or r.get("projection") or 0)):
        td = r.get("chance") is not None
        ab = r.get("team") or ""
        col = colors.get(ab, "")
        slug = (NFL_LOGO.get(ab, ab.lower()) if nfl else ab.lower())
        opp = _nickname(names.get(r.get("opponent") or "", r.get("opponent") or ""))
        pos = _(POS_ONE_WORD[r["position"]]) if r.get("position") in POS_ONE_WORD else (r.get("position") or "")
        logo = (f'<span class="pc-lg" style="--s:30px" aria-hidden="true">'
                f'<img src="https://a.espncdn.com/i/teamlogos/{esc(league)}/500/{esc(slug)}.png" alt="" '
                f'width="30" height="30" loading="lazy" decoding="async" onerror="this.remove()">'
                f'{esc(ab[:4])}</span>') if ab else ""
        who = " · ".join(x for x in (pos, _("pp_vs", opp=opp) if opp else "") if x)
        why = ""
        if r.get("pos_allowed") is not None and r.get("pos_rank") and r.get("pos_of"):
            why = _("pp_why", opp=opp, v=f'{r["pos_allowed"]:.1f}', stat=stat.lower(),
                    pos=_(POS_LABEL.get(r.get("pos_slot", ""), "nba_pos_any")),
                    r=r["pos_rank"], ord=_ordinal(r["pos_rank"]), n=r["pos_of"])
        elif r.get("opp_allowed") is not None and r.get("league_allowed") is not None:
            why = _("pp_why_avg", opp=opp, stat=_("pp_tds") if td else stat.lower(),
                    v=f'{r["opp_allowed"]:.2f}' if td else f'{r["opp_allowed"]:.1f}',
                    avg=f'{r["league_allowed"]:.2f}' if td else f'{r["league_allowed"]:.1f}')
        elif r.get("opp_allowed") is not None:
            why = _("pp_why_team", opp=opp, v=f'{r["opp_allowed"]:.1f}')
        proj, avg = r.get("projection"), r.get("per_game")
        if td:
            pairs = ((f'{r["chance"] * 100:.0f}%', _("pp_chance")),
                     ("&ndash;" if avg is None else f"{avg:.2f}", _("pp_td_game")))
            bar, ref = stat, 1
        else:
            pairs = (("&ndash;" if proj is None else f"{proj:.1f}",
                      _("pp_week") if nfl else _("pp_tonight")),
                     ("&ndash;" if avg is None else f"{avg:.1f}", _("pp_season")))
            bar, ref = _("pp_projected", stat=stat), proj
        nums = "".join(f'<div><b>{v}</b><span>{lab}</span></div>' for v, lab in pairs)
        final = ""
        if td and r.get("scored") is not None:
            final = f'<p class="pp-final">{_("pp_scored") if r["scored"] else _("pp_no_score")}</p>'
        elif r.get("actual") is not None:
            actual = f'{r["actual"]:g}'
            final = f'<p class="pp-final">{_("mk_got", v=actual)}</p>'
        cards.append(
            f'<article class="pp"><header class="pp-h"'
            + (f' style="--c:#{col}"' if col else "") + f'>{logo}'
            f'<span class="pp-who"><b>{esc(r.get("name", ""))}</b><small>{esc(who)}</small></span></header>'
            f'<p class="pp-bar">{esc(bar)}</p>'
            f'<div class="pp-nums">{nums}</div>'
            + (f'<p class="pp-why">{esc(why)}</p>' if why else "")
            + _last5(r.get("recent"), ref, _("pp_recent") if nfl else _("pp_last5"), strict=td)
            + final + "</article>")
    key = _("pp_key_td") if any(r.get("chance") is not None for r in rows) else (
        _("pp_key_nfl") if nfl else _("pp_key"))
    return (f'<div class="pp-grid">{"".join(cards)}</div>'
            f'<p class="mk-note">{key}</p>')


def _market_section(title: str, count: int, inner: str) -> str:
    return (f'<details class="pc-grp mk"><summary><span class="pc-grp-t">{esc(title)}</span>'
            f'<span class="pc-grp-n" aria-label="{count} {esc(_("mk_count"))}">{count}</span></summary>'
            f'<div class="mk-body">{inner}</div></details>')


def _pro_logo(row: dict, side: str, abbr: dict, size: int = 34) -> str:
    """A pro club's logo over a badge with its abbreviation; the image
    removes itself if it fails, leaving the badge."""
    ab = abbr.get(row.get(side)) or ""
    img = (f'<img src="https://a.espncdn.com/i/teamlogos/{esc(row.get("league", ""))}/500/{esc(ab.lower())}.png" '
           f'alt="" width="{size}" height="{size}" loading="lazy" decoding="async" '
           f'onerror="this.remove()">' if ab else "")
    return f'<span class="pc-lg" style="--s:{size}px" aria-hidden="true">{img}{esc(ab[:4])}</span>'


def _pro_card(r: dict, props: dict | None, abbr: dict | None,
              lead: str = "", pair: dict | None = None) -> tuple[str, int]:
    """One pro game as a Scoreboard card, and how many projections it holds.
    `abbr` (full name -> abbreviation) finds the logo; `pair`, when the
    projection boards abbreviate differently, finds the game's players."""
    abbr = abbr or {}
    pair = pair or abbr
    n_props = 0
    m = r.get("markets") or {}
    sp, tot = m.get("spreads") or {}, m.get("totals") or {}
    teams = ""
    for side in ("away", "home"):
        form = ((r.get("detail") or {}).get(f"{side}_form")) or {}
        rec = (f'{form["w"]}-{form["l"]}'
               if form.get("w") is not None and form.get("l") is not None else "")
        teams += _gm_team(_pro_logo(r, side, abbr), esc(_nickname(r.get(side))), esc(rec), side)
    line = []
    if sp.get("point") is not None:
        hp = sp["point"] if sp.get("side_a", "home") == "home" else -sp["point"]
        fav, pt = ("home", hp) if hp <= 0 else ("away", -hp)
        line.append("PK" if pt == 0 else f'{esc(_nickname(r.get(fav)))} {pt:g}')
    ou = f'<span class="gm-ou">{_("pl_ou")} {tot["point"]:g}</span>' if tot.get("point") is not None else ""
    pick = (f'<div class="gm-pk gm-line"><span class="gm-lb">{_("pl_line")}</span>'
            f'<span class="gm-pv">{line[0] if line else "&mdash;"}</span>{ou}'
            f'<span class="gm-res"></span></div>')
    when = ""
    if r.get("week_game"):
        # A game later in the week: no line yet, and the day matters.
        pick = '<span class="gm-res"></span>'
        try:
            from zoneinfo import ZoneInfo  # noqa: PLC0415
            dt = datetime.fromisoformat(str(r.get("commence_time")).replace("Z", "+00:00")
                                        ).astimezone(ZoneInfo(config.TIMEZONE))
            when = f"{dt:%a} {dt:%-I:%M %p}"
        except ValueError:
            when = ""
    pair = {pair.get(r.get("home")), pair.get(r.get("away"))} - {None}
    sections = []
    gl, n = _game_lines(r)
    if gl:
        sections.append(_market_section(_("mk_lines"), n, gl))
    for key, prop_rows in (props or {}).items():
        mine = [p for p in prop_rows
                if len(pair) == 2 and {p.get("team"), p.get("opponent")} == pair]
        if mine:
            n_props += len(mine)
            sections.append(_market_section(_(key), len(mine), _prop_cards(mine, key, r.get("league", "nba"))))
    detail = f'<div class="pc-groups">{"".join(sections)}</div>' if sections else ""
    return _gm_card(r, tier="line", teams=teams, pick=pick, detail=detail, lead=lead,
                    when=when), n_props


def pro_list(rows: list[dict], props: dict[str, list[dict]] | None = None,
             abbr: dict | None = None, pair: dict | None = None,
             summary: bool = True) -> str:
    """The pro Today list: one card per game by start time with the market's
    line, and Details opening that game's markets as collapsed sections.
    `props` maps a section's i18n key to that board's rows; a row belongs to
    the game whose two clubs are its team and opponent (`abbr`: full name ->
    the abbreviation the prop rows use)."""
    if not rows:
        return board_cards([])
    cards, n_props = [], 0
    for r in sorted(rows, key=lambda r: (_tip(r), r.get("home") or "")):
        html_, n = _pro_card(r, props, abbr, pair=pair)
        cards.append(html_)
        n_props += n
    if not summary:
        return '<div class="gm-list">' + "".join(cards) + "</div>"
    head = _gm_summary([(len(rows), _("gm_games"))]
                       + ([(n_props, _("gm_projections"))] if n_props else []))
    if props and not n_props:
        head += f'<p class="gm-key">{_("gm_props_pending")}</p>'
    return head + '<div class="gm-list">' + "".join(cards) + "</div>"


def prop_accuracy(summaries: dict[str, dict]) -> str:
    """How the player projections have scored, one line per board, under
    the pro list (the boards' own pages are gone; their record is not)."""
    return accuracy_section([(_(key), nba_accuracy(summ)) for key, summ in summaries.items()])


def accuracy_section(blocks: list[tuple[str, str]]) -> str:
    """The scored-in-public section under a pro list: (heading, html) per board."""
    lines = "".join(f'<h3 class="pa-h">{esc(title)}</h3>{body}' for title, body in blocks)
    return (f'<section class="pad-sm" id="projections"><div class="wrap">'
            f'<div class="eyebrow">{_("pa_eyebrow")}</div>'
            f'<h2 style="font-size:26px;margin-top:10px">{_("pa_head")}</h2>{lines}</div></section>')


def day_record(rows: list[dict]) -> list[int]:
    """W-L-P of the day's Best bets and Leans that have a final."""
    out = [0, 0, 0]
    for r in rows:
        a, f = r.get("ats"), r.get("final")
        if not a or not f or _tier_of(a) not in ("best", "lean"):
            continue
        mine, theirs = ((f["home"], f["away"]) if a["side"] == "home"
                        else (f["away"], f["home"]))
        edge = mine - theirs + a["line"]
        out[0 if edge > 0 else 1 if edge < 0 else 2] += 1
    return out


def _wlp(rec) -> str:
    return f"{rec[0]}-{rec[1]}" + (f"-{rec[2]}" if rec[2] else "")


def history_calendar(days: dict[str, list[dict]], league: str) -> str:
    """The History tab: one month grid per month with a saved day, newest
    first. A saved day links to its page and shows the day's record of Best
    bets and Leans; other days are plain numbers. A real table, so the
    weekday headers are announced with each date."""
    import calendar as _cal  # noqa: PLC0415
    from datetime import date as _date  # noqa: PLC0415
    if not days:
        return f'<p class="empty-board">{_("hc_empty")}</p>'
    recs = {d: day_record(rows) for d, rows in days.items()}
    total = [sum(r[i] for r in recs.values()) for i in range(3)]
    months = sorted({d[:7] for d in days}, reverse=True)
    week = _cal.Calendar(firstweekday=6)          # Sunday first, as US calendars
    heads = "".join(f'<th scope="col" abbr="{esc(full)}">{esc(full[:1])}</th>'
                    for full in _("hc_days").split(","))
    out = [f'<p class="hc-sum">{_("hc_total")} <b>{_wlp(total)}</b></p>']
    for ym in months:
        y, m = int(ym[:4]), int(ym[5:])
        title = f'{_("hc_months").split(",")[m - 1]} {y}'
        rows = []
        for wk in week.monthdatescalendar(y, m):
            cells = []
            for d in wk:
                if d.month != m:
                    cells.append('<td class="hc-pad"></td>')
                    continue
                iso = d.isoformat()
                if iso in days:
                    rec = recs[iso]
                    lab = f'{title.split(" ")[0]} {d.day}: {_wlp(rec)}'
                    cls = " hc-up" if rec[0] > rec[1] else " hc-down" if rec[1] > rec[0] else ""
                    cells.append(f'<td class="hc-on{cls}"><a href="day-{iso}.html" aria-label="{esc(lab)}">'
                                 f'<span class="hc-d">{d.day}</span>'
                                 f'<span class="hc-r">{_wlp(rec)}</span></a></td>')
                else:
                    cells.append(f'<td class="hc-off"><span class="hc-d">{d.day}</span></td>')
            rows.append("<tr>" + "".join(cells) + "</tr>")
        out.append(f'<table class="hc"><caption>{esc(title)}</caption>'
                   f'<thead><tr>{heads}</tr></thead><tbody>{"".join(rows)}</tbody></table>')
    out.append(f'<p class="hc-note">{_("hc_note")}</p>')
    return '<div class="hc-wrap">' + "".join(out) + "</div>"


def home_away_table(split: dict, side: str = "home") -> str:
    """Season to date on true home courts: the home side's record against
    the spread as favorite and as underdog, overall and by spread size.
    Each cell is home covers - away covers, then the home cover rate, so
    the table reads both ways."""
    if not split or not any(sum(v[:2]) for v in (split.get("all") or {}).values()):
        return ""

    def cell(v):
        n = v[0] + v[1]
        if not n:
            return '<td class="ha-none">&mdash;</td>'
        return f'<td>{v[0]}-{v[1]}<small>{round(100 * v[0] / n)}%</small></td>'

    def flip(v):          # the road team's side of the same game
        return [v[1], v[0], v[2]]

    body = ""
    for k, row in split.items():
        label = _("ha_all") if k == "all" else _("pc_spread").format(r=k)
        fav, dog = ((row["fav"], row["dog"]) if side == "home"
                    else (flip(row["dog"]), flip(row["fav"])))
        body += (f'<tr class="ha-{"all" if k == "all" else "grp"}"><th scope="row">{esc(label)}</th>'
                 f'{cell(fav)}{cell(dog)}</tr>')
    pushes = sum(split["all"][s][2] for s in ("fav", "dog"))
    sfx = "" if side == "home" else "_away"
    foot = f'<p class="ha-note">{_("ha_note" + sfx)}' + (
        f' {_("ha_pushes", n=pushes)}' if pushes and side == "home" else "") + "</p>"
    return (f'<table class="ha"><caption>{_("ha_caption" + sfx)}</caption><thead><tr>'
            f'<th scope="col"><span class="ts-vh">{_("ha_spread")}</span></th>'
            f'<th scope="col">{_("ha_fav" + sfx)}</th><th scope="col">{_("ha_dog" + sfx)}</th>'
            f'</tr></thead><tbody>{body}</tbody></table>' + foot)


def cover_split(games: list[list], x: float) -> dict:
    """Who covered below a spread and at-or-above it. `games` are
    [absolute spread, 1 if the home side was favored else 0, "h" / "a" / "p"
    for home covered, away covered, push]. For each side of `x`:
    {"n", "fav": [covered, not], "dog": [...], "home": [...], "away": [...]}.
    Pushes are left out."""
    names = {"f": "fav", "d": "dog", "h": "home", "a": "away"}
    raw = calc_split(_spread_coded(games), x, "fdha")
    return {side: dict({"n": g["n"]}, **{names[k]: g[k] for k in "fdha"})
            for side, g in raw.items()}


def _spread_coded(games: list[list]) -> list[list]:
    """Spread games as the calculator's [value, winners]: the letters of
    every group that covered (f favorite, d underdog, h home, a away), or
    None for a push."""
    out = []
    for sp, home_fav, res in games:
        if res not in ("h", "a"):
            out.append([sp, None])
            continue
        fav_cov = (res == "h") == bool(home_fav)
        out.append([sp, ("f" if fav_cov else "d") + res])
    return out


def calc_split(coded: list[list], x: float, letters: str) -> dict:
    """The calculator's sum, shared by every calculator and mirrored in
    board.js: for games below `x` ("under") and at-or-above it ("over"),
    how often each lettered group won. A game is [value, winners]; a group
    whose letter is in `winners` won, the rest lost; None is a push and is
    left out."""
    out = {k: dict({"n": 0}, **{c: [0, 0] for c in letters}) for k in ("under", "over")}
    for value, winners in coded:
        if winners is None:
            continue
        g = out["under" if value < x else "over"]
        g["n"] += 1
        for c in letters:
            g[c][0 if c in winners else 1] += 1
    return out


def _calc(cid: str, coded: list[list], x: float, groups: list[tuple[str, str]], *,
          head: str, label: str, under: str, over: str, note: str,
          presets: tuple, lo: float, hi: float) -> str:
    """One calculator: a number box with presets, and two panels (below the
    number, at-or-above it) listing each group's record and rate. Drawn for
    the default number here so it reads without scripts; board.js recomputes
    from the embedded games when the number changes."""
    import json as _json  # noqa: PLC0415
    if not coded:
        return ""
    letters = "".join(c for c, _lab in groups)
    split = calc_split(coded, x, letters)

    def panel(key: str, title: str) -> str:
        g = split[key]
        rows = "".join(
            f'<div class="sc-row"><span>{esc(lab)}</span>'
            f'<b data-sc-cell="{key}-{c}">{g[c][0]}-{g[c][1]}</b>'
            f'<small data-sc-pct="{key}-{c}">'
            f'{(str(round(100 * g[c][0] / (g[c][0] + g[c][1]))) + "%") if sum(g[c]) else "&ndash;"}</small></div>'
            for c, lab in groups)
        return (f'<div class="sc-panel"><h3 data-sc-title="{key}">{esc(title)}</h3>'
                f'<p class="sc-n"><span data-sc-n="{key}">{g["n"]}</span> {_("gm_games").lower()}</p>{rows}</div>')

    chips = "".join(f'<button type="button" class="sc-preset" data-v="{v:g}">{v:g}</button>'
                    for v in presets)
    return (f'<section class="sc" data-letters="{letters}" data-under="{esc(under)}" data-over="{esc(over)}">'
            f'<h2 class="sc-h">{esc(head)}</h2>'
            f'<label for="{cid}">{esc(label)}</label>'
            f'<div class="sc-in"><input id="{cid}" type="number" inputmode="decimal" min="{lo:g}" max="{hi:g}" '
            f'step="0.5" value="{x:g}">{chips}</div>'
            f'<div class="sc-out" role="status">'
            f'{panel("under", under.format(x=f"{x:g}"))}{panel("over", over.format(x=f"{x:g}"))}</div>'
            f'<p class="ha-note">{esc(note)}</p>'
            f'<script type="application/json" class="sc-data">{_json.dumps(coded, separators=(",", ":"))}</script>'
            f'</section>')


def spread_calc(games: list[list], x: float = 10.0) -> str:
    """Who covers at a spread: favorites, underdogs, home and away, under
    any number and at-or-above it."""
    return _calc("sc-x", _spread_coded(games), x,
                 [("f", _("sc_fav")), ("d", _("sc_dog")), ("h", _("sc_home")), ("a", _("sc_away"))],
                 head=_("sc_head"), label=_("sc_label"), under=_("sc_under"), over=_("sc_over"),
                 note=_("sc_note"), presets=(3, 5, 7.5, 10, 15, 20), lo=0.5, hi=45)


def total_calc(games: list[list], x: float | None = None) -> str:
    """Over or under at a total: `games` are [total line, "o" / "u" / "p"].
    The default number is the middle total of the season so far."""
    coded = [[t, (r if r in ("o", "u") else None)] for t, r in games]
    if not coded:
        return ""
    if x is None:
        vals = sorted(t for t, _r in coded)
        x = round(vals[len(vals) // 2] * 2) / 2
    base = round(x / 5) * 5
    return _calc("tc-x", coded, x, [("o", _("tc_over")), ("u", _("tc_under"))],
                 head=_("tc_head"), label=_("tc_label"), under=_("tc_below"), over=_("tc_above"),
                 note=_("tc_note"), presets=tuple(base + d for d in (-15, -10, -5, 0, 5, 10)),
                 lo=30, hi=300)


def history_day(rows: list[dict], day: str, prev: str | None, nxt: str | None) -> str:
    """One saved day: previous / calendar / next links, the day's record,
    and the Simple list with finals and results."""
    from datetime import date as _date  # noqa: PLC0415
    def lab(iso):
        d = _date.fromisoformat(iso)
        return f'{_("hc_months").split(",")[d.month - 1][:3]} {d.day}'
    nav = (f'<nav class="hd-nav" aria-label="{esc(_("hc_days_nav"))}">'
           + (f'<a href="day-{prev}.html" rel="prev">&lsaquo; {esc(lab(prev))}</a>' if prev else "<span></span>")
           + f'<a href="history.html">{_("hc_calendar")}</a>'
           + (f'<a href="day-{nxt}.html" rel="next">{esc(lab(nxt))} &rsaquo;</a>' if nxt else "<span></span>")
           + "</nav>")
    rec = day_record(rows)
    head = f'<p class="hc-sum">{_("hc_day_total")} <b>{_wlp(rec)}</b></p>'
    return nav + head + college_list(rows)


# Spread-size groups on the college boards, by the absolute line: lower
# bound inclusive. Pick'em sits with 1-5.
SPREAD_GROUPS = ((0, 5, "1\u20135"), (5, 10, "5\u201310"), (10, 20, "10\u201320"),
                 (20, None, "20+"))


def _abs_spread(row: dict):
    sp = ((row.get("markets") or {}).get("spreads") or {}).get("point")
    if sp is None:
        sp = row.get("spread_home")
    return None if sp is None else abs(sp)


def _spread_groups(rows: list[dict]) -> str:
    """Collapsed groups like a sportsbook's market list. Native <details>:
    keyboard, find-in-page and screen readers come free; not exclusive, so
    two groups can be open side by side. Rows keep their order inside."""
    buckets: list[tuple[str, list[dict]]] = [
        (_("pc_spread").format(r=lab), [r for r in rows if _abs_spread(r) is not None
                                        and lo <= _abs_spread(r) and (hi is None or _abs_spread(r) < hi)])
        for lo, hi, lab in SPREAD_GROUPS]
    buckets.append((_("pc_no_line"), [r for r in rows if _abs_spread(r) is None]))
    out = []
    for title, group in buckets:
        if not group:
            continue
        tiers = [_tier_of(r.get("ats")) for r in group]
        bits = [_("pc_g_" + t).format(n=tiers.count(t))
                for t in ("best", "lean", "check") if tiers.count(t)]
        joined = " \u00b7 ".join(bits)
        sub = f'<span class="pc-grp-s">{esc(joined)}</span>' if bits else ""
        out.append(
            f'<details class="pc-grp" data-best="{tiers.count("best")}">'
            f'<summary><span class="pc-grp-t">{esc(title)}</span>{sub}'
            f'<span class="pc-grp-n" aria-label="{len(group)} {esc(_("pc_games"))}">{len(group)}</span></summary>'
            + board_cards(group) + "</details>")
    return f'<div class="pc-groups">{"".join(out)}</div>'


def board_card(row: dict) -> str:
    """One game, priced, with everything else behind a disclosure.

    Rebuilt to the design canvas's card, which is a deliberately thin thing:
    the matchup, ONE probability -- the side we favour -- a bar with the
    market's own number ticked onto it, what the market says, and the size of
    the disagreement. Five lines.

    Clubs are named by nickname -- "Phillies @ Nationals", not "Philadelphia
    Phillies @ Washington Nationals". At 20px the full names wrap to two
    lines on every card and the matchup stops being one object.

    What used to sit on the face of this card and now sits inside it: both
    clubs' records, both starters, the head-to-head strip, and the three
    market price rows. None of that is gone; it is one tap away. The point of
    the canvas card is that a reader scanning fifteen games should be
    comparing fifteen of the same number, not reading fifteen paragraphs.

    The disclosure is a <details> rather than a card flip: a flipped card's
    back is exactly the footprint of its front, and the detail does not fit.
    <details> also stays findable by Ctrl+F and works with no JavaScript.
    """
    if row.get("league") in COLLEGE:
        return _pick_card(row)
    model = row.get("model") or {}
    tip = game_time(row.get("commence_time"))
    accent = team_color(row.get("home"))
    style = f' style="--accent:{accent}"' if accent else ""

    hp = model.get("home_win_prob")
    ap = model.get("away_win_prob")
    away, home = row.get("away", ""), row.get("home", "")

    if row.get("ats"):
        body = _spread_body(row)
    elif hp is None or ap is None:
        body = f'<div class="cv-none">{_("not_rated")}</div>'
    else:
        # One side, and it is ours -- the club our number likes. A card that
        # printed both made the reader do the comparison the card had already
        # done.
        lead_home = hp >= ap
        who = home if lead_home else away
        ours = hp if lead_home else ap
        mkt = model.get("market_home_prob")
        if mkt is not None and not lead_home:
            mkt = 1.0 - mkt
        market_txt = (_("cv_market", v=f"{mkt * 100:.0f}%")
                      if mkt is not None else "")
        fill = max(0.0, min(100.0, ours * 100))
        tick = (f'<i class="cv-tick" style="left:{max(0.0, min(100.0, mkt * 100)):.1f}%"></i>'
                if mkt is not None else "")
        body = f"""
          <div class="cv-row">
            <span class="cv-lab">{_("cv_winprob", who=esc(_name(who, row) if row.get("league") in COLLEGE else _abbr(who)))}</span>
            <span class="cv-pct">{ours * 100:.0f}%</span>
          </div>
          <div class="cv-bar"><i class="cv-fill" style="width:{fill:.1f}%"></i>{tick}</div>
          <div class="cv-foot">
            <span class="gm">{market_txt}</span>{_cv_edge(model)}
          </div>"""

    return f"""
      <article class="gcard"{style} id="g-{esc(row.get('event_id',''))}"{_live_hooks(row)}>
        <div class="gcard-body">
          <div class="cv-head">
            <h3 class="cv-tm">{esc(_name(away, row))} <span>@</span> {esc(_name(home, row))}</h3>
            <span class="cv-time">{esc(tip)}</span>
          </div>
          {_result_strip(row)}
          {body}
          {_line_note(row)}
          {_disclosure(row)}
        </div>
      </article>"""


# Division rivals meet thirteen times a season. Listing every meeting buries
# the starters and the props underneath it, so the strip shows the most recent
# few and counts the rest. Six, because six chips fit one row at 320px and
# seven wrap -- a strip that wraps stops reading as a timeline.
SERIES_SHOWN = 6

# ESPN publishes three positions for basketball, not five. POSITIONS in
# nba_data says why.
POS_LABEL = {"G": "nba_pos_g", "F": "nba_pos_f", "C": "nba_pos_c"}
# The same three, singular, for the chip on a card's face. ESPN gives the
# NBA one letter, and a lone "F" sitting after "ATL vs ORL" reads as part of
# the fixture -- so the word is spelled out and lifted up beside the name.
# Football positions (QB, WR, RB, TE) are already unambiguous two-letter
# abbreviations a reader knows, so they pass through untouched.
POS_ONE = {"G": "pos_one_g", "F": "pos_one_f", "C": "pos_one_c"}


def _pos_badge(pos: str) -> str:
    """The player's position, as its own chip. Empty string when unknown --
    an empty chip is worse than none."""
    pos = (pos or "").strip()
    if not pos:
        return ""
    key = POS_ONE.get(pos.upper())
    return f'<span class="cv-pos">{esc(_(key) if key else pos)}</span>'

MX_LABEL = {"favourable": "mx_favourable", "tough": "mx_tough",
            "neutral": "mx_neutral"}
# The same three verdicts, in one word, for the badge on a row's face.
MXB_LABEL = {"favourable": "mxb_favourable", "tough": "mxb_tough",
             "neutral": "mxb_neutral"}
MX_CLASS = {"favourable": "good", "tough": "bad", "neutral": ""}

# Tonight's strikeout props, indexed by event id. Module-level for the same
# reason LANG is: build.py sets it once before rendering, and threading a
# props argument down through board_cards -> board_card -> panel would put
# baseball's vocabulary into a signature every league has to use.
_PROPS: dict[str, list[dict]] = {}


def set_props(rows) -> None:
    """Hand render the day's prop rows. Call before drawing any board."""
    global _PROPS
    index: dict[str, list[dict]] = {}
    for r in rows or []:
        eid = r.get("event_id")
        if eid:
            index.setdefault(eid, []).append(r)
    _PROPS = index


def _md(iso_date: str) -> str:
    """'2026-06-08' -> 'Jun 8', in the reader's language."""
    try:
        _y, month, day = (int(part) for part in iso_date.split("-"))
    except (ValueError, AttributeError):
        return iso_date or ""
    return f"{i18n.MONTHS[LANG][month - 1][:3]} {day}"


def _place(n: int) -> str:
    """'2nd' / '2\u00ba'. A division place, in the reader's language.

    Deliberately NOT named _ordinal. There is already an _ordinal in this
    file and it returns the SUFFIX alone -- "nd", not "2nd" -- for the
    "{r}{ord} of {n}" rank strings the prop boards build. A second function
    by that name shadowed it and every rank on the site became "2ndnd of
    30", which is how this comment came to exist.
    """
    if LANG == "es":
        return f"{n}\u00ba"
    return f"{n}{_ordinal(n)}"


def _place_line(form: dict, record: dict) -> str:
    """'84\u201361 \u00b7 2nd AL East', or as much of it as we have.

    The record alone is the fallback and it is load-bearing: standings is one
    request that can fail, and a card that then showed nothing where the
    record goes would be worse than a card that shows the record.
    """
    src = form or record or {}
    w, l = src.get("w"), src.get("l")
    if w is None or l is None:
        return ""
    line = f"{w}&ndash;{l}"
    rank, div = (form or {}).get("div_rank"), (form or {}).get("division")
    if rank and div:
        line += f' &middot; <span class="sc-div">{_place(rank)} {esc(div)}</span>'
    return line


def _streak_chip(code: str) -> str:
    """'W4' as a tinted chip, or nothing.

    Nothing, rather than a dash: the chip sits inline after the last-ten
    record and a dash there reads as a missing number in that record.
    """
    if not code or len(code) < 2 or not code[1:].isdigit():
        return ""
    won = code.startswith("W")
    return (f'<b class="sc-stk {"sc-up" if won else "sc-down"}" '
            f'title="{_("pnl_streak")}">{esc(code)}</b>')


def _scorecard(row: dict, detail: dict) -> str:
    """Both clubs across the head of the panel, the way a scoreboard does it.

    Replaces a three-row table of record / last ten / streak. The table was
    honest and unreadable: a reader comparing two clubs had to track which
    column was which down three rows, and the club names sat in a header row
    they had already read on the face of the card.

    Here each club owns a side. The abbreviation is the heading, the record
    and division sit under it, the last ten and the streak sit under that,
    and a rule in the club's own accent closes the block. Nothing has to be
    tracked across a row because nothing crosses the middle.

    The away club is left and the home club is right, matching "away @ home"
    on the card's face. That order is not negotiable on a baseball card and
    it is why the @ badge sits in the middle rather than beside a name.
    """
    away, home = row.get("away"), row.get("home")
    # Nothing at all, rather than two abbreviations under the nicknames the
    # card's face already carries. A college basketball card before any
    # finals are stored has no records, no starters and no props, and a
    # scorecard drawn from nothing is what would give it a disclosure that
    # opens onto an empty box.
    if not any(detail.get(f"{w}_form") or detail.get(f"{w}_record")
               for w in ("away", "home")) and not detail.get("venue"):
        return ""
    sides = []
    for which, team in (("away", away), ("home", home)):
        form = detail.get(f"{which}_form") or {}
        line = _place_line(form, detail.get(f"{which}_record") or {})
        l10 = ""
        if form.get("l10_w") is not None and form.get("l10_l") is not None:
            l10 = _("sc_l10", w=form["l10_w"], l=form["l10_l"])
        chip = _streak_chip(form.get("streak", ""))
        colour = team_color(team)
        style = f' style="--sc-accent:{colour}"' if colour else ""
        sides.append(
            f'<div class="sc-side sc-{which}"{style}>'
            f'<div class="sc-abbr">{esc(_abbr(team))}</div>'
            f'<div class="sc-rec">{line}</div>'
            f'<div class="sc-l10">{l10}{chip}</div>'
            f'<i class="sc-rule"></i></div>')

    when = _fixture_line(row, detail)
    fixture = f'<div class="sc-when">{when}</div>' if when else ""
    return (f'<section class="pk sc">'
            f'<div class="sc-grid">{sides[0]}'
            f'<span class="sc-at">@</span>{sides[1]}</div>'
            f'{fixture}</section>')


def _fixture_line(row: dict, detail: dict) -> str:
    """'Thu Sep 17 \u00b7 7:10 PM ET \u00b7 Citi Field', minus whatever is missing.

    Joined from parts rather than formatted as one string so a game with no
    announced starter -- and therefore no venue, since the venue rides on the
    schedule row the starter came from -- loses the park and keeps the time.
    """
    bits = []
    iso = row.get("commence_time")
    if iso:
        try:
            from zoneinfo import ZoneInfo
            dt = datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone(
                ZoneInfo(config.TIMEZONE))
            wd = i18n.WEEKDAYS[LANG][dt.weekday()][:3]
            mo = i18n.MONTHS[LANG][dt.month - 1][:3]
            bits.append(esc(f"{wd} {mo} {dt.day}"))
        except Exception:                                    # noqa: BLE001
            pass
    tip = game_time(iso)
    if tip:
        bits.append(esc(tip))
    venue = detail.get("venue")
    if venue:
        bits.append(esc(venue))
    return " &middot; ".join(bits)


def _h2h_block(row: dict, detail: dict) -> str:
    """The season series as a split bar, a run rate and one chip per meeting.

    The old block was a paragraph and five lines of prose -- "Padres 6-2 at
    San Diego" repeated. Everything in it was true and none of it was
    scannable: who is ahead, by how much, and which way it has been going
    are three questions a reader asks in one glance, and prose answers them
    in the order it was written rather than the order they are asked.

    So: the bar answers "who is ahead" before it is read, because one colour
    is longer. The runs per game under each end answer "by how much" in the
    units the sport uses. The chips answer "which way" by sitting in date
    order with the winner's tint on each. Nothing here is a number the old
    block did not have.

    Clubs are named by name throughout -- slate.py converts StatsAPI's ids
    before they reach here -- so this draws all four leagues identically.
    """
    games = detail.get("series") or []
    home, away = row.get("home"), row.get("away")
    home_nick, away_nick = _name(home, row), _name(away, row)
    year = (games[-1]["date"][:4] if games and games[-1].get("date") else "")
    head = (f'<section class="pk h2"><h4>{_("pnl_h2h")}'
            + (f' <span class="h2yr">{esc(year)}</span>' if year else "")
            + "</h4>")
    if not games or not home or not away:
        return head + f'<p class="pnl-note">{_("pnl_h2h_none")}</p></section>'

    wins = {home: 0, away: 0}
    runs = {home: 0, away: 0}
    for g in games:
        winner = g["away"] if g["away_runs"] > g["home_runs"] else g["home"]
        if winner in wins:
            wins[winner] += 1
        # Runs are totalled per CLUB, not per side of the fixture: the same
        # two clubs swap home and away through a season series, so adding
        # home_runs to the home club would credit half the games to the
        # wrong team.
        for side in ("away", "home"):
            club = g.get(side)
            if club in runs:
                runs[club] += g.get(f"{side}_runs", 0) or 0
    aw, hw = wins[away], wins[home]
    lead = (_("pnl_h2h_lead", team=esc(away_nick), w=aw, l=hw) if aw > hw else
            _("pnl_h2h_lead", team=esc(home_nick), w=hw, l=aw) if hw > aw else
            _("pnl_h2h_even", w=aw, l=hw))

    # A swept series is 100/0 and still has to draw as a bar rather than as a
    # single block with a number floating off one end, so both ends keep a
    # sliver. With no games at all we have already returned above.
    total = max(1, aw + hw)
    a_pct = max(4.0, min(96.0, aw / total * 100))
    bar = (f'<div class="h2bar"><span class="h2n">{aw}</span>'
           f'<i class="h2track"><b class="h2a" style="width:{a_pct:.1f}%"></b></i>'
           f'<span class="h2n">{hw}</span></div>')
    rate = ""
    if len(games):
        rate = (f'<div class="h2rate">'
                f'<span>{_("sc_runs", v=f"{runs[away] / len(games):.1f}")}</span>'
                f'<span>{_("sc_runs", v=f"{runs[home] / len(games):.1f}")}</span>'
                f'</div>')

    # Most recent LAST, so the strip reads left to right like a calendar.
    shown = games[-SERIES_SHOWN:]
    chips = []
    for g in shown:
        away_won = g["away_runs"] > g["home_runs"]
        winner = g["away"] if away_won else g["home"]
        hi = max(g["away_runs"], g["home_runs"])
        lo = min(g["away_runs"], g["home_runs"])
        # Lit for the AWAY club of today's card, whichever dugout it was in
        # that night. The caption says whose colour it is, because a chip
        # tinted for "the winner" would tell a reader nothing they cannot
        # already read off the score.
        cls = " on" if winner == away else ""
        chips.append(f'<div class="h2c{cls}">'
                     f'<span class="h2cd">{esc(_md(g["date"]))}</span>'
                     f'<span class="h2cs">{hi}&ndash;{lo}</span></div>')
    hidden = len(games) - len(shown)
    # Its own line. Run on after the caption it read as part of the score --
    # "CLE 7-6 6 earlier meetings not shown" -- which is a sentence with a
    # number in the wrong place and a score with a digit too many.
    more = (f'<p class="h2note">{_("pnl_h2h_more", n=hidden, s=_pl(hidden))}</p>'
            if hidden else "")

    last = games[-1]
    last_winner = (last["away"] if last["away_runs"] > last["home_runs"]
                   else last["home"])
    note = _("sc_chip_note", team=esc(away_nick), date=esc(_md(last["date"])),
             who=esc(_abbr(last_winner)),
             score=f'{max(last["away_runs"], last["home_runs"])}'
                   f'&ndash;{min(last["away_runs"], last["home_runs"])}')

    return (head + f'<p class="pnl-note">{lead}</p>{bar}{rate}'
            f'<div class="h2strip">{"".join(chips)}</div>'
            f'<p class="h2note">{note}</p>{more}</section>')


# The comparison table's rows, in the reference's order, with which
# direction is better. W-L carries no direction on purpose: a starter's
# record is mostly a report on the lineup behind him, which is already why
# it sits out of the projection.
# What the two starters are compared on. The season block first, then the
# strikeout numbers this site actually models -- which used to sit under the
# table as a stacked list per pitcher, where comparing them meant reading two
# paragraphs and doing the subtraction yourself.

# The prop half. "better" means "lit", not "superior": a higher projected
# strikeout count is not a better pitcher, it is the number this board is
# about, and lighting the larger one is what makes the pair scannable. The
# posted line is lit on neither side -- it is the market's number, not a
# contest between the two men.


SP_ALIAS = {"ARI": "AZ"}


def _club_key(abbr: str) -> str:
    return SP_ALIAS.get(abbr, abbr)


def _side_props(row: dict, props) -> tuple[dict, dict]:
    """Which prop row belongs to which side of this game, by club.

    The pitcher board writes StatsAPI's abbreviation ("ATL"); the odds feed
    writes the full club name. _abbr reconciles the two for the card's own
    headings and _club_key covers the one club they spell differently.

    A club neither abbreviation recognises still lands on the right side when
    the other one is already placed: a game has exactly two starters, so the
    remaining slot is not a guess. With both unmatched they are left out
    rather than assigned by order.
    """
    a_prop = h_prop = {}
    rest = []
    for p in props or []:
        team = p.get("team")
        if team and team == _club_key(_abbr(row.get("away"))):
            a_prop = p
        elif team and team == _club_key(_abbr(row.get("home"))):
            h_prop = p
        else:
            rest.append(p)
    if len(rest) == 1 and bool(a_prop) != bool(h_prop):
        if a_prop:
            h_prop = rest[0]
        else:
            a_prop = rest[0]
    return a_prop, h_prop


# One row of the mirrored sheet: the label, the field on vs_roster, and the
# two ends of its scale. `lo` is the value that draws an empty bar and `hi`
# the value that fills it, so a stat where LOWER is better simply has hi
# below lo and the same formula draws it. That is what lets the caption say
# one thing -- longer means more suppressed -- about all four rows.
#
# The ends are fixed rather than taken from the two pitchers on the card. A
# relative scale would fill one bar completely on every card ever drawn,
# including the cards where both starters have been hit hard, which is the
# one thing the panel must not say.
SV_ROWS = (
    ("sv_k",     "k_pct",  0.10, 0.40),
    ("sv_bb",    "bb_pct", 0.14, 0.02),
    ("sv_avg",   "avg",    0.320, 0.140),
    ("sv_xwoba", "xwoba",  0.400, 0.220),
)


def _sv_fmt(field: str, v: float) -> str:
    """A rate as a percentage, an average as a three-place decimal."""
    if field in ("k_pct", "bb_pct"):
        return f"{v * 100:.1f}"
    return f"{v:.3f}".lstrip("0")


def _sv_fill(lo: float, hi: float, v: float) -> float:
    span = hi - lo
    if not span:
        return 0.0
    return max(0.0, min(1.0, (v - lo) / span))


def _sv_column(prop: dict, hand: str, era, opponent: str,
               starter: str = "") -> str:
    """One starter against the other club's hitters, or nothing.

    The name comes from the prop row and the hand and ERA from the side of
    the card, so the two have to be the same man. They are matched by club
    and the clubs are spelled differently by the two feeds -- the ARI/AZ
    case -- so when the abbreviations fail the fallback places a pitcher by
    elimination. That fallback is right far more often than not, but "far
    more often than not" is not a standard for printing one pitcher's
    strikeout rate under another one's name.

    So they are checked. A disagreement drops the column rather than drawing
    a confident hybrid of two men, and the other side still renders.
    """
    vs = (prop or {}).get("vs_roster") or {}
    if not vs.get("pa"):
        return ""
    if starter and _short_name(prop.get("name")) != _short_name(starter):
        return ""
    hand_txt = _("sv_rhp") if hand == "R" else _("sv_lhp") if hand == "L" else ""
    meta = " &middot; ".join(
        x for x in (hand_txt, f"{era:.2f} ERA" if era else "") if x)
    rows = []
    for label, field, lo, hi in SV_ROWS:
        v = vs.get(field)
        if v is None:
            # A dash, and the bar's track with nothing in it. Dropping the
            # row would silently shorten one column against the other, which
            # reads as one pitcher being better rather than less documented.
            rows.append(f'<div class="sv-r"><span class="sv-l">{_(label)}</span>'
                        f'<span class="sv-v">&mdash;</span>'
                        f'<i class="sv-track"></i></div>')
            continue
        rows.append(
            f'<div class="sv-r" data-f="{field}">'
            f'<span class="sv-l">{_(label)}</span>'
            f'<span class="sv-v">{_sv_fmt(field, v)}</span>'
            f'<i class="sv-track"><b style="width:'
            f'{_sv_fill(lo, hi, v) * 100:.1f}%"></b></i></div>')
    return (f'<div class="sv-col">'
            f'<div class="sv-n">{esc(_short_name(prop.get("name")))}</div>'
            f'<div class="sv-m">{meta}</div>'
            f'<div class="sv-m">{_("sv_line", team=esc(_nickname(opponent)), n=vs["pa"])}</div>'
            f'{"".join(rows)}</div>')


def _sv_sheet(row: dict, detail: dict, props=None) -> str:
    """Both starters against the lineup each actually has to get out.

    This is the block the whole panel was rebuilt around. A starter's season
    ERA says how he has pitched; this says how he has pitched AGAINST THESE
    HITTERS, which is the question a reader opening a matchup card is
    actually asking and the one no free scoreboard answers.

    Two columns, mirrored, with the same four scales on both sides. Mirrored
    rather than interleaved because these are not a contest: both starters
    can have dominated their opposite number's lineup, and a shared centre
    column would invite a reader to read the pair as a winner and a loser.

    The numbers come from the pitcher board's roster panel, which is one
    StatsAPI request per hitter and already made every morning. Nothing here
    costs anything new.
    """
    a_prop, h_prop = _side_props(row, props)
    cols = [
        _sv_column(a_prop, detail.get("away_hand", ""),
                   detail.get("away_starter_era"), row.get("home"),
                   detail.get("away_starter", "")),
        _sv_column(h_prop, detail.get("home_hand", ""),
                   detail.get("home_starter_era"), row.get("away"),
                   detail.get("home_starter", "")),
    ]
    if not any(cols):
        return ""
    # A side with no history keeps its half of the grid. An empty column is a
    # column that says "these two have never met", which is worth the space;
    # collapsing to one column would centre the other and break the mirror.
    cols = [c or f'<div class="sv-col sv-empty">{_("sv_none")}</div>'
            for c in cols]
    notes = []
    for prop in (a_prop, h_prop):
        vs = (prop or {}).get("vs_roster") or {}
        if vs.get("xwoba") is not None and vs.get("xwoba_span"):
            notes.append(_("sv_xwoba_note", span=esc(vs["xwoba_span"]),
                           n=vs.get("xwoba_pa") or 0))
            break
    return (f'<section class="pk sv"><h4>{_("sv_head")}</h4>'
            f'<div class="sv-grid">{cols[0]}{cols[1]}</div>'
            f'<p class="sv-note">{_("sv_note")}'
            + (f' &middot; {notes[0]}' if notes else "")
            + "</p></section>")


# ---------------------------------------------- NCAAB detail: Team Stats
# The owner's reference is ESPN's Team Stats comparison: value / label /
# value, a split bar under each, away striped on the left, home in its own
# colour on the right. Season averages from our own ESPN box-score store.
TS_ROWS = (("ats", "ts_ats"), ("h1", "ts_h1"),
           ("pts", "ts_pts"), ("opp", "ts_opp"), ("fg", "ts_fg"),
           ("reb", "ts_reb"), ("ast", "ts_ast"), ("blk", "ts_blk"),
           ("stl", "ts_stl"))


def _ats_rate(v):
    """Cover rate in percent, pushes left out; None with no decided games."""
    if not v or (v[0] + v[1]) == 0:
        return None
    return 100 * v[0] / (v[0] + v[1])


# First-half bars split on halftime margin + this, so a team that trails at
# the half on average still gets a visible share.
TS_H1_FLOOR = 20.0


def _ts_val(key: str, v) -> str:
    if key == "h1":
        return f"{v[0]:.1f}-{v[1]:.1f}" if v else "&ndash;"
    if key == "ats":
        if not v or sum(v) == 0:
            return "&ndash;"
        return f"{v[0]}-{v[1]}" + (f"-{v[2]}" if v[2] else "")
    if v is None:
        return "&ndash;"
    return f"{v:.0f}%" if key == "fg" else f"{v:.1f}"


def _ts_bar(key: str, a, b) -> str:
    """Decorative: the numbers either side already say it."""
    if key == "h1":
        a = max(0.0, a[0] - a[1] + TS_H1_FLOOR) if a else None
        b = max(0.0, b[0] - b[1] + TS_H1_FLOOR) if b else None
    if key == "ats":
        # Cover rate on the same two 0-100 tracks as FG%.
        a, b, key = _ats_rate(a), _ats_rate(b), "fg"
    if key == "fg":
        # Two separate 0-100 tracks, as in the reference: a percentage is not
        # a share of the two teams' total.
        aw = max(0.0, min(100.0, a or 0.0))
        bw = max(0.0, min(100.0, b or 0.0))
        return (f'<div class="ts-bar ts-pct" aria-hidden="true">'
                f'<span class="ts-trk"><i class="ts-l" style="width:{aw:.1f}%"></i></span>'
                f'<span class="ts-trk ts-trk-r"><i class="ts-r" style="width:{bw:.1f}%"></i></span>'
                f'</div>')
    if a is None or b is None or (a + b) <= 0:
        return '<div class="ts-bar" aria-hidden="true"></div>'
    left = round(100 * a / (a + b), 1)
    return (f'<div class="ts-bar" aria-hidden="true">'
            f'<i class="ts-l" style="width:{left:.1f}%"></i>'
            f'<i class="ts-r" style="width:{100 - left:.1f}%"></i></div>')


def _ts_side(t: dict, cls: str) -> str:
    rank = (f'<span class="ts-rk">{int(t["rank"])}</span>'
            if t.get("rank") else "")
    # Record and ESPN BPI rank on one muted line. The AP number (top 25)
    # sits before the name as in the reference; BPI ranks all 365 teams, so
    # every game shows a ranking whether or not either side is in the poll.
    bits = [esc(t.get("record", ""))] if t.get("record") else []
    power = t.get("power_rank") or t.get("bpi")
    if power:
        bits.append(f'{esc(t.get("rank_label") or "BPI")} #{int(power)}')
    rec = (f'<span class="ts-rec">{" &middot; ".join(bits)}</span>'
           if bits else "")
    return (f'<span class="ts-sw {cls}" aria-hidden="true"></span>'
            f'<span class="ts-nm">{rank}{esc(t.get("name", ""))}</span>{rec}')


# Football's panel is narrower on purpose: the owner bets on ATS, scoring
# and turnovers; yards per play is the one efficiency number added.
TS_ROWS_CFB = (("ats", "ts_ats"), ("pts", "ts_pts"), ("opp", "ts_opp"),
               ("giv", "ts_giv"), ("tak", "ts_tak"), ("ypp", "ts_ypp"))


def ncaaf_record(s: dict) -> str:
    """How the NCAAF board's FPI number has done: the side it liked against
    the spread, and its Brier score beside the market's (lower is better)."""
    s = s or {}
    if not s.get("graded"):
        return (f'<section class="wrap board-page"><p class="pnl-note">'
                f'{_("cf_none")}</p></section>')
    w, l, p = (s.get("fpi_ats") or [0, 0, 0])
    ats = f"{w}-{l}" + (f"-{p}" if p else "")
    brier = (_("cf_brier", m=f'{s["brier"]:.3f}',
                k=f'{s["market_brier"]:.3f}' if s.get("market_brier") is not None
                else "&ndash;") if s.get("brier") is not None else "")
    return (f'<section class="wrap board-page"><h2>{_("cf_graded")}</h2>'
            f'<p class="sys-rec"><b>{_("cf_ats", r=ats)}</b> &middot; '
            f'{_("cf_n", n=s["graded"])}</p>'
            f'<p class="pnl-note">{brier}</p></section>')


def _ncaab_notes(row: dict) -> list[str]:
    """The market spread and total, then BPI's line and projected score --
    the same two lines a football card carries, from the board row itself."""
    home, away = row.get("home", ""), row.get("away", "")
    m = row.get("markets") or {}
    notes = []
    sp = (m.get("spreads") or {})
    if sp.get("point") is not None:
        home_pt = sp["point"] if sp.get("side_a", "home") == "home" else -sp["point"]
        fav, pt = (home, home_pt) if home_pt <= 0 else (away, -home_pt)
        text = "Spread: Pick'em" if pt == 0 else f"Spread: {fav} {pt:g}"
        tot = (m.get("totals") or {}).get("point")
        if tot is not None:
            text += f" \u00b7 Total {tot:g}"
        notes.append(text)
    proj = (row.get("model") or {}).get("proj")
    if proj:
        margin = proj[0] - proj[1]
        fav = home if margin > 0 else away
        line = ("BPI line: Pick'em" if round(margin, 1) == 0
                else f"BPI line: {fav} -{abs(margin):.1f}")
        hi, lo = max(proj), min(proj)   # the favourite's score first
        notes.append(f"{line} \u00b7 Projected {hi:.0f}-{lo:.0f} "
                     f"(total {proj[0] + proj[1]:.0f})")
    return notes


def _line_note(row: dict) -> str:
    """The lines a football card carries on its face: the spread and total,
    and FPI's own line beside them."""
    notes = row.get("line_note") or (_ncaab_notes(row)
                                     if row.get("league") == "ncaab" else [])
    if not notes:
        return ""
    return ('<div class="cv-lines">'
            + "".join(f"<p>{esc(n)}</p>" for n in notes) + "</div>")


def _team_stats(ts: dict, spec=None) -> str:
    """The Team Stats table for one NCAAB game, or "" without both teams."""
    away, home = (ts or {}).get("away"), (ts or {}).get("home")
    if not away or not home:
        return ""
    colour = home.get("color") or ""
    style = ""
    if len(colour.lstrip("#")) == 6:
        style = f' style="--ts-c:{_legible("#" + colour.lstrip("#"))}"'
    rows = []
    for key, label in (spec or TS_ROWS):
        a = (away.get("stats") or {}).get(key)
        b = (home.get("stats") or {}).get(key)
        if key in ("ats", "h1") and a is None and b is None:
            continue    # a sheet written before this row existed
        rows.append(
            f'<tr class="ts-v"><td>{_ts_val(key, a)}</td>'
            f'<th scope="row">{_(label)}</th>'
            f'<td>{_ts_val(key, b)}</td></tr>'
            f'<tr class="ts-b"><td colspan="3">{_ts_bar(key, a, b)}</td></tr>')
    return (f'<section class="ts"{style}><table class="ts-t">'
            f'<caption class="ts-cap">{_("ts_title")}</caption>'
            f'<thead><tr>'
            f'<th scope="col" class="ts-a">{_ts_side(away, "ts-sw-a")}</th>'
            f'<th scope="col"><span class="ts-vh">{_("ts_stat")}</span></th>'
            f'<th scope="col" class="ts-h">{_ts_side(home, "ts-sw-h")}</th>'
            f'</tr></thead><tbody>{"".join(rows)}</tbody></table></section>')


def _detail_panel(row: dict) -> str:
    """Everything behind the card's disclosure: the three blocks of 5a.

    Three, and only three. The panel had grown a price table, an eight-row
    season comparison, tonight's strikeout props, a matchup verdict and two
    paragraphs of prose about each starter underneath the design it was
    built to -- every one of them true, and together four times the height
    of the thing a reader opened the card to see.

    So the rule here is subtraction. Who is playing, how these two clubs
    have gone against each other, and how tonight's arms have gone against
    tonight's bats. Anything that is reference rather than answer belongs on
    the board page that is about it -- the strikeout numbers on the pitcher
    board, the prices on the face of the card.
    """
    if row.get("league") in COLLEGE:
        ts = _team_stats(row.get("team_stats") or {},
                         TS_ROWS_CFB if row.get("league") == "ncaaf" else None)
        if ts:
            return f'<div class="pnl">{ts}</div>'
    detail = row.get("detail") or {}
    head = _scorecard(row, detail)
    sheet = _sv_sheet(row, detail, _PROPS.get(row.get("event_id") or ""))
    if not (head or sheet):
        return ""
    # The head-to-head block is the only one that speaks when it has nothing
    # ("they have not met yet this season"), which is worth saying on a card
    # that has other material and is just noise on a card that has none. So
    # it is included only alongside something else, which the guard above is.
    return (f'<div class="pnl">{head}{_h2h_block(row, detail)}'
            f'{sheet}</div>')


def _disclosure(row: dict) -> str:
    """The card's expandable half, or nothing.

    College basketball has no starters, no props and -- until enough finals
    are stored -- no form. A <details> that opens onto an empty box reads as
    a broken page, so a card with nothing behind it gets no control at all.
    """
    panel = _detail_panel(row)
    if not panel:
        return ""
    close = _("close")
    return (f'<details class="gmore" data-close="{close}">'
            f'<summary>{_("cv_detail")}</summary>'
            f'<div class="gmore-in">{panel}</div></details>')


def board_cards(rows: list[dict], empty_key: str = "board_empty") -> str:
    """Every game on a board, or a line saying there are none.

    Does not group by league. A caller wanting per-league headings renders
    each league's rows in its own call, which keeps this function ignorant of
    page layout.
    """
    if not rows:
        return f'<p class="empty-board">{_(empty_key)}</p>'
    return '<div class="board">' + "".join(board_card(r) for r in rows) + "</div>"


# ------------------------------------------------------------------ +EV ---
# The page is generated rather than written because every threshold on it is
# a live value from config.py and every figure a live value from the board.
# A page that restated them in prose would be wrong the first time either
# moved, and this is the one page whose whole claim is that it is not.

EV_PRICES = (-200, -110, 100, 150, 900)


def _ev_hold(width) -> float:
    """Hold implied by a two-way market that wide, quoted symmetrically."""
    if not width:
        return 0.0
    p = 100.0 + width / 2.0
    imp = p / (p + 100.0)
    return (2 * imp - 1) / (2 * imp)


def _ev_best_side(board: dict):
    """The best-priced side anywhere on the board, or None."""
    best = None
    for entry in (board.get("leagues") or {}).values():
        for game in entry.get("games") or []:
            for market, m in (game.get("markets") or {}).items():
                for tag in ("home", "away"):
                    edge = m.get(f"edge_{tag}")
                    if edge is None:
                        continue
                    if best is None or edge > best["edge"]:
                        best = {"edge": edge, "game": game, "market": market,
                                "tag": tag, "best": m.get(f"best_{tag}") or {},
                                "fair": m.get(f"fair_{tag}"),
                                "books": m.get("books"),
                                "point": m.get("point")}
    return best


# --------------------------------------------------------- batter homers ---
# A projection, and drawn as one: the chance is the headline, the three
# numbers behind it sit underneath, and the calibration strip above the cards
# says what the model has actually delivered so far.

def _bvp_line(r: dict) -> str:
    """This batter's career line against tonight's starter, in one row.

    The board's own unit is already one batter against one named pitcher,
    so a whole table would be five columns of one row. A sentence carries
    the same five numbers and does not have to be scanned.

    The sample is almost always small -- five to twenty-five plate
    appearances -- so it is set at label weight beside the projection rather
    than beside it in size, and nothing on the card is derived from it.
    """
    who = _short_name(r.get("vs"))
    bvp = r.get("bvp")
    if not bvp or not bvp.get("pa"):
        return (f'<div class="bvp none">'
                f'{_("bvp_never", who=esc(who))}</div>')
    avg = bvp.get("avg")
    return (f'<div class="bvp">'
            + _("bvp_line", who=esc(who),
                h=bvp.get("h", 0), ab=bvp.get("ab", 0),
                hr=bvp.get("hr") if bvp.get("hr") is not None else 0,
                k=bvp.get("k") if bvp.get("k") is not None else 0,
                avg=(f"{avg:.3f}".lstrip("0") if avg is not None else "&mdash;"))
            + "</div>")


def _group_card(title: str, when, sub: str, rows_html: str,
                accent: str | None = None, right: str = "",
                detail: str = "") -> str:
    """The canvas card, for a board whose unit is a LIST rather than a number.

    The home run, hits and NFL boards each show several players under one
    pitcher or one defence, so they cannot borrow board_card's shape
    literally -- there is no single figure to set at 30px. What they take
    instead is the vocabulary: the same head, the same mono sub-line, the
    same footer rule, the same disclosure button. Five boards through one
    function, so the next change to the card is one change.
    """
    style = f' style="--accent:{accent}"' if accent else ""
    right_html = f'<span class="cv-time">{right}</span>' if right else ""
    return f"""
        <article class="pb-card bat-card"{style}>
          <div class="pb-body">
            <div class="cv-head">
              <h3 class="cv-tm">{title}</h3>
              <span class="cv-time">{esc(game_time(when)) if when else ""}</span>
            </div>
            <div class="cv-sub">{sub}{(" &middot; " + right_html) if right else ""}</div>
            <div class="bats">{rows_html}</div>
            {detail}
          </div>
        </article>"""


def lineup_note(rows) -> str:
    """Which of the two things this board is showing, said plainly.

    The page used to carry one fixed sentence -- "club regulars, not
    tonight's lineup" -- which was true at nine in the morning and false by
    six in the evening, on the same page, with nothing to tell the reader
    which it was.
    """
    clubs = {(r.get("team_id"), r.get("commence_time")) for r in rows or []}
    posted = {(r.get("team_id"), r.get("commence_time")) for r in rows or []
              if r.get("lineup")}
    if not rows or not posted:
        return _("lu_regulars")
    key = "lu_posted" if len(posted) == len(clubs) else "lu_mixed"
    return _(key, n=len(posted), of=len(clubs))


def batter_cards(rows: list[dict]) -> str:
    """Tonight's most dangerous bats, grouped by the game they appear in."""
    if not rows:
        return f'<div class="empty-board">{_("bat_empty")}</div>'
    games: dict = {}
    for r in rows:
        games.setdefault((r.get("commence_time"), r.get("vs")), []).append(r)

    out = []
    for (when, pitcher), group in games.items():
        club = esc(_nickname(group[0].get("team")))
        hand = group[0].get("vs_hand") or ""
        hand_txt = (f' ({_("mx_right") if hand == "R" else _("mx_left")})'
                    if hand in ("L", "R") else "")
        park = group[0].get("park") or 1.0
        park_cls = "good" if park > 1.03 else "bad" if park < 0.97 else ""
        bats = "".join(f"""
          <div class="bat">
            <div class="bat-n">{esc(b.get('name',''))}</div>
            <div class="bat-c"><b>{b['chance'] * 100:.1f}%</b></div>
            <div class="bat-w">{_("bat_season",
                hr=b.get('hr', 0), pa=f"{b.get('pa', 0):,}",
                rate=f"{b.get('hr_rate', 0) * 100:.1f}")}</div>
            {_bvp_line(b)}
            {hit_strip(b.get("recent"), 0.5, key="value", priced=False)}
          </div>""" for b in group)
        out.append((group[0], _group_card(
            club, when,
            _("bat_facing", who=esc(pitcher or "?"), hand=hand_txt,
              rate=f"{(group[0].get('vs_hr_per_bf') or 0) * 100:.1f}"),
            bats,
            accent=team_color(group[0].get("team")) or "var(--line-2)",
            right=f'<span class="bat-park {park_cls}">'
                  f'{_("bat_park", v=f"{park:.2f}")}</span>')))
    return _game_board(out, lambda c: c[1], sides=lambda c: _mlb_sides(c[0]),
                       when=lambda c: c[0].get("commence_time") or "",
                       nickname=True)


def batter_calibration(summary: dict) -> str:
    """What the model promised against what happened. Not a win rate."""
    n = (summary or {}).get("graded") or 0
    if not n:
        return f'<p class="pnl-note">{_("bat_ungraded")}</p>'
    exp, act = summary["expected"], summary["actual"]
    rows = "".join(
        f'<tr><th>{esc(b["label"])}</th>'
        f'<td class="en">{b["n"]}</td>'
        f'<td class="en">{b["expected"]:.1f}%</td>'
        f'<td class="en {"egain" if b["actual"] >= b["expected"] else "eloss"}">'
        f'{b["actual"]:.1f}%</td></tr>'
        for b in summary.get("buckets") or [])
    # Formatted before the f-string, not inside it. An f-string expression
    # cannot be split across two adjacent literals, and this is the third
    # time that trap has been hit in this file.
    exp_txt, act_txt = f"{exp:.1f}", f"{act:.1f}"
    head = f'<p class="pnl-note">{_("bat_cal", n=n, exp=exp_txt, act=act_txt)}</p>' 
    if not rows:
        return head
    return (head + f'<div class="sscroll"><table class="stbl num">'
            f'<tr><th></th><td class="en hd">{_("bat_n")}</td>'
            f'<td class="en hd">{_("bat_promised")}</td>'
            f'<td class="en hd">{_("bat_delivered")}</td></tr>'
            f'{rows}</table></div>')


# ----------------------------------------------------------------- hits ---
# A sibling of the batter home-run board, same layout, different column:
# the hits column of payloads the home-run board already fetches.

def hit_cards(rows: list[dict]) -> str:
    """Tonight's best chances of a hit, grouped by the game they appear in."""
    if not rows:
        return f'<div class="empty-board">{_("hit_empty")}</div>'
    games: dict = {}
    for r in rows:
        games.setdefault((r.get("commence_time"), r.get("vs")), []).append(r)

    out = []
    for (when, pitcher), group in games.items():
        club = esc(_nickname(group[0].get("team")))
        hand = group[0].get("vs_hand") or ""
        hand_txt = (f' ({_("mx_right") if hand == "R" else _("mx_left")})'
                    if hand in ("L", "R") else "")
        park = group[0].get("park") or 1.0
        park_cls = "good" if park > 1.03 else "bad" if park < 0.97 else ""
        vs_rate = f"{(group[0].get('vs_h_per_bf') or 0) * 100:.1f}"
        bats = "".join(f"""
          <div class="bat">
            <div class="bat-n">{esc(b.get('name',''))}</div>
            <div class="bat-c"><b>{b['chance'] * 100:.1f}%</b></div>
            <div class="bat-w">{_("hit_season",
                h=b.get('h', 0), pa=f"{b.get('pa', 0):,}",
                rate=f"{b.get('hit_rate', 0) * 100:.1f}")}</div>
            {_bvp_line(b)}
            {hit_strip(b.get("recent"), 0.5, key="value", priced=False)}
          </div>""" for b in group)
        accent = team_color(group[0].get('team')) or 'var(--line-2)'
        out.append((group[0], _group_card(
            club, when,
            _("hit_facing", who=esc(pitcher or "?"), hand=hand_txt,
              rate=vs_rate),
            bats, accent=accent,
            right=f'<span class="bat-park {park_cls}">'
                  f'{_("hit_park", v=f"{park:.2f}")}</span>')))
    return _game_board(out, lambda c: c[1], sides=lambda c: _mlb_sides(c[0]),
                       when=lambda c: c[0].get("commence_time") or "",
                       nickname=True)


def hit_calibration(summary: dict) -> str:
    """What the model promised against what happened. Not a win rate."""
    n = (summary or {}).get("graded") or 0
    if not n:
        return f'<p class="pnl-note">{_("hit_ungraded")}</p>'
    return batter_calibration(summary)


# ------------------------------------------------------------------ NFL ---
# Three yardage boards (passing, rushing, receiving) and one touchdown
# board, siblings of the hits board above: same card grid, same calibration
# note, a different number underneath. yard_cards and td_cards both group by
# game exactly as hit_cards does; yard_accuracy is the continuous-error
# sibling of hit_calibration's bucketed one, because a yardage projection is
# a number, not a chance.
#
# The badge that names a player's position is given its own class, "ppos",
# rather than the bare "pos" the brief's own snippet uses -- base.css already
# defines a bare .pos rule for the monthly chart's positive bars
# (height:180px, flex column), and a player's position badge would have
# inherited that layout by accident.

def _game_sides(row: dict) -> tuple[str, str]:
    """(away, home) for an NFL row.

    nflverse game ids are season_week_AWAY_HOME, which is the only place a
    row says which side is at home -- `team` and `opponent` are written from
    the player's point of view and cannot say. Falls back to the player's own
    pair when the id is not the shape we expect, because a header naming the
    right two clubs in the wrong order still beats no header.
    """
    parts = (row.get("game_id") or "").split("_")
    if len(parts) >= 4 and parts[2] and parts[3]:
        return parts[2], parts[3]
    return row.get("opponent", ""), row.get("team", "")


def _mlb_sides(row: dict) -> tuple[str, str]:
    """(away, home) for an MLB row, from is_home rather than from a guess.

    probable_starters has carried is_home all along; it simply never
    reached the rows. `team` and `opponent` are written from one side's
    point of view and cannot say which dugout is which on their own.
    """
    a, b = row.get("team") or "", row.get("opponent") or row.get("vs_team") or ""
    return (b, a) if row.get("is_home") else (a, b)


def _game_board(rows, card, *, sides, key=None, nickname: bool = False,
                when=None) -> str:
    """Cards grouped into the fixtures they belong to, with a game picker.

    Written for the NFL boards after "it's all over the place, I don't know
    which team each player is on", and then wanted for MLB for the same
    reason -- so it takes the two things that differ as arguments: how a
    row names its two clubs, and what makes two rows the same fixture.

    The picker is progressive. The chips are ordinary anchors pointing at
    each section, so with no JavaScript they scroll to the right group and
    nothing is lost; board.js upgrades them to a filter, which on a
    sixteen-game slate is the difference between finding a player and
    scrolling for him.
    """
    if not rows:
        return ""
    # Rows are not always dicts: the home-run and hits boards hand this
    # (row, rendered card) pairs, because their card is already a group of
    # several batters and only one of those rows can speak for it.
    when = when or (lambda r: r.get("commence_time") or "")

    def fixture(r):
        if key is not None:
            return key(r)
        away, home = sides(r)
        # frozenset, so both clubs' rows land in one group no matter which
        # side wrote them. Paired with first pitch, because two clubs meet
        # twice in a doubleheader and those are different games.
        return (when(r), frozenset({away, home}))

    games: dict = {}
    for r in rows:
        games.setdefault(fixture(r), []).append(r)
    order = sorted(games, key=lambda g: (when(games[g][0]), str(g)))

    chips = [f'<a href="#" class="gchip on" data-game="">{_("nfl_allgames")}</a>']
    blocks = []
    for i, gid in enumerate(order):
        group = games[gid]
        away, home = sides(group[0])
        if nickname:
            away, home = _nickname(away), _nickname(home)
        # One side unknown -- an older data file written before the board
        # stored the opposing club -- heads the group with the club it does
        # know rather than with "ATL @ ", which reads as a rendering fault.
        title = (f'{esc(away)} <span>@</span> {esc(home)}'
                 if away and home else esc(away or home))
        chip = f"{away} @ {home}" if away and home else (away or home)
        tip = esc(game_time(when(group[0])))
        slug = f"g{i}"
        chips.append(f'<a href="#s-{slug}" class="gchip" data-game="{slug}">'
                     f'{esc(chip)}</a>')
        blocks.append(
            f'<section class="gsec" id="s-{slug}" data-game="{slug}">'
            f'<div class="gsec-h">'
            f'<h3>{title}</h3>'
            f'<span>{tip}</span></div>'
            f'<div class="pb-grid">{"".join(card(r) for r in group)}</div>'
            f'</section>')
    return (f'<nav class="gsel" aria-label="{_("nfl_pickgame")}">'
            + "".join(chips) + "</nav>" + "".join(blocks))


def _nfl_board(rows: list[dict], card) -> str:
    if not rows:
        return f'<div class="empty-board">{_("nfl_empty")}</div>'
    return _game_board(rows, card, sides=_game_sides,
                       key=lambda r: r.get("game_id") or "")


def _nfl_card(r: dict, *, big: str, label: str, ref: float, ref_label: str,
              key: str, fmt, unit: str = "", strip_line: float | None = None,
              rows_html: str = "", bar_pct: float | None = None,
              base_fmt=None, extra: str = "") -> str:
    """One NFL player, in the pitcher card's shape.

    Asked for directly: the NFL boards listed three players under a club
    header with a per-game average each, and no sense of whether any of
    them had done it lately. The pitcher card answers that with a strip,
    so these get the same card rather than a second design that means the
    same thing.
    """
    recent = r.get("recent") or []
    over = sum(1 for g in recent if (g.get(key) or 0) > (strip_line if strip_line is not None else ref))
    last5 = recent[-5:]
    over5 = sum(1 for g in last5 if (g.get(key) or 0) > (strip_line if strip_line is not None else ref))
    n, n5 = len(recent), len(last5)

    # No games, no section. "Last 0 games / 0-0" is worse than silence: it
    # looks like a player who has never produced rather than a board built
    # before his season started.
    strip_sec = ""
    if recent:
        strip_sec = (
            f'<section class="pk">'
            f'<h4>{_("nfl_last", n=n, s=_pl(n))}</h4>'
            f'<div class="pb-striphead"><span></span>'
            f'<span class="pb-rec"><b>{over}&ndash;{max(0, n - over)}</b> '
            f'{ref_label} &middot; {_("l5")} '
            f'<b>{over5}&ndash;{max(0, n5 - over5)}</b></span></div>'
            f'{_strip(recent, strip_line if strip_line is not None else ref, key=key, fmt=fmt)}'
            f'</section>')
    inner = (strip_sec +
             f'<section class="pk"><h4>{_("nfl_defence")}</h4>'
             f'<div class="pb-rows">{rows_html}</div></section>')

    # A bar only where there is something to be a fraction OF. A chance is
    # a fraction of 100 and draws honestly; a yardage projection has no
    # posted line to sit against on this board, and scaling it to itself
    # would draw the same bar on every card -- decoration that looks like
    # a measurement. Same rule as the lineless pitcher card.
    # The same strip the pitcher board carries, on the face. These boards are
    # never priced, so there is no market cell to put beside it: the third
    # cell names our own number where that number means something, and is
    # dropped where it does not.
    face_strip = hit_strip(recent, strip_line if strip_line is not None else ref,
                           key=key, priced=False)

    bar = ""
    if bar_pct is not None:
        w = max(0.0, min(100.0, bar_pct))
        bar = (f'<div class="cv-bar">'
               f'<i class="cv-fill" style="width:{w:.1f}%"></i></div>')
    return f"""
        <div class="pb-card">
          <div class="pb-body">
            <div class="cv-head">
              <div class="cv-id">
                <h3 class="cv-tm">{esc(r.get('name', ''))}</h3>
                {_pos_badge(r.get('position', ''))}
              </div>
              <span class="cv-time">{esc(game_time(r.get('commence_time')))}</span>
            </div>
            <div class="cv-sub">{esc(r.get('team', ''))} vs {esc(r.get('opponent', ''))}</div>
            {extra}
            <div class="cv-row">
              <span class="cv-lab">{label}</span>
              <span class="cv-pct">{big}{f'<span class="cv-u">{esc(unit)}</span>' if unit else ''}</span>
            </div>
            {bar}
            {face_strip}
            <div class="cv-foot">
              <span class="gm">{(base_fmt or fmt)(r.get('per_game') or 0)} {_("nfl_base")}</span>
            </div>
            <details class="gmore" data-close="{_("close")}">
              <summary>{_("nfl_detail")}</summary>
              <div class="gmore-in"><div class="pnl">{inner}</div></div>
            </details>
          </div>
        </div>"""


def yard_cards(rows: list[dict], unit: str = "yds") -> str:
    """Projected yardage, one card per player.

    Was one card per club with three players listed inside it. The card
    now matches the pitcher board: the projection at display size, the run
    of recent games as a strip, and the defensive context behind the
    disclosure.
    """
    def yd(v):
        return f"{v:.0f}"

    def card(r):
        proj = r.get("projection") or 0
        opp = esc(r.get("opponent", ""))
        rows_html = (
            f'<div class="pb-row"><span>{_("nfl_allows", opp=opp)}</span>'
            f'<b>{r.get("opp_allowed", 0):.0f} {esc(unit)}</b></div>'
            f'<div class="pb-row"><span>{_("nfl_league")}</span>'
            f'<b>{r.get("league_allowed", 0):.0f} {esc(unit)}</b></div>')
        return _nfl_card(
            r, big=yd(proj), label=_("nfl_proj"), ref=proj,
            ref_label=_("nfl_clears", v=yd(proj)),
            key="value", fmt=yd, unit=unit, rows_html=rows_html)

    return _nfl_board(rows, card)


def td_cards(rows: list[dict]) -> str:
    """Anytime touchdown chance, one card per player.

    The strip's reference is half a touchdown rather than the chance
    itself: the market is "anytime", so one is a hit and zero is not, and
    a two-touchdown game is not twice as much of a hit. Comparing a count
    against a percentage would be a category error drawn as a chart.
    """
    def td(v):
        return f"{v:g}"

    def card(r):
        chance = (r.get("chance") or 0) * 100
        opp = esc(r.get("opponent", ""))
        rows_html = (
            f'<div class="pb-row"><span>{_("nfl_allows", opp=opp)}</span>'
            f'<b>{r.get("opp_allowed", 0):.2f}</b></div>'
            f'<div class="pb-row"><span>{_("nfl_league")}</span>'
            f'<b>{r.get("league_allowed", 0):.2f}</b></div>')
        return _nfl_card(
            r, big=f"{chance:.1f}%", label=_("nfl_chance"), ref=chance,
            ref_label=_("nfl_scored"), key="value", fmt=td,
            strip_line=0.5, rows_html=rows_html, bar_pct=chance,
            # "0.671 per game" is a float that escaped. The strip's own
            # ticks stay whole, because those are touchdown counts.
            base_fmt=lambda v: f"{v:.2f}")

    return _nfl_board(rows, card)


def _nba_sides(row: dict) -> tuple[str, str]:
    """(away, home) for an NBA row.

    The schedule says which club is hosting and build() writes the row from
    one player's point of view, so `is_home` is carried rather than guessed
    at -- the mistake the NFL boards had to unpick from game ids.
    """
    if row.get("is_home"):
        return row.get("opponent", ""), row.get("team", "")
    return row.get("team", ""), row.get("opponent", "")


def nba_cards(rows: list[dict], unit: str = "") -> str:
    """Tonight's NBA projections, grouped into the game each belongs to.

    The NFL card, unchanged: the same projection-against-a-defence argument
    in a sport that plays every night, so it gets the same shape rather than
    a second design meaning the same thing.
    """
    if not rows:
        return f'<div class="empty-board">{_("nba_empty")}</div>'

    def fmt(v):
        return f"{v:.0f}" if abs(v - round(v)) < 0.05 else f"{v:.1f}"

    def card(r):
        proj = r.get("projection") or 0
        opp = esc(r.get("opponent", ""))
        rows_html = (
            f'<div class="pb-row"><span>{_("nfl_allows", opp=opp)}</span>'
            f'<b>{r.get("opp_allowed", 0):.1f}</b></div>'
            f'<div class="pb-row"><span>{_("nfl_league")}</span>'
            f'<b>{r.get("league_allowed", 0):.1f}</b></div>'
            f'<div class="pb-row"><span>{_("nba_average")}</span>'
            f'<b>{r.get("per_game", 0):.1f}</b></div>')
        # What this opponent gives up to men in his position. Context, not
        # an input: adjusting the projection by it was measured and made the
        # projection worse, so it is reported and nothing more.
        if r.get("pos_allowed") is not None:
            rank = (_("nba_pos_rank", r=r["pos_rank"],
                      ord=_ordinal(r["pos_rank"]), n=r["pos_of"])
                    if r.get("pos_rank") else "")
            label = _("nba_pos_allows",
                      opp=esc(r.get("opponent", "")),
                      pos=_(POS_LABEL.get(r.get("pos_slot", ""),
                                          "nba_pos_any")))
            rows_html += (f'<div class="pb-row"><span>{label}</span>'
                          f'<b>{r["pos_allowed"]:.1f}{rank}</b></div>')
            if r.get("pos_league"):
                rows_html += (
                    f'<div class="pb-row"><span>{_("nba_pos_league")}</span>'
                    f'<b>{r["pos_league"]:.1f}</b></div>')
        vs = r.get("vs_opp") or {}
        # How he has gone against this club. In basketball two teams meet
        # three or four times a season, so this is a real matchup sample --
        # unlike the two or three plate appearances a baseball card hedges
        # about -- and it belongs on the face rather than behind a tap.
        if vs:
            line = _("nba_vs", n=vs["games"], s=_pl(vs["games"]),
                     team=esc(r.get("opponent", "")),
                     v=f'{vs["per_game"]:.1f}',
                     hi=fmt(vs["best"]), lo=fmt(vs["worst"]))
            face = f'<div class="bvp">{line}</div>'
        else:
            face = (f'<div class="bvp none">'
                    f'{_("nba_vs_never", team=esc(r.get("opponent", "")))}'
                    f'</div>')
        return _nfl_card(
            r, big=fmt(proj), label=_("nfl_proj"), ref=proj,
            ref_label=_("nfl_clears", v=fmt(proj)),
            key="value", fmt=fmt, unit=unit, rows_html=rows_html,
            base_fmt=lambda v: f"{v:.1f}", extra=face)

    return _game_board(rows, card, sides=_nba_sides,
                       key=lambda r: r.get("game_id") or "")


# ------------------------------------------------------ first seven innings
def _f7_pct(v) -> str:
    return f"{v * 100:.0f}%"


def f7_cards(rows: list[dict]) -> str:
    """One club per game, with the runs it should score through seven.

    The probability ladder sits on the FACE, not behind the disclosure.
    That is the whole board: a reader has a line in front of them at a
    sportsbook and wants our number for it, and making them tap to find it
    would be like putting the price behind a tap on a pricing site.

    Three rungs, not the book's own line, because reading the book's line
    on this market costs a credit per game and this board is free. The
    reader matches whichever rung their book is offering.
    """
    if not rows:
        return f'<div class="empty-board">{_("f7_empty")}</div>'

    def card(r):
        probs = r.get("probs") or {}
        ladder = "".join(
            f'<div class="pb-row"><span>{_("f7_over", v=line)}</span>'
            f'<b>{_f7_pct(probs[line])}</b></div>'
            for line in ("2.5", "3.5", "4.5") if probs.get(line) is not None)
        if not ladder:
            # A projection with no shape behind it. Said out loud rather
            # than drawn as an empty row, because a blank where a
            # percentage goes reads as zero percent.
            ladder = f'<p class="pnl-note">{_("f7_noshape")}</p>'

        hand = (_("sv_rhp") if r.get("pitcher_hand") == "R"
                else _("sv_lhp") if r.get("pitcher_hand") == "L" else "")
        era = r.get("pitcher_era")
        arm = " &middot; ".join(x for x in (
            esc(_short_name(r.get("pitcher"))), hand,
            f"{era:.2f} ERA" if era else "") if x)

        # The working. Every factor that multiplied into the number, in the
        # order the model applies them, so a reader can see WHICH of the
        # four is doing the work on this card -- a 4.4 that is all park and
        # a 4.4 that is all bullpen are different bets.
        #
        # The two innings counts are computed into locals first. Nesting
        # them inside the f-string needed quotes inside quotes inside a
        # format spec, which does not parse and is unreadable when it does.
        sp_ip = float(r.get("sp_innings") or 0)
        pen_ip = max(0.0, 7 - sp_ip)
        sp_lab = _("f7_starter", ip=f"{sp_ip:.1f}")
        pen_lab = _("f7_pen", ip=f"{pen_ip:.1f}")
        inner = (
            f'<section class="pk"><h4>{_("f7_working")}</h4>'
            f'<div class="pb-rows">'
            f'<div class="pb-row"><span>{_("f7_base")}</span>'
            f'<b>{r.get("league_f7", 0):.2f}</b></div>'
            f'<div class="pb-row"><span>{_("f7_offence")}</span>'
            f'<b>{r.get("offence", 1):.2f}&times;</b></div>'
            f'<div class="pb-row"><span>{sp_lab}</span>'
            f'<b>{r.get("sp_index", 1):.2f}&times;</b></div>'
            f'<div class="pb-row"><span>{pen_lab}</span>'
            f'<b>{r.get("pen_index", 1):.2f}&times;</b></div>'
            f'<div class="pb-row"><span>{_("f7_park")}</span>'
            f'<b>{r.get("park", 1):.2f}&times;</b></div>'
            f'</div></section>')

        where = _("f7_at") if r.get("is_home") else _("f7_away")
        # The park is one of the four factors, so the card names it rather
        # than carrying the field silently the way the row used to.
        park_txt = (f' &middot; {esc(r["venue"])}' if r.get("venue") else "")
        return f"""
        <div class="pb-card">
          <div class="pb-body">
            <div class="cv-head">
              <h3 class="cv-tm">{esc(_nickname(r.get('team', '')))}</h3>
              <span class="cv-time">{esc(game_time(r.get('commence_time')))}</span>
            </div>
            <div class="cv-sub">{where} {esc(_nickname(r.get('opponent', '')))}
              &middot; {arm}{park_txt}</div>
            <div class="cv-row">
              <span class="cv-lab">{_("f7_proj")}</span>
              <span class="cv-pct">{r.get('projection', 0):.1f}<span
                class="cv-u">{_("f7_runs")}</span></span>
            </div>
            <div class="pb-rows f7-ladder">{ladder}</div>
            <details class="gmore" data-close="{_("close")}">
              <summary>{_("f7_detail")}</summary>
              <div class="gmore-in"><div class="pnl">{inner}</div></div>
            </details>
          </div>
        </div>"""

    return '<div class="pb-grid">' + "".join(card(r) for r in rows) + "</div>"


def f7_accuracy(summary: dict) -> str:
    """How far off the projections were, and whether the ladder was honest.

    Two different claims, so two different tests. The mean is judged
    against the flat league average -- a model that cannot beat "everyone
    scores 3.6" has learned nothing about pitching or parks. The ladder is
    judged on whether the clubs it gave 44% to went over about 44% of the
    time, which is the only thing that makes a probability a price.
    """
    graded = (summary or {}).get("graded") or 0
    mae = (summary or {}).get("mae")
    if not graded or mae is None:
        return f'<p class="pnl-note">{_("f7_ungraded")}</p>'
    base = summary.get("baseline_mae")
    text = _("f7_mae", n=graded, v=f"{mae:.2f}")
    if base is not None:
        rel = ("f7_beats" if mae < base
               else ("f7_loses" if mae > base else "f7_level"))
        text += " " + _(rel, v=f"{base:.2f}")
    out = f'<p class="disclaimer">{text}</p>'

    # The resolution test. MAE and a pooled hit-rate can both look fine on a
    # model with no discrimination at all -- this is the table that asks
    # whether a club projected at 4.5 really does outscore one projected at
    # 3.0. It was being computed every morning and rendered nowhere, which
    # is the same bug as the lineup tables, so it is the first thing here.
    bands = summary.get("bands") or []
    if bands:
        def band(b):
            label = _("f7_band", lo=f'{b["lo"]:g}', hi=f'{b["hi"]:g}',
                      n=b["n"]) if b["hi"] < 90 else _(
                          "f7_band_top", lo=f'{b["lo"]:g}', n=b["n"])
            return (f'<div class="pb-row"><span>{label}</span>'
                    f'<b>{b["projected"]:.2f} &rarr; {b["actual"]:.2f}</b>'
                    f'</div>')
        out += (f'<div class="pb-rows">'
                f'{"".join(band(b) for b in bands)}</div>'
                f'<p class="pnl-note">{_("f7_band_note")}</p>')

    rungs = summary.get("over_rate") or []
    if rungs:
        def rung(r):
            label = _("f7_rung", v=f'{r["line"]:g}', n=r["n"])
            return (f'<div class="pb-row"><span>{label}</span>'
                    f'<b>{_f7_pct(r["said"])} &rarr; {_f7_pct(r["were"])}</b>'
                    f'</div>')

        rows = "".join(rung(r) for r in rungs)
        out += (f'<div class="pb-rows">{rows}</div>'
                f'<p class="pnl-note">{_("f7_rung_note")}</p>')
    return out


def nba_accuracy(summary: dict) -> str:
    """How far off the projections were -- against doing nothing at all.

    There is no posted line on this board, so the benchmark is the simplest
    alternative to having a model: the player's own season average, with no
    opponent adjustment. A backtest over 37 nights of last season put the
    adjustment inside one standard error of zero on points and assists, so
    this comparison is the honest headline rather than a footnote, and it
    keeps being published as the sample grows.
    """
    graded = (summary or {}).get("graded") or 0
    if not graded:
        return f'<p class="pnl-note">{_("nba_ungraded")}</p>'
    mae, base = summary.get("mae"), summary.get("baseline")
    if mae is None:
        return f'<p class="pnl-note">{_("nba_ungraded")}</p>'
    text = _("nba_mae", n=graded, v=f"{mae:.2f}")
    if base is not None:
        rel = ("nba_beats" if mae < base
               else ("nba_loses" if mae > base else "nba_level"))
        text += " " + _(rel, v=f"{base:.2f}")
    return f'<p class="disclaimer">{text}</p>'


def td_calibration(summary: dict) -> str:
    """What the model promised against what happened. Not a win rate.

    batter_calibration's bucketed markup fits a chance-based verdict
    exactly as well here as it does for a home run -- the touchdown page
    just needs its own empty state. Without this it fell through to
    batter_calibration directly, and batter_calibration's own empty-state
    copy talks about the batter's season total, which is how a public NFL
    page ended up reading like a baseball one. hit_calibration is the
    same fix for the same reason; follow it.
    """
    n = (summary or {}).get("graded") or 0
    if not n:
        return f'<p class="pnl-note">{_("nfl_ungraded")}</p>'
    return batter_calibration(summary)


def yard_accuracy(summary: dict) -> str:
    """Mean error against the unadjusted baseline, like for like.

    Every sibling renderer goes through i18n; this one used to hardcode
    its sentences in English only, which is invisible in an English-only
    build but is exactly the kind of gap that leaves half a site
    untranslatable the day a second language ships.
    """
    n = (summary or {}).get("graded") or 0
    if not n:
        return f'<p class="pnl-note">{_("nfl_ungraded")}</p>'
    mae = summary.get("mae")
    base = summary.get("baseline_mae")
    comp = summary.get("mae_on_baseline_rows")
    bits = [_("nfl_acc_headline", mae=mae, n=n, s=i18n.plural(n, LANG))]
    if base is not None and comp is not None:
        verdict = _("nfl_acc_earning" if comp < base
                   else "nfl_acc_not_earning")
        bits.append(_("nfl_acc_compare", bn=summary.get("baseline_n"),
                      comp=comp, base=base, verdict=verdict))
    return '<p class="pnl-note">' + " ".join(bits) + "</p>"


# ------------------------------------------------------------------ form ---
# Every league's table, computed from the finals this project stores for
# itself. MLB could take it from StatsAPI instead, but one code path that
# works for four leagues beats two that each work for some of them.

def _test_position_badge() -> None:
    """The position is its own chip beside the name, not a letter trailing
    the matchup. A bare "F" after "ATL vs ORL" reads as part of the
    fixture; that is what confused the reader."""
    row = {"name": "Giannis Antetokounmpo", "team": "MIL", "opponent": "ORL",
           "position": "F", "commence_time": "2026-10-22T23:30:00Z",
           "line": 30.5, "over": 0.54, "under": 0.46, "proj": 31.2}
    html = nba_cards([row])
    assert 'class="cv-pos"' in html, "no position chip on the card"
    assert "Forward" in html, "the position is still a bare letter"
    sub = re.search(r'class="cv-sub">(.*?)</div>', html, re.S)
    assert sub and "Forward" not in sub.group(1) and "&middot;" not in sub.group(1), \
        f"position still trailing the matchup: {sub and sub.group(1)!r}"
    # NFL abbreviations are already unambiguous and must pass through intact.
    nfl = yard_cards([{**row, "position": "WR", "name": "A.J. Brown"}])
    assert ">WR<" in nfl, "NFL position was mangled"


def _test_ncaab_system() -> None:
    """The System tabs: full names, the play, the count, every check marked;
    and the NCAAB board naming clubs in full while MLB keeps nicknames."""
    def ck(key, mark, *v):
        return {"key": key, "mark": mark, "v": list(v)}
    row = {"tab": "system", "event_id": "e1", "date": "2026-11-12",
           "commence_time": "2026-11-13T00:00Z",
           "home": {"id": "221", "name": "Pittsburgh Panthers", "abbr": "PITT"},
           "away": {"id": "2335", "name": "Liberty Flames", "abbr": "LIB"},
           "side": "away", "line": 11.5, "est": False, "ml": 480,
           "checks": [ck("reb", "y", 40.0, 33.0), ck("ats", "y", 5, 1, "away"),
                      ck("bpi", "y", 55, 48, 11.5), ck("h2h", "na", 0, 1),
                      ck("depth", "y", 3, 1), ck("form", "n", 2, 5, "away"),
                      ck("def", "y", 6.0, 0.0)],
           "passed": 5, "applicable": 6, "postseason": False,
           "under_note": False, "total": 140.5}
    html = system_cards([row])
    assert "Liberty Flames +11.5" in html, "the play names the club in full"
    assert "Liberty Flames @ Pittsburgh Panthers" in html
    assert "+480" in html
    assert ">5<" in html and "of 6" in html
    assert html.count('class="ck-m"') == 7, "every check is listed"
    assert 'role="img" aria-label="Passed"' in html
    assert 'aria-label="Failed"' in html and 'aria-label="Not enough data"' in html
    assert "40.0 vs 33.0" in html and "5-1" in html and "#55" in html
    assert "est." not in html
    h1 = dict(row, tab="1h", side="home", line=-6.0, est=True, ml=None,
              checks=[c for c in row["checks"] if c["key"] != "bpi"])
    html = system_cards([h1])
    assert "Pittsburgh Panthers 1H -6" in html and "est." in html
    assert "ML" not in html
    assert system_cards([dict(row, line=0.0)]).count("Liberty Flames PK") == 1
    post = system_cards([dict(row, postseason=True, under_note=True,
                              checks=row["checks"] + [ck("scorer", "y", 81.2)])])
    assert "under" in post.lower() and "81.2" in post
    assert "No games pass" in system_cards([])

    rec = system_record({"w": 7, "l": 3, "p": 1, "pending": 2, "units": 3.36,
                         "checks": {"reb": [5, 1], "depth": [2, 2]}})
    assert "7-3-1" in rec and "+3.36" in rec and "5-1" in rec
    assert "Rebounding" in rec
    assert "No graded plays yet" in system_record({"w": 0, "l": 0, "p": 0,
                                                    "pending": 0, "units": 0.0,
                                                    "checks": {}})

    # The board: Flames vs Panthers was the confusion.
    game = {"event_id": "g", "league": "ncaab", "commence_time": "2026-11-13T00:00Z",
            "home": "Pittsburgh Panthers", "away": "Liberty Flames",
            "model": {"home_win_prob": 0.8, "away_win_prob": 0.2}}
    card = board_card(game)
    assert "Liberty Flames @" in card and "Pittsburgh Panthers" in card, card[:400]
    mlb = board_card(dict(game, league="mlb", home="San Diego Padres",
                          away="Chicago Cubs"))
    assert "Cubs <span>@</span> Padres" in mlb


# ------------------------------------------------------- NCAAB System tabs
CK_LABEL = {"reb": "ck_reb", "bpi": "ck_bpi", "h2h": "ck_h2h",
            "depth": "ck_depth", "def": "ck_def", "scorer": "ck_scorer"}
CK_MARK = {"y": ("&#10003;", "ck_pass"), "n": ("&#10007;", "ck_fail"),
           "na": ("&ndash;", "ck_na")}


def _spread(v) -> str:
    """+11.5, -6, PK. Whole numbers lose the .0 -- a book prints -6, not -6.0."""
    if v is None:
        return ""
    if v == 0:
        return "PK"
    txt = f"{v:+.1f}"
    return txt[:-2] if txt.endswith(".0") else txt


def _ck_label(c: dict) -> str:
    key = c["key"]
    if key in ("ats", "form"):
        role = (c.get("v") or [None, None, "away"])[-1]
        return _(f"ck_{key}_{'home' if role == 'home' else 'away'}")
    return _(CK_LABEL.get(key, key))


def _ck_detail(c: dict) -> str:
    v = c.get("v") or []
    if c["mark"] == "na" and c["key"] in ("reb", "depth", "def"):
        return _("ck_thin")
    try:
        if c["key"] == "reb":
            return _("ck_reb_d", a=f"{v[0]:.1f}", b=f"{v[1]:.1f}")
        if c["key"] in ("ats", "form"):
            if c["key"] == "form":
                return _("ck_form_d", w=v[0], l=v[1] - v[0], n=v[1])
            return _("ck_ats_d", w=v[0], l=v[1])
        if c["key"] == "bpi":
            if v[0] is None or v[1] is None:
                return _("ck_bpi_none")
            if v[2] < 10:
                return _("ck_bpi_small")
            return _("ck_bpi_d", a=v[0], b=v[1], g=_spread(v[2]))
        if c["key"] == "h2h":
            return _("ck_h2h_d", w=v[0], n=v[1]) if c["mark"] != "na" \
                else _("ck_h2h_few", n=v[1])
        if c["key"] == "depth":
            return _("ck_depth_d", a=v[0], b=v[1])
        if c["key"] == "def":
            return _("ck_def_d", a=f"{v[0]:+.1f}", b=f"{v[1]:+.1f}")
        if c["key"] == "scorer":
            return _("ck_scorer_d", v=f"{v[0]:.1f}") if v and v[0] is not None else ""
    except (IndexError, TypeError, ValueError):
        return ""
    return ""


def _system_card(r: dict) -> str:
    home, away = r["home"]["name"], r["away"]["name"]
    club = r[r["side"]]["name"]
    half = f" {_('sys_1h')}" if r.get("tab") == "1h" else ""
    est = (f' <span class="cv-u">{_("sys_est")}</span>' if r.get("est") else "")
    ml = r.get("ml")
    sub = esc(f"{away} @ {home}")
    if ml is not None:
        sub += f" &middot; ML {esc(f'{ml:+d}')}"
    items = []
    for c in r.get("checks", []):
        glyph, label = CK_MARK.get(c["mark"], CK_MARK["na"])
        detail = _ck_detail(c)
        items.append(
            f'<li class="ck-is-{c["mark"]}">'
            f'<span class="ck-m" role="img" aria-label="{_(label)}">{glyph}</span>'
            f'<span class="ck-n">{_ck_label(c)}</span>'
            f'<span class="ck-d">{esc(detail)}</span></li>')
    note = (f'<p class="ck-note">{_("sys_unders")}</p>'
            if r.get("under_note") else "")
    return f"""
        <div class="pb-card">
          <div class="pb-body">
            <div class="cv-head">
              <h3 class="cv-tm">{esc(club)}{half} {esc(_spread(r.get("line")))}{est}</h3>
              <span class="cv-time">{esc(game_time(r.get("commence_time")))}</span>
            </div>
            <div class="cv-sub">{sub}</div>
            <div class="cv-row">
              <span class="cv-lab">{_("sys_checks")}</span>
              <span class="cv-pct">{r.get("passed", 0)}<span class="cv-u">{_("sys_of", n=r.get("applicable", 0))}</span></span>
            </div>
            <ul class="ck">{"".join(items)}</ul>
            {note}
          </div>
        </div>"""


def system_cards(rows: list[dict]) -> str:
    """Tonight's qualifying plays for one tab. Strongest first, as stored."""
    if not rows:
        return f'<div class="empty-board">{_("sys_none")}</div>'
    return ('<div class="pb-grid">'
            + "".join(_system_card(r) for r in rows) + "</div>")


def system_record(summary: dict) -> str:
    """The tab's record and how each check has done when it passed."""
    s = summary or {}
    if not (s.get("w") or s.get("l") or s.get("p")):
        return f'<p class="pnl-note">{_("sys_no_record")}</p>'
    units = s.get("units", 0.0)
    head = (f'<p class="sys-rec"><b>{s["w"]}-{s["l"]}-{s["p"]}</b> &middot; '
            f'{units:+.2f} {_("sys_units")}'
            + (f' &middot; {_("sys_pending", n=s["pending"])}' if s.get("pending") else "")
            + "</p>")
    order = ("reb", "ats", "bpi", "h2h", "depth", "form", "def", "scorer")
    lines = []
    for key in order:
        wl = (s.get("checks") or {}).get(key)
        if not wl:
            continue
        label = _ck_label({"key": key, "v": [None, None, "away"]}) \
            if key not in ("ats", "form") else _(f"ck_{key}_any")
        lines.append(f'<li><span class="ck-n">{label}</span>'
                     f'<span class="ck-d">{wl[0]}-{wl[1]}</span></li>')
    tail = (f'<p class="ck-cap">{_("sys_by_check")}</p><ul class="ck ck-rec">'
            + "".join(lines) + "</ul>") if lines else ""
    return head + tail


def _test_team_stats() -> None:
    """NCAAB detail: the Team Stats comparison from the owner's screenshot."""
    ark = {"name": "Arkansas Razorbacks", "color": "9d2235", "rank": 12,
           "record": "1-0", "games": 1,
           "stats": {"pts": 106.0, "opp": 61.0, "fg": 55.2, "reb": 43.0,
                     "ast": 19.0, "blk": 7.0, "stl": 16.0}}
    uva = {"name": "Virginia Cavaliers", "color": "f84c1e", "rank": 9,
           "record": "2-0", "games": 2,
           "stats": {"pts": 93.0, "opp": 66.0, "fg": 51.0, "reb": 39.5,
                     "ast": 21.5, "blk": 3.5, "stl": 15.0}}
    row = {"event_id": "g", "league": "ncaab", "home": "Virginia Cavaliers",
           "away": "Arkansas Razorbacks", "commence_time": "2026-11-09T18:00Z",
           "model": {"home_win_prob": 0.6, "away_win_prob": 0.4},
           "team_stats": {"away": ark, "home": uva}}
    html = _detail_panel(row)
    assert "<table" in html and "<caption" in html, "a real table"
    labels = ["Points", "Points Against", "Field Goal %", "Rebounds",
              "Assists", "Blocks", "Steals"]
    pos = [html.index(f'<th scope="row">{l}</th>') for l in labels]
    assert pos == sorted(pos), "rows in the example's order"
    assert "106.0" in html and "93.0" in html and "55%" in html and "51%" in html
    assert "Arkansas Razorbacks" in html and "Virginia Cavaliers" in html
    assert ">12<" in html and ">9<" in html and "1-0" in html and "2-0" in html
    # BPI under every team, ranked in the AP or not.
    unranked = dict(ark, rank=None, bpi=88)
    html_b = _detail_panel(dict(row, team_stats={"away": unranked,
                                                 "home": dict(uva, bpi=112)}))
    assert "BPI #88" in html_b and "BPI #112" in html_b
    assert ">12<" not in html_b, "no AP number for an unranked team"
    assert "BPI #" not in _detail_panel(row), "no BPI on file, nothing shown"
    assert html.index("Arkansas") < html.index("Virginia"), "away left, home right"
    # Bars split by share: 106 / (106 + 93) = 53.3%.
    assert "width:53.3%" in html and "width:46.7%" in html
    assert html.count('aria-hidden="true"') >= 7, "bars are decorative"
    # Home colour drives the right-hand bar.
    assert "--ts-c:" in html
    # ATS row, first: W-L (push only when there is one), cover-rate bars.
    at = _detail_panel(dict(row, team_stats={
        "away": dict(ark, stats=dict(ark["stats"], ats=[3, 1, 0])),
        "home": dict(uva, stats=dict(uva["stats"], ats=[1, 2, 1]))}))
    assert at.index('<th scope="row">ATS</th>') < at.index('<th scope="row">Points</th>')
    assert ">3-1<" in at and ">1-2-1<" in at
    assert "width:75.0%" in at and "width:33.3%" in at, "cover rate, pushes left out"
    no_ats = _detail_panel(dict(row, team_stats={
        "away": dict(ark, stats=dict(ark["stats"], ats=[0, 0, 0])), "home": uva}))
    assert '<th scope="row">ATS</th>' in no_ats and "&ndash;" in no_ats
    # 1st Half row, right after ATS: "for-against", bar split on the
    # halftime margin + 20 so a team trailing at the half still gets a bar.
    hh = _detail_panel(dict(row, team_stats={
        "away": dict(ark, stats=dict(ark["stats"], ats=[1, 0, 0], h1=[57.0, 22.5])),
        "home": dict(uva, stats=dict(uva["stats"], ats=[0, 1, 0], h1=[36.0, 16.0]))}))
    order = [hh.index(f'<th scope="row">{l}</th>') for l in ("ATS", "1st Half", "Points")]
    assert order == sorted(order), "ATS, then 1st Half, then Points"
    assert ">57.0-22.5<" in hh and ">36.0-16.0<" in hh
    assert "width:57.7%" in hh, "(34.5+20)/((34.5+20)+(20+20))"
    assert '<th scope="row">1st Half</th>' not in _detail_panel(row), \
        "no first-half data, no row"
    # A missing stat shows a dash and an empty bar, not a crash.
    thin = dict(uva, stats=dict(uva["stats"], reb=None))
    html2 = _detail_panel(dict(row, team_stats={"away": ark, "home": thin}))
    assert "&ndash;" in html2
    # No team sheet: the old panel, unchanged.
    assert "<caption" not in _detail_panel(dict(row, team_stats=None))
    # MLB never gets it.
    assert "<caption" not in _detail_panel(dict(row, league="mlb"))


def _test_ncaaf_card() -> None:
    """NCAAF: full names, the spread and FPI lines on the face, and a
    football Team Stats panel behind Game Detail."""
    def side(name, rank, ats, pts, opp, giv, tak, ypp):
        return {"name": name, "color": "9e1b32", "rank": rank, "record": "8-2",
                "power_rank": 3, "rank_label": "FPI",
                "stats": {"ats": ats, "pts": pts, "opp": opp, "giv": giv,
                          "tak": tak, "ypp": ypp}}
    row = {"event_id": "f1", "league": "ncaaf", "commence_time": "2026-11-15T00:30Z",
           "home": "Alabama Crimson Tide", "away": "LSU Tigers",
           "model": {"home_win_prob": 0.81, "away_win_prob": 0.19,
                     "market_home_prob": 0.72},
           "line_note": ["Spread: Alabama Crimson Tide -6.5 \u00b7 Total 52.5",
                         "FPI line: Alabama Crimson Tide -12.5"],
           "team_stats": {
               "away": side("LSU Tigers", 14, [5, 4, 0], 30.2, 22.1, 1.4, 1.1, 6.1),
               "home": side("Alabama Crimson Tide", 3, [6, 3, 1], 35.0, 18.4, 0.9, 1.8, 6.8)}}
    card = board_card(row)
    # Redesign B: college cards are pick cards; the panel sits behind Details.
    assert "LSU Tigers @" in card and "Alabama Crimson Tide" in card
    labels = ["ATS", "Points", "Points Against", "Turnovers", "Takeaways",
              "Yards per Play"]
    pos = [card.index(f'<th scope="row">{l}</th>') for l in labels]
    assert pos == sorted(pos), "football rows, in order"
    assert '<th scope="row">Rebounds</th>' not in card
    assert "FPI #3" in card and "BPI #" not in card
    assert ">6.8<" in card and ">0.9<" in card
    # The board's record: FPI's side against the spread, and Brier vs market.
    rec = ncaaf_record({"graded": 10, "pending": 2, "brier": 0.1812,
                        "market_brier": 0.1904, "fpi_ats": [6, 4, 0]})
    assert "6-4" in rec and "0.181" in rec and "0.190" in rec and "10" in rec
    assert "No graded games yet" in ncaaf_record({"graded": 0})
    # NCAAB keeps its own rows.
    nb = board_card(dict(row, league="ncaab", line_note=[], team_stats={
        "away": {"name": "A", "stats": {"reb": 30.0}},
        "home": {"name": "B", "stats": {"reb": 33.0}}}))
    assert '<th scope="row">Rebounds</th>' in nb and "Yards per Play" not in nb


def _test_result_strip() -> None:
    """Started college games: score and verdict on the card, live hooks for
    the browser, and a note when a pick is outside the record."""
    pick = {"side": "away", "team": "Marshall Thundering Herd", "line": 25.5,
            "cover": 0.6588, "gap": 4.5}
    row = {"event_id": "o1", "espn_id": "401", "league": "ncaab",
           "commence_time": "2026-11-09T23:00:00Z",
           "home": "Ohio State Buckeyes", "away": "Marshall Thundering Herd",
           "markets": {"spreads": {"point": -25.5, "side_a": "home"}},
           "model": {"home_win_prob": 0.97, "away_win_prob": 0.03, "margin": 21.0},
           "ats": pick, "final": {"away": 66, "home": 88, "away_short": "Marshall",
                                  "home_short": "Ohio State"}}
    card = board_card(row)
    assert 'class="cv-res"' in card and "Final" in card
    assert "Marshall 66 &ndash; Ohio State 88" in card, "school names, not mascots"
    assert "&#10003; Covered" in card and 'class="won"' in card
    missed = board_card(dict(row, final=dict(row["final"], away=60)))
    assert "&#10007; Missed" in missed and 'class="lost"' in missed
    push = board_card(dict(row, final=dict(row["final"], away=62.5)))
    assert ">Push<" in push
    # Not final yet: an empty strip the browser fills, and the hooks it needs.
    live = board_card(dict(row, final=None))
    assert '<div class="cv-res" hidden data-l="Final|Live|Covered|Missed|Push|Covering|Not covering"></div>' in live, \
        "the empty strip carries its labels for board.js"
    for attr in ('data-sport="ncaab"', 'data-espn="401"', 'data-side="away"',
                 'data-line="25.5"', 'data-tip="2026-11-09T23:00:00Z"',
                 'data-home="Ohio State Buckeyes"', 'data-away="Marshall Thundering Herd"'):
        assert attr in live, attr
    # Outside the record.
    nc = board_card(dict(row, counted=False))
    assert "not counted in the record" in nc
    # Other leagues: no strip, no hooks.
    nba = board_card(dict(row, league="nba", ats=None, final=None))
    assert "cv-res" not in nba and "data-sport" not in nba


def _test_pick_card() -> None:
    """Redesign B: the compact college pick card."""
    teams = {"home": {"id": "204", "color": "dc4405", "abbr": "ORST", "school": "Oregon State"},
             "away": {"id": "331", "color": "a10022", "abbr": "EWU", "school": "Eastern Washington"}}
    row = {"event_id": "ew", "league": "ncaab", "commence_time": "2026-11-10T02:30:00Z",
           "home": "Oregon St Beavers", "away": "Eastern Washington Eagles",
           "markets": {"spreads": {"point": -17.5, "side_a": "home"}, "totals": {"point": 162}},
           "model": {"home_win_prob": 0.9, "away_win_prob": 0.1, "proj": [83.0, 74.0], "margin": 8.9},
           "ats": {"side": "away", "team": "Eastern Washington Eagles", "line": 17.5,
                   "cover": 0.78, "gap": 8.6, "raw": 17.2, "tier": "best"},
           "teams": teams,
           "team_stats": {"away": {"name": "Eastern Washington Eagles", "stats": {"pts": 73.3, "opp": 88.7}},
                          "home": {"name": "Oregon State Beavers", "stats": {"pts": 97.3, "opp": 71.0}}}}
    c = board_card(row)
    assert 'class="gcard pc pc-best"' in c and 'data-tier="best"' in c
    assert ">Best bet<" in c and "Eastern Washington +17.5" in c and ">78%<" in c
    import re as _re
    visible = _re.sub(r"<[^>]+>", " ", c)   # tags and their attributes out
    assert "Eagles" not in visible and "Beavers" not in visible, "school names only"
    assert "Eastern Washington @" in c and "Oregon State" in c
    assert 'src="https://a.espncdn.com/i/teamlogos/ncaa/500/331.png"' in c
    assert 'onerror="this.remove()"' in c and "--c:#a10022" in c and ">EWU<" in c, \
        "a failed logo leaves the team-colour badge"
    for chip in ("Edge <b>+8.6</b>", "Line <b>Oregon State -17.5</b>",
                 "Proj <b>83-74</b>", "Total <b>162</b>"):
        assert chip in c, chip
    assert 'aria-expanded="false" aria-controls="d-ew"' in c and 'id="d-ew" hidden' in c
    assert 'class="cv-res"' in c, "the result strip stays (live/final)"
    assert "Details" not in board_card(dict(row, team_stats=None)), "no panel, no button"
    # Tiers.
    assert 'pc-lean' in board_card(dict(row, ats=dict(row["ats"], tier="lean")))
    passed = board_card(dict(row, ats=dict(row["ats"], tier="pass")))
    assert 'pc-pass' in passed and "Pass" in passed
    # The card shows the tier the pricing posted; a row from before tiers
    # were stored falls back to its gap.
    assert 'pc-best' in board_card(dict(row, ats={k: v for k, v in row["ats"].items() if k != "tier"}))
    # Check the line: amber banner, the reason in words, never "Best bet".
    chk = board_card(dict(row, ats=dict(row["ats"], tier="check", check=True)))
    assert 'pc-check' in chk and 'data-tier="check"' in chk and ">Check the line<" in chk
    assert 'class="pc-warn"' in chk and "17.2 pts off the market on a 17.5-pt spread" in chk
    assert ">Best bet<" not in chk and 'pc-warn' not in c
    assert "pc-pct" not in chk, "no cover % on a line we do not trust"
    # No pick: a grey banner, still the card.
    none = board_card(dict(row, ats=None))
    assert 'pc-none' in none and "No pick" in none and 'data-tier="none"' in none
    # Without team info: names from the row, badge without a logo.
    bare = board_card(dict(row, teams=None))
    assert "Eastern Washington Eagles +17.5" in bare and "espncdn" not in bare
    # Other leagues keep their card.
    assert " pc " not in board_card(dict(row, league="nba", ats=None, teams=None))
    # The college board: tier tiles with season records, and the filter.
    head = college_board([row], {"ats_tiers": {"best": [3, 6, 0], "lean": [7, 1, 0],
                                               "check": [2, 2, 0], "pass": [5, 6, 0]}})
    assert "Best bets" in head and "3-6" in head and "7-1" in head
    assert "Check the line" in head and "2-2" in head and head.count("<div><span>") == 4
    assert 'aria-pressed="false">Best bets only' in head and 'aria-pressed="true">All picks' in head
    assert head.count('class="gcard pc') == 1
    # Best bets first, then leans, checks, passes, no pick; by time inside.
    def mk(eid, t, tip):
        return dict(row, event_id=eid, commence_time=tip,
                    ats=(dict(row["ats"], tier=t) if t is not None else None))
    order = college_board([mk("p", "pass", "2026-11-10T23:00:00Z"), mk("b2", "best", "2026-11-11T01:00:00Z"),
                           mk("n", None, "2026-11-10T22:00:00Z"), mk("l", "lean", "2026-11-10T23:30:00Z"),
                           mk("c", "check", "2026-11-10T21:00:00Z"),
                           mk("b1", "best", "2026-11-11T00:00:00Z")], {})
    ids = [order.index(f'id="g-{x}"') for x in ("b1", "b2", "l", "c", "p", "n")]
    assert ids == sorted(ids), "tier first, then time"
    # Grouped by spread size, collapsed, like a sportsbook's market list:
    # 1-5, 5-10, 10-20, 20+ (by the absolute line), then games with no line.
    def sp(eid, pt, t="lean"):
        return dict(row, event_id=eid, markets={"spreads": {"point": pt, "side_a": "home"}},
                    ats=dict(row["ats"], tier=t))
    grp = college_board([sp("a", -3.5), sp("b", 7.0, "best"), sp("c", -5.0), sp("d", -12.5),
                         sp("e", 24.0, "pass"), sp("f", -20.0, "pass"),
                         dict(row, event_id="g", markets={}, ats=None)], {})
    titles = _re.findall(r'<span class="pc-grp-t">([^<]+)</span>', grp)
    assert titles == ["Spread 1\u20135", "Spread 5\u201310", "Spread 10\u201320",
                      "Spread 20+", "No line"], titles
    counts = _re.findall(r'<span class="pc-grp-n"[^>]*>(\d+)</span>', grp)
    assert counts == ["1", "2", "1", "2", "1"], counts
    assert grp.count("<details class=\"pc-grp\"") == 5 and "<details class=\"pc-grp\" open" not in grp
    sec = grp[grp.index("Spread 5\u201310"):grp.index("Spread 10\u201320")]
    assert sec.index('id="g-b"') < sec.index('id="g-c"'), "best first inside a group"
    assert "1 best" in sec and "1 lean" in sec, "tier counts on the collapsed row"
    assert '<details class="pc-grp" data-best="1"><summary><span class="pc-grp-t">Spread 5\u201310' in grp
    empty_grp = college_board([sp("a", -3.5)], {})
    assert "Spread 20+" not in empty_grp, "no empty groups"
    # The college board: one Scoreboard card per game, by start time.
    st = {"away": {"bpi": 278, "stats": {"ats": [2, 1, 0]}},
          "home": {"bpi": 137, "stats": {"ats": [0, 2, 1]}}}
    lst = college_list([dict(row, team_stats=st, espn_id="401"),
                        dict(row, event_id="z", commence_time="2026-11-10T00:00:00Z",
                             final={"away": 70, "home": 90}, team_stats=None,
                             ats=dict(row["ats"], tier="lean"))])
    assert lst.count('<article class="gm ') == 2 and '<div class="gm-list">' in lst
    assert lst.index('id="l-z"') < lst.index('id="l-ew"'), "by time"
    mixed = college_list([dict(row, event_id="late", commence_time="2026-11-11T17:00:00Z"),
                          dict(row, event_id="early", commence_time="2026-11-11T16:00Z")])
    assert mixed.index('id="l-early"') < mixed.index('id="l-late"'), "stamp formats mixed"
    # The summary strip: games, best bets, leans.
    assert "<div><b>2</b><span>Games</span></div><div><b>0</b><span>System plays</span></div>" \
           "<div><b>1</b><span>Best bets</span></div>" in lst
    assert "sys-filter" not in lst, "no System plays, no filter"
    ew = lst[lst.index('id="l-ew"'):]
    assert '<article class="gm gm-best" id="l-ew" data-sport="ncaab" data-espn="401"' in lst
    assert 'data-side="away" data-line="17.5"' in ew
    assert '<span class="gm-st">9:30 PM</span><span class="gm-tier gm-tier-best">Best bet</span>' in ew
    assert "<b>Eastern Washington</b><small>#278  ATS 2-1</small>" in ew
    assert "<b>Oregon State</b><small>#137  ATS 0-2-1</small>" in ew
    assert 'teamlogos/ncaa/500/331.png' in ew, "school logos"
    assert '<span class="gm-sc" data-sc="away"></span>' in ew, "an empty score cell for live scores"
    assert '<span class="gm-pv">Eastern Washington +17.5</span><span class="gm-pc">78<small>%</small></span>' in ew
    assert '<i style="width:78%"></i>' in ew
    assert '<span class="cv-res" hidden data-l="Final|Live|' in ew, "live words for board.js"
    assert "Eagles" not in _re.sub(r"<[^>]+>", " ", lst), "school names only"
    fin = lst[lst.index('<article class="gm gm-lean'):lst.index('id="l-ew"')]
    assert 'class="gm gm-lean is-final"' in fin and '<span class="gm-st">Final</span>' in fin
    assert '<span class="gm-sc" data-sc="away">70</span>' in fin
    assert '<span class="gm-sc w" data-sc="home">90</span>' in fin, "the winner's score is marked"
    assert "Missed" in fin and ">Lean<" in fin, "lost by 20 getting 17.5"
    assert "data-l=" not in fin, "a final card needs no live strip"
    # Details: the chips and the Team Stats panel behind the same button.
    one = college_list([dict(row, team_stats={
        "away": {"name": "Eastern Washington Eagles", "stats": {"pts": 73.3, "opp": 88.7}},
        "home": {"name": "Oregon State Beavers", "stats": {"pts": 97.3, "opp": 71.0}}})])
    assert 'class="pc-more gm-more" aria-expanded="false" aria-controls="ld-ew"' in one
    det = one[one.index('<div class="gm-detail" id="ld-ew" hidden>'):]
    assert "Edge <b>+8.6</b>" in det and "Line <b>Oregon State -17.5</b>" in det
    assert "Points Against" in det
    bare = college_list([dict(row, team_stats=None, markets={}, model={}, ats=None)])
    assert "gm-more" not in bare and "gm-detail" not in bare, "nothing behind it, no button"
    assert 'class="gm gm-none"' in bare and "No pick" in bare
    chk = college_list([dict(row, ats=dict(row["ats"], tier="check"))])
    assert "gm-pc" not in chk and ">Check the line<" in chk, "no cover % on a flagged line"
    assert college_list([]).startswith('<p class="empty-board">')
    # The System: a box on the card naming the play and why, the tag the
    # filter reads, and once final whether each play won.
    sysrow = dict(row, event_id="sy", markets={"spreads": {"point": -4.5, "side_a": "home"},
                                               "totals": {"point": 150.5}},
                  system={"side": "away", "reasons": ["small", "defense"], "under": True})
    # (An "under" left in a day saved before Nov 18 must not show: unders
    # are no longer part of the System.)
    sl = college_list([sysrow, dict(row, event_id="ns")])
    card = sl[sl.index('id="l-sy"') - 40:sl.index('id="l-ns"')]
    assert 'data-sys="1"' in card and 'data-sys="1"' not in sl[sl.index('id="l-ns"') - 40:]
    assert '<span class="gm-sys-tag">System</span>' in card
    assert "<b>Eastern Washington +4.5</b><small>Small underdog \u00b7 Better defense</small>" in card
    assert "Under 150.5" not in card and "Total 145" not in card
    assert "<div><b>1</b><span>System plays</span></div>" in sl
    assert 'data-sf="sys"' in sl and 'aria-pressed="true">All games' in sl
    won = college_list([dict(sysrow, final={"away": 70, "home": 72})])
    sysbox = won[won.index('class="gm-sys"'):]
    sysbox = sysbox[:sysbox.index('class="pc-more')]
    assert sysbox.count('class="won"') == 1 and "Covered" in sysbox, "dog +4.5 lost by 2: covered"
    assert "gm-sys" not in college_list([row]), "no play, no box"
    # The System record on History: forward from go-live, plays graded on finals.
    days = {"2026-11-17": [dict(sysrow, final={"away": 70, "home": 72})],
            "2026-11-18": [dict(sysrow, final={"away": 60, "home": 80}),
                           dict(sysrow, event_id="o", final=None)]}
    rec = rules_record(days, "2026-11-18")
    # Tracked, not played: the favourite's team total under when the
    # defense rule fires. Home -4.5, total 150.5: home implied 77.5.
    # 80-60 is over it (L); the Nov 17 game is before go-live.
    assert rec == {"spread": [0, 1, 0], "tt": [0, 1, 0], "days": 1}, rec
    box = rules_section(days, "2026-11-18")
    assert "0-1" in box and "143-90" in box and "276-216" not in box
    assert "Favorite team total under" in box and "70-42" in box and "Tracking" in box
    small_only = dict(sysrow, system={"side": "away", "reasons": ["small"]},
                      final={"away": 60, "home": 70})
    assert _sys_grade(small_only)["tt"] is None, "tracked only when the defense rule fires"
    held = dict(sysrow, final={"away": 70, "home": 72})
    assert _sys_grade(held)["tt"] == "W", "72 under 77.5"
    assert "team total" not in college_list([held]).lower(), "not shown on the cards"
    # History: a day's record counts Best bets and Leans with a final.
    def h(eid, tier, away, home):
        return dict(row, event_id=eid, ats=dict(row["ats"], tier=tier),
                    final={"away": away, "home": home})
    day_rows = [h("w", "best", 80, 90),     # EWU +17.5, lost by 10: covered
                h("l", "lean", 60, 90),     # lost by 30: missed
                h("p", "pass", 80, 90),     # a pass: not in the record
                dict(row, event_id="u")]    # not final yet
    assert day_record(day_rows) == [1, 1, 0]
    cal = history_calendar({"2026-11-10": day_rows, "2026-11-12": [h("w", "best", 80, 90)]},
                           "ncaab")
    assert "<caption>November 2026</caption>" in cal
    assert '<a href="day-2026-11-10.html"' in cal and 'aria-label="November 10: 1-1"' in cal
    assert '<span class="hc-r">1-1</span>' in cal and '<span class="hc-r">1-0</span>' in cal
    assert '<td class="hc-off"><span class="hc-d">11</span></td>' in cal, "no snapshot, no link"
    assert cal.count('<th scope="col"') == 7
    # November 2026 starts on a Sunday: the 1st sits in the first column.
    first_week = cal[cal.index("<tbody>"):cal.index("</tr>", cal.index("<tbody>"))]
    assert first_week.count("<td") == 7 and '<span class="hc-d">1</span>' in first_week
    assert "2-1" in cal, "season total of Best + Lean"
    assert history_calendar({}, "ncaab").startswith('<p class="empty-board">')
    # Home favorites and home underdogs against the spread, true home
    # courts, overall and by spread size.
    split = {"all": {"fav": [183, 194, 2], "dog": [30, 24, 0]},
             "1\u20135": {"fav": [17, 29, 0], "dog": [24, 14, 0]},
             "20+": {"fav": [84, 72, 0], "dog": [0, 0, 0]}}
    ha = home_away_table(split)
    assert "<caption>" in ha and ha.count('<th scope="row">') == 3
    assert ">Home favorites<" in ha and ">Home underdogs<" in ha
    assert '<th scope="row">All spreads</th><td>183-194<small>49%</small></td><td>30-24<small>56%</small></td>' in ha
    assert '<th scope="row">Spread 1\u20135</th><td>17-29<small>37%</small></td><td>24-14<small>63%</small></td>' in ha
    assert '<td class="ha-none">&mdash;</td>' in ha, "no home underdogs of 20+"
    assert "2 pushes" in ha
    assert home_away_table({"all": {"fav": [0, 0, 0], "dog": [0, 0, 0]}}) == ""
    # The spread calculator: who covered under a number and at-or-above it.
    gms = [[3.5, 1, "h"], [3.5, 1, "a"], [4.0, 0, "h"], [12.0, 1, "h"], [10.0, 0, "a"], [25.0, 1, "p"]]
    cs = cover_split(gms, 10.0)
    assert cs["under"] == {"n": 3, "fav": [1, 2], "dog": [2, 1], "home": [2, 1], "away": [1, 2]}
    assert cs["over"] == {"n": 2, "fav": [2, 0], "dog": [0, 2], "home": [1, 1], "away": [1, 1]}, \
        "a 10 counts as 10 or more; the push is left out"
    calc = spread_calc(gms, 10.0)
    assert '<label for="sc-x">' in calc and 'id="sc-x" type="number"' in calc and 'value="10"' in calc
    assert ">Spread under 10<" in calc and ">Spread 10 or more<" in calc
    assert '<b data-sc-cell="under-f">1-2</b><small data-sc-pct="under-f">33%</small>' in calc
    assert '<b data-sc-cell="over-d">0-2</b><small data-sc-pct="over-d">0%</small>' in calc
    assert 'class="sc-data">[[3.5,"fh"],[3.5,"da"],[4.0,"dh"]' in calc and 'role="status"' in calc
    assert '[25.0,null]' in calc and 'data-letters="fdha"' in calc
    assert spread_calc([]) == ""
    # Totals: overs and unders below a total line and at-or-above it.
    tots = [[140.5, "o"], [141.0, "u"], [150.0, "u"], [150.0, "o"], [160.5, "u"], [160.5, "p"]]
    assert calc_split([[t, r if r != "p" else None] for t, r in tots], 150.0, "ou") == {
        "under": {"n": 2, "o": [1, 1], "u": [1, 1]}, "over": {"n": 3, "o": [1, 2], "u": [2, 1]}}
    tc = total_calc(tots, 150.0)
    assert '<label for="tc-x">' in tc and 'id="tc-x" type="number"' in tc and 'data-letters="ou"' in tc
    assert ">Total under 150<" in tc and ">Total 150 or more<" in tc
    assert '<span>Overs</span><b data-sc-cell="over-o">1-2</b><small data-sc-pct="over-o">33%</small>' in tc
    assert 'data-v="135"' in tc and 'data-v="160"' in tc, "presets around the number"
    assert 'value="150"' in total_calc(tots), "defaults to the middle total"
    assert total_calc([]) == ""
    # The same games from the road team's side: an away favorite is a home
    # underdog's opponent, so its record is that column flipped.
    aw = home_away_table(split, "away")
    assert ">Away favorites<" in aw and ">Away underdogs<" in aw
    assert '<th scope="row">All spreads</th><td>24-30<small>44%</small></td><td>194-183<small>51%</small></td>' in aw
    assert '<th scope="row">Spread 1\u20135</th><td>14-24<small>37%</small></td><td>29-17<small>63%</small></td>' in aw
    assert "Away teams against the spread" in aw and "away covers - home covers" in aw
    page = history_day(day_rows, "2026-11-10", "2026-11-09", None)
    assert 'href="day-2026-11-09.html"' in page and 'href="history.html"' in page
    assert "day-None" not in page and page.count('<article class="gm ') == 4
    assert "1-1" in page
    # Football rows carry the spread and total in their own fields.
    cf = dict(row, league="ncaaf", markets=None, spread_home=-6.5, total=52.5,
              teams={"home": {"school": "Alabama"}, "away": {"school": "LSU"}}, model={})
    cc = board_card(cf)
    assert "Line <b>Alabama -6.5</b>" in cc and "Total <b>52.5</b>" in cc


def _test_pro_list() -> None:
    game = {"event_id": "g1", "league": "nba", "commence_time": "2026-11-13T00:10:00Z",
            "home": "Philadelphia 76ers", "away": "Toronto Raptors",
            "detail": {"home_form": {"w": 8, "l": 3}, "away_form": {"w": 5, "l": 4}},
            "markets": {"spreads": {"point": -10.0, "side_a": "home",
                                    "best_home": {"price": -106}, "best_away": {"price": -104}},
                        "h2h": {"best_home": {"price": -450}, "best_away": {"price": 360}},
                        "totals": {"point": 221.0, "side_a": "over",
                                   "best_home": {"price": -107}, "best_away": {"price": -105}}}}
    def pl(name, team, opp, proj, **kw):
        return dict({"name": name, "team": team, "opponent": opp, "position": "G",
                     "projection": proj, "per_game": 20.0,
                     "recent": [{"value": v} for v in (10, 20, 30, 20, 20, 40)]}, **kw)
    props = {"mk_points": [pl("Tyrese Maxey", "PHI", "TOR", 27.0, pos_rank=16, pos_of=30,
                              pos_allowed=56.0, pos_slot="G"),
                           pl("RJ Barrett", "TOR", "PHI", 21.5, actual=31),
                           pl("Someone Else", "DAL", "MIN", 30.0)],
             "mk_assists": [pl("Nobody Here", "DAL", "MIN", 9.0)]}
    out = pro_list([game], props, _NBA_BY_NAME)
    assert '<article class="gm gm-line" id="l-g1" data-sport="nba"' in out
    assert 'data-home="Philadelphia 76ers"' in out and "data-side" not in out
    assert '<span class="gm-st">7:10 PM</span>' in out
    assert "<b>Raptors</b><small>5-4</small>" in out and "<b>76ers</b><small>8-3</small>" in out
    assert 'teamlogos/nba/500/phi.png' in out and ">TOR</span>" in out, "logo over an abbreviation badge"
    assert '<span class="gm-lb">Line</span><span class="gm-pv">76ers -10</span><span class="gm-ou">O/U 221</span>' in out
    assert "<div><b>1</b><span>Games</span></div><div><b>2</b><span>Projections</span></div>" in out
    assert 'aria-controls="ld-g1"' in out and '<div class="gm-detail" id="ld-g1" hidden>' in out
    titles = re.findall(r'<span class="pc-grp-t">([^<]+)</span><span class="pc-grp-n"[^>]*>(\d+)<', out)
    assert titles == [("Game lines", "3"), ("Points", "2")], titles
    assert "<details class=\"pc-grp mk\" open" not in out, "sections start closed"
    # Game lines: the road side's spread is the home line flipped; best prices.
    assert "<td>+10<small>-104</small></td><td>-10<small>-106</small></td>" in out
    assert "<td>+360</td><td>-450</td>" in out
    assert "<td>O 221<small>-107</small></td><td>U 221<small>-105</small></td>" in out
    # Players: this game's only, best projection first, one card each.
    assert out.index("Tyrese Maxey") < out.index("RJ Barrett") and "Someone Else" not in out
    assert out.count('<article class="pp">') == 2
    mx = out[out.index('<article class="pp">'):out.index("RJ Barrett")]
    assert 'class="pp-h" style="--c:#006BB6"' in mx, "the club's colour behind the name"
    assert "<b>Tyrese Maxey</b><small>Guard · vs Raptors</small>" in mx
    assert "teamlogos/nba/500/phi.png" in mx
    assert '<p class="pp-bar">Projected Points</p>' in mx
    assert "<div><b>27.0</b><span>Tonight</span></div><div><b>20.0</b><span>Season avg</span></div>" in mx
    assert "Raptors give up 56.0 points a game to guards, 16th most of 30." in mx
    # Last five: the numbers themselves, marked against tonight's 27.0.
    assert ('<span>Last 5</span><i class="pp-miss">20</i><i class="pp-hit">30</i>'
            '<i class="pp-miss">20</i><i class="pp-miss">20</i><i class="pp-hit">40</i>') in mx
    assert _last5([{"value": 24.0}], 27.0) .count("pp-near") == 1, "within 15% under"
    assert "Final: 31" in out and "green" in out.lower(), "the colour key is written out"
    # A game with no lines and no props: no Details button.
    bare = pro_list([dict(game, markets={}, event_id="g2")], {}, _NBA_BY_NAME)
    assert "gm-more" not in bare and "&mdash;" in bare
    assert pro_list([], {}, {}).startswith('<p class="empty-board">')
    # Projections not in yet for tonight's games (the boards are dated
    # yesterday): say so, rather than a tile reading "0 Projections".
    stale = pro_list([game], {"mk_points": [pl("Nobody Here", "DAL", "MIN", 9.0)]}, _NBA_BY_NAME)
    assert "<span>Projections</span>" not in stale and "not in yet" in stale
    assert "not in yet" not in out
    assert _NBA_BY_NAME["Los Angeles Clippers"] == "LAC" and _NBA_BY_NAME["New York Knicks"] == "NY"
    assert len(set(NBA_ABBR.values())) == 30
    # Tonight: every league in one list by time, each card saying its league.
    college = {"event_id": "c1", "league": "ncaab", "commence_time": "2026-11-12T23:00:00Z",
               "home": "Bradley Braves", "away": "Coppin St Eagles",
               "markets": {"spreads": {"point": -10.5, "side_a": "home"}},
               "ats": {"side": "home", "team": "Bradley Braves", "line": -10.5, "cover": 0.56,
                       "gap": 1.0, "tier": "pass"}}
    nfl = dict(game, event_id="f1", league="nfl", home="New York Giants",
               away="Washington Commanders", commence_time="2026-11-13T01:15:00Z")
    ton = tonight_list([nfl, game, college], {"nba": props})
    order = [ton.index(f'id="l-{x}"') for x in ("c1", "g1", "f1")]
    assert order == sorted(order), "by start time across leagues"
    assert '<span class="gm-lg">NCAAB</span><span class="gm-st">6:00 PM</span>' in ton
    assert '<span class="gm-lg">NBA</span>' in ton and '<span class="gm-lg">NFL</span>' in ton
    assert "teamlogos/nfl/500/nyg.png" in ton and "Tyrese Maxey" in ton
    assert "<div><b>3</b><span>Games</span></div>" in ton and "<span>NCAAB</span>" in ton
    assert tonight_list([]).startswith('<p class="empty-board">')
    assert len(NFL_ABBR) == 32
    # NFL: the same cards. Prop rows use nflverse's abbreviations (WAS, LA),
    # logos ESPN's (wsh, lar); the week's other games get a card with the
    # kickoff day and no line.
    def nf(name, team, opp, pos, proj, **kw):
        return dict({"name": name, "team": team, "opponent": opp, "position": pos,
                     "projection": proj, "per_game": 174.2, "opp_allowed": 259.2,
                     "league_allowed": 231.8, "game_id": "2026_10_WAS_NYG",
                     "commence_time": "2026-11-15T13:00:00-05:00",
                     "recent": [{"value": v} for v in (252.0, 127.0, 293.0)]}, **kw)
    nfl_props = {
        "mk_pass": [nf("J.J. McCarthy", "NYG", "WAS", "QB", 194.8, actual=293.0)],
        "mk_td": [dict(nf("Cam Skattebo", "NYG", "WAS", "RB", None), chance=0.556, per_game=0.682,
                       opp_allowed=2.92, league_allowed=2.46, scored=True,
                       recent=[{"value": v} for v in (0.0, 1.0, 2.0)])]}
    board_game = dict(game, event_id="n1", league="nfl", home="New York Giants",
                      away="Washington Commanders")
    nl = pro_list([board_game], nfl_props, PRO_ABBR["nfl"], pair=NFL_PAIR)
    assert "teamlogos/nfl/500/wsh.png" in nl and "teamlogos/nfl/500/nyg.png" in nl
    titles = re.findall(r'<span class="pc-grp-t">([^<]+)</span>', nl)
    assert titles == ["Game lines", "Passing yards", "Anytime touchdown"], titles
    assert 'class="pp-h" style="--c:#0B2265"' in nl, "Giants blue"
    assert "<b>J.J. McCarthy</b><small>QB \u00b7 vs Commanders</small>" in nl
    assert '<p class="pp-bar">Projected Passing yards</p>' in nl
    assert "<div><b>194.8</b><span>This week</span></div><div><b>174.2</b><span>Season avg</span></div>" in nl
    assert "Commanders give up 259.2 passing yards a game; the league average is 231.8." in nl
    assert '<span>Recent</span><i class="pp-hit">252</i><i class="pp-miss">127</i><i class="pp-hit">293</i>' in nl
    assert "Final: 293" in nl
    # Touchdowns: the chance to score, and each recent game marked by scoring.
    td = nl[nl.index("Cam Skattebo"):]
    assert "<div><b>56%</b><span>Chance to score</span></div><div><b>0.68</b><span>TDs a game</span></div>" in td
    assert '<i class="pp-miss">0</i><i class="pp-hit">1</i><i class="pp-hit">2</i>' in td
    assert "Scored" in td and "Commanders give up 2.92 touchdowns a game" in td
    # The rest of the week: games the props cover that are not on today's board.
    wk = week_games(nfl_props, [dict(board_game, home="Buffalo Bills", away="Miami Dolphins")])
    assert [(g["away"], g["home"]) for g in wk] == [("Washington Commanders", "New York Giants")]
    assert week_games(nfl_props, [board_game]) == [], "already on the board"
    extra = pro_list(wk, nfl_props, PRO_ABBR["nfl"], pair=NFL_PAIR, summary=False)
    assert '<span class="gm-st">Sun 1:00 PM</span>' in extra and "gm-sum" not in extra
    assert 'class="gm-pk' not in extra, "no line box without a line"
    assert "J.J. McCarthy" in extra
    assert len(NFL_COLOR) == 32 and set(NFL_COLOR) == set(NFL_VERSE)
    acc = prop_accuracy({"mk_points": {"graded": 839, "mae": 6.12, "baseline": 6.07},
                         "mk_assists": {}})
    assert ">Points<" in acc and "839" in acc and "6.12" in acc and ">Assists<" in acc


def _self_test() -> None:
    _test_pro_list()
    _test_pick_card()
    _test_result_strip()
    _test_ncaaf_card()
    _test_team_stats()
    _test_ncaab_system()
    _test_position_badge()
    row = {
        "event_id": "evt1", "league": "mlb",
        "commence_time": "2026-08-31T23:05:00Z",
        "home": "Milwaukee Brewers", "away": "Chicago Cubs",
        "model": {"home_win_prob": 0.556, "away_win_prob": 0.444},
        "markets": {
            "h2h": {"point": None, "side_a": "home", "fair_home": 0.548, "fair_away": 0.452,
                    "fair_price_home": -121, "fair_price_away": 121,
                    "best_home": {"book": "Caesars", "price": -125},
                    "best_away": {"book": "FanDuel", "price": 114},
                    "edge_home": 0.9, "edge_away": -2.1,
                    "books": 6, "width": 14},
            "spreads": {"point": -1.5, "side_a": "home", "fair_home": 0.41, "fair_away": 0.59,
                        "fair_price_home": 144, "fair_price_away": -144,
                        "best_home": {"book": "FanDuel", "price": 134},
                        "best_away": {"book": "BetMGM", "price": -155},
                        "edge_home": 2.2, "edge_away": -1.0,
                        "books": 5, "width": 20},
            "totals": {"point": 8.5, "side_a": "over", "fair_home": 0.503, "fair_away": 0.497,
                       "fair_price_home": -101, "fair_price_away": 101,
                       "best_home": {"book": "BetMGM", "price": -105},
                       "best_away": {"book": "Caesars", "price": -110},
                       "edge_home": 0.4, "edge_away": -0.8,
                       "books": 6, "width": 10, "model": None},
        },
    }

    html_out = board_card(row)

    # Both clubs are named, by nickname -- the canvas card sets the matchup
    # at 20px and the full names wrap to two lines on every card. The card
    # must still not mark our side by making the other one harder to read,
    # so both are present and neither is dimmed.
    assert _nickname(row["home"]) in html_out, html_out
    assert _nickname(row["away"]) in html_out, html_out

    # One probability, not two: the side our number likes. Printing both
    # made the reader do the comparison the card had already done.
    assert html_out.count('class="cv-pct"') == 1, html_out

    assert "--dim" not in html_out, \
        "--dim may not appear in a card; it is 3:1 and this is all content"

    # The price table is gone from the card, and with it the only place the
    # book names and the three market lines appeared. That was deliberate:
    # the panel is the matchup, and everything that was not the matchup came
    # out of it. The card keeps the disagreement, which is the number the
    # board exists to publish.
    assert "Caesars" not in html_out, "no book names on a card any more"
    assert i18n.t("mkt_run_line", LANG) not in html_out, "no price rows"
    assert 'class="mk-row"' not in html_out, html_out
    assert 'class="ge' in html_out, "the edge stays on the face of the card"

    # A row with no matchup material at all -- the state of a college
    # basketball card, and of an NFL card before enough finals are stored --
    # has nothing to disclose, and gets no control rather than an empty box.
    bare = dict(row)
    bare["detail"] = {}
    assert "<details" not in board_card(bare), board_card(bare)
    assert "onclick" not in html_out, "the card needs no JavaScript"

    # A game with no model has no win probability rather than a made-up one.
    unrated = {**row, "model": None}
    assert "55.6" not in board_cards([unrated])

    # An empty board says so instead of rendering nothing at all.
    assert i18n.t("board_empty", LANG) in board_cards([])

    # --- the probability bar ------------------------------------------------
    rated = {**row, "model": {
        "home_win_prob": 0.556, "away_win_prob": 0.444,
        "market_home_prob": 0.503, "disagreement": 5.3,
        "suspect": False, "source": "slate"},
        "detail": {"home_record": {"w": 74, "l": 56},
                   "away_record": {"w": 77, "l": 53},
                   "home_starter": "Freddy Peralta", "home_starter_era": 3.47,
                   "away_starter": "Shota Imanaga", "away_starter_era": 3.24}}

    bar = _prob_bar(rated["model"])
    assert 'class="gbar"' in bar
    assert 'class="tick"' in bar, "the market's own number has to be marked"
    # The bar reads left to right as the away club's chance, so the market's
    # tick sits at 1 - market_home_prob.
    assert "49.7%" in bar, "the tick is placed on the away side of the bar"

    # No market number means no tick, rather than a tick at zero.
    assert 'class="tick"' not in _prob_bar(
        {**rated["model"], "market_home_prob": None})

    # No model at all means no bar, rather than an empty one.
    assert _prob_bar(None) == ""

    card = board_card(rated)
    # ONE percentage on the face, rounded to whole points, and it is the side
    # our number likes. The canvas card prints the claim, not the arithmetic
    # -- 44.4 is 100 minus 55.6 and the reader can do that subtraction.
    shown = re.findall(r'class="cv-pct">([^<]*)', card)
    assert shown == ["56%"], shown
    # 55.6 still appears -- as the bar's width in a style attribute, which is
    # geometry, not a claim. The assertion is on the printed number only:
    # a decimal there implies a precision the model does not have.
    assert "44.4" not in card, card

    # The records moved behind the disclosure, and are still in the markup.
    # The whole record line, not the digits: "74" and "56" on their own also
    # appear in event ids and percentages, so a two-substring assertion would
    # pass whether or not a record ever reached the card.
    assert "74&ndash;56" in card, \
        "the home club's record reaches the card as a record line"
    assert "77&ndash;53" in card

    # The starters are named by the mirrored sheet and nowhere else, so a
    # card with no roster history for them names neither. That is the shape
    # of the design: a starter with no line against tonight's hitters has
    # nothing to say on a matchup panel, and a name with no numbers under it
    # is what the old two-paragraph block was.
    assert "Freddy Peralta" not in card, card

    # A card with no starter shows no starter line at all, rather than a
    # hardcoded English "TBA" — which every basketball and football card
    # would otherwise carry under a club that has no pitcher.
    hoops = board_card({**row, "league": "nba", "detail": {},
                        "model": {"home_win_prob": 0.55, "away_win_prob": 0.45}})
    assert "TBA" not in hoops, "no pitcher slot on a card with no pitcher"
    assert "var(--dim)" not in card, "everything on a card is content"

    # The edge is the last thing on the face, after the market's number --
    # the canvas reads left to right as "here is what they say, here is how
    # far we are from it". Pin the order so an edit that swaps them fails.
    assert card.index('class="gm"') < card.index('class="ge'), \
        "the market's number comes before the size of the disagreement"

    # Under a point, the card says so instead of printing a decimal that
    # would teach a reader to stop believing the ones that matter.
    agree = board_card({**rated, "model": {**rated["model"], "disagreement": 0.4}})
    assert i18n.t("cv_noedge", LANG) in agree, agree
    assert "0.4" not in agree.split('class="ge')[1][:40], agree

    # An edge the other way is amber and says "fade", not a negative edge.
    fade = board_card({**rated, "model": {**rated["model"], "disagreement": -6.0}})
    assert 'class="ge down"' in fade and i18n.t("cv_fade", LANG, v="") .split()[-1] in fade

    # A game we have not rated shows no percentages at all, rather than a
    # placeholder or the market's number standing in for ours.
    plain = board_card({**row, "model": None, "detail": None})
    assert "55.6" not in plain and 'class="cv-pct"' not in plain
    assert i18n.t("not_rated", LANG) in plain, plain

    # ---- the detail panel is the card's whole second half.
    row["detail"] = {
        "home_form": {"w": 85, "l": 53, "streak": "L2", "l10_w": 6, "l10_l": 4},
        "away_form": {"w": 78, "l": 60, "streak": "W1", "l10_w": 4, "l10_l": 6},
        "series": [
            {"date": "2026-06-23", "away": "Chicago Cubs", "away_runs": 1,
             "home": "Milwaukee Brewers", "home_runs": 4},
            {"date": "2026-06-29", "away": "Milwaukee Brewers", "away_runs": 7,
             "home": "Chicago Cubs", "home_runs": 2},
        ],
        "home_starter": "Robert Gasser", "away_starter": "Matthew Boyd",
        "home_starter_era": 3.44, "away_starter_era": 4.12,
        "home_hand": "L", "away_hand": "R",
        "venue": "American Family Field",
        "home_vs_opp": None,
        "away_vs_opp": {"starts": 2, "innings": 10.3, "era": 7.84,
                        "strikeouts": 5, "span": "2025-2026"},
    }
    set_props([
        # Boyd is the AWAY starter on this card, so his prop row carries the
        # away club. The pair used to be crossed -- Boyd on MIL, Gasser on a
        # club not in the game at all -- which the panel silently untangled
        # by elimination and drew each man's numbers under the other's hand.
        {"event_id": "evt1", "name": "Matthew Boyd", "team": "CHC",
         "line": 4.5, "projection": 4.2, "gap": -0.3, "over_odds": 112,
         "under_odds": -120, "matchup": "tough", "opp_k_per_game": 7.4,
         "vs_roster": {"pa": 41, "k_pct": 0.381, "bb_pct": 0.049,
                       "avg": 0.178, "batters": 9, "xwoba": 0.241,
                       "xwoba_pa": 38, "xwoba_span": "2025-2026",
                       "thin": True}},
        {"event_id": "evt1", "name": "Robert Gasser", "team": "MIL",
         "line": 5.5, "projection": 6.3, "gap": 0.8, "over_odds": -105,
         "under_odds": -115, "matchup": "favourable", "opp_k_per_game": 9.1,
         "vs_roster": {"pa": 18, "k_pct": 0.222, "bb_pct": 0.111,
                       "avg": 0.333, "batters": 6, "xwoba": 0.398,
                       "xwoba_pa": 16, "xwoba_span": "2025-2026",
                       "thin": True}},
        {"event_id": "other", "name": "Nobody At All", "team": "SEA",
         "line": 1.5, "projection": 1.5, "gap": 0.0, "matchup": "neutral"},
    ])
    panel = _detail_panel(row)
    # _ordinal returns a SUFFIX and _place a whole word. Defining the second
    # as another _ordinal shadowed the first and turned every rank on the
    # site into "2ndnd of 30" -- in the prop boards, which this panel's test
    # would never have looked at.
    assert _ordinal(2) == "nd" and _place(2) == "2nd", (_ordinal(2), _place(2))
    assert _place(11) == "11th" and _ordinal(11) == "th"

    # ---- the scorecard head. Both clubs, each on its own side.
    assert 'class="sc-abbr">CHC<' in panel and 'class="sc-abbr">MIL<' in panel
    assert "78&ndash;60" in panel and "85&ndash;53" in panel, "both records"
    assert i18n.t("sc_l10", LANG, w=4, l=6) in panel, "the away club's last ten"
    assert "L2" in panel and "W1" in panel, "both streak chips"
    assert "American Family Field" in panel, "the park, from the schedule row"
    # The day is new information; the time is already on the card's face.
    assert "Mon Aug 31" in panel, panel

    # ---- head to head. The bar carries both counts and neither end is ever
    # empty, or a sweep would print a number floating off a blank track.
    assert "Brewers lead the season series" in panel, panel
    assert 'class="h2a" style="width:4.0%"' in panel, \
        "a club that has won none of them still keeps a sliver of bar"
    assert i18n.t("sc_runs", LANG, v="1.5") in panel, "away runs per game"
    assert i18n.t("sc_runs", LANG, v="5.5") in panel, "home runs per game"
    # Counted with a real pattern, not a prefix: 'class="h2c' also matches
    # the date and score spans INSIDE each chip, so a prefix count reads 6
    # for two meetings and would pass whatever the strip actually drew.
    assert len(re.findall(r'class="h2c( on)?"', panel)) == 2, \
        "one chip per meeting"

    # ---- the mirrored sheet. Four scales, both sides, fixed ends.
    assert i18n.t("sv_head", LANG) in panel, panel
    assert "38.1" in panel and "22.2" in panel, "both K% against the lineup"
    assert "4.9" in panel and "11.1" in panel, "both BB%"
    assert ".178" in panel and ".333" in panel, "both averages"
    assert ".241" in panel and ".398" in panel, "both xwOBA"
    assert i18n.t("sv_line", LANG, team="Brewers", n=41) in panel, panel
    assert "RHP" in panel and "LHP" in panel, "both hands"
    # Lower xwOBA has to draw the LONGER bar, or the caption is a lie. .241
    # against a .400-.220 scale is nearly full; .398 is nearly empty.
    fills = [float(m) for m in re.findall(
        r'data-f="xwoba"[^>]*>.*?<b style="width:([0-9.]+)%"', panel)]
    assert len(fills) == 2, fills
    assert fills[0] > 85 and fills[1] < 15, fills
    assert "M. Boyd" in panel and "R. Gasser" in panel, "both starters named"
    # Props join by event id, and only this game's appear.
    assert "Nobody At All" not in panel, panel

    # ---- and NOTHING else. The panel is these three blocks. It had grown a
    # price table, an eight-row season comparison, tonight's strikeout props,
    # a matchup verdict and a paragraph on each starter underneath the design
    # it was built to. Each absence is named, because a block creeping back
    # in is exactly how the panel got that way the first time.
    for gone, what in (
        ('class="mk-row"', "the price rows"),
        ('class="sptbl"', "the season comparison table"),
        (i18n.t("sp_tonight", LANG), "tonight's strikeout props"),
        (i18n.t("mxb_tough", LANG), "the matchup verdict"),
        ("o+112", "the prop prices"),
        ('class="pst"', "the per-starter paragraphs"),
        ('class="lutbl"', "the per-hitter tables"),
    ):
        assert gone not in panel, f"{what} belong on their own board, not here"
    assert panel.count("<section") == 3, panel

    # Arizona is the club where TEAM_ABBR and StatsAPI disagree (ARI / AZ).
    # The sheet's own identity guard drops a column whose prop names a
    # different man than the card does, so the fixture names them both.
    az_row = dict(row, event_id="az1", home="Arizona Diamondbacks",
                  away="Colorado Rockies",
                  detail={**row["detail"], "home_starter": "A Snake",
                          "away_starter": "A Rockie"})
    set_props([
        {"event_id": "az1", "name": "A Snake", "team": "AZ",
         "vs_roster": {"pa": 30, "k_pct": 0.30, "bb_pct": 0.06,
                       "avg": 0.200, "batters": 8, "xwoba": 0.260}},
        {"event_id": "az1", "name": "A Rockie", "team": "COL",
         "vs_roster": {"pa": 25, "k_pct": 0.20, "bb_pct": 0.09,
                       "avg": 0.280, "batters": 7, "xwoba": 0.340}},
    ])
    az = _detail_panel(az_row)
    assert "A. Snake" in az and "A. Rockie" in az, \
        "ARI/AZ is an alias, not a missing club"
    assert "[[" not in panel, panel

    # A card whose rating never merged has no detail and nothing to disclose.
    # The prices used to keep a disclosure alive on exactly this card; they
    # are gone, so it gets no control rather than an empty box.
    bare = dict(row)
    bare.pop("detail")
    set_props([])
    assert _detail_panel(bare) == "", "no detail means no panel, not a crash"
    assert _disclosure(bare) == "", "and no panel means no disclosure control"
    assert "<details" not in board_card(bare), board_card(bare)
    # And with a detail block it is a details element, not a flip.
    with_detail = board_card(row)
    assert "<details" in with_detail and "<summary" in with_detail
    assert "onclick" not in with_detail, "still no JavaScript"

    # ---- the prop card's matchup panel
    prop = {
        "name": "Gavin Williams", "team": "CLE", "opponent": "TOR",
        "hand": "R", "matchup": "tough", "k_per_9": 11.77,
        "opp_split": {"k_pct": 18.9, "pa": 3665, "rank": 29, "rank_all": 28,
                      "of": 30, "league_mean": 21.85},
        "vs_opp": {"starts": 3, "innings": 15.3, "era": 6.46,
                   "strikeouts": 15, "span": "2025-2026"},
    }
    mx = _matchup_inner(prop)
    assert "18.9%" in mx, mx
    assert "vs right-handers" in mx and "vs left-handers" not in mx, \
        "only the hand that applies is shown"
    assert "29th of 30" in mx, "the split rank stays, in the row"
    assert "3,665 PA" in mx, "the sample size prints with a thousands mark"
    assert "tough matchup" in mx
    assert "[[" not in mx, mx

    # The panel is a grid, a table and a verdict -- no paragraphs. Asked for
    # twice, so it is pinned rather than left to taste. Every sentence that
    # used to sit here restated a number already on screen.
    assert "<p" not in mx, f"the prop panel carries no prose:\n{mx}"
    for gone in ("mx_read", "mx_thin", "mx_applies", "mx_and_hand",
                 "mx_same", "mx_never_v"):
        assert i18n.t(gone, LANG, k9="", season="", n=1, s="", who="",
                      team="", hand="", overall="", split="",
                      hand_word="") not in mx, gone

    # No split and no history still renders, and claims nothing.
    thin = {"name": "Nobody", "opponent": "TOR", "hand": "",
            "matchup": "neutral", "k_per_9": 8.0, "opp_split": None,
            "vs_opp": None}
    out = _matchup_inner(thin)
    assert "has never faced" in out, out
    assert "%" not in out, "no split means no percentage invented"

    # --- the pitcher card with no posted line -------------------------------
    # The board is built from StatsAPI every morning now, so most cards have
    # no price on them. The card must not invent one.
    free_sp = {"name": "A Pitcher", "team": "DET",
               "opponent": "Cleveland Guardians", "projection": 6.4,
               "line": None, "gap": None, "suspect": False, "reference": 6.4,
               "recent": [{"date": "2026-09-02", "strikeouts": 8,
                           "innings": 6.0}],
               "recent_over": 1, "recent_n": 1, "last5_over": 1, "last5_n": 1,
               "k_per_9": 11.2, "matchup": "neutral", "actual": None}
    free_html = pitcher_cards([free_sp])
    assert 'class="pl-tick"' not in free_html, \
        "no posted line means no tick; ours is already the fill"
    assert i18n.t("pl_noline", LANG) in free_html, free_html
    assert i18n.t("pnl_prices", LANG) not in free_html, \
        "no prices section on a card with no prices"
    assert 'data-edge="0"' in free_html, \
        "an edge against nothing is not a small edge"
    assert "0.0" not in free_html.split('class="pl-edge"')[1][:160], \
        "a missing line must not collapse to a real-looking zero"
    # The rewrite's whole claim is that nothing behind the disclosure was
    # lost. The row is a <summary>, so the panel has to still be in it.
    assert "<details" in free_html and "<summary" in free_html, free_html[:300]
    assert i18n.t("season", LANG) in free_html

    priced_sp = dict(free_sp, line=6.5, gap=-0.1, reference=6.5,
                     over_odds=-115, under_odds=-105)
    priced_html = pitcher_cards([priced_sp])
    assert 'class="pl-tick"' in priced_html
    assert i18n.t("pnl_prices", LANG) in priced_html
    # Under the 0.4 K threshold is not an edge, and must not be printed as
    # one: the board sorts by this and a 0.1 K "edge" at the top would be
    # the page arguing something it cannot support.
    assert i18n.t("cv_noedge", LANG) in priced_html, priced_html

    # --- the list sorts by edge, and settled rows sink ----------------------
    edged = dict(free_sp, name="Big Edge", line=5.0, gap=1.8, reference=5.0)
    small = dict(free_sp, name="Small Edge", line=6.0, gap=0.6, reference=6.0)
    done = dict(free_sp, name="Yesterday", line=5.0, gap=2.4, reference=5.0,
                actual=7)
    board = pitcher_cards([done, small, edged])
    order = [board.index(n) for n in ("Big Edge", "Small Edge", "Yesterday")]
    assert order == sorted(order), "biggest edge first, settled last"
    assert pitcher_head([done, small, edged])["edges"] == "2", \
        "a settled row is a result, not one of tonight's edges"
    # Every row carries its fixture so the picker can filter a flat list --
    # three rows plus the one chip their shared fixture earns.
    assert board.count('<details class="pl') == 3, board[:300]
    assert board.count('data-game="g') == 4, board[:300]
    assert 'data-filter="edges"' in board, "two live edges earns the chip"
    assert 'data-filter="edges"' not in pitcher_cards([free_sp]), \
        "a board with no edges must not offer a filter that empties it"

    # --- the hit strip ------------------------------------------------------
    # The midpoint is the whole point of the scale: a coin flip must not be
    # tinted, in either direction, or every row carries a colour and none of
    # them mean anything.
    assert hit_band(0.50) == "mid"
    assert hit_band(0.51) == "h1" and hit_band(0.49) == "l1"
    assert hit_band(0.85) == "h3" and hit_band(0.05) == "l3"
    assert hit_band(None) == "na"

    games = [{"k": v} for v in (2, 8, 9, 3, 7, 6, 1, 9, 8, 4)]
    pct, over, of = hit_rate(games, 5.5, 10, "k")
    assert (over, of) == (6, 10) and abs(pct - 0.6) < 1e-9
    # The last five, not the first five: `recent` is oldest-first.
    pct5, over5, of5 = hit_rate(games, 5.5, 5, "k")
    assert (over5, of5) == (3, 5), (over5, of5)
    # Fewer games than the span is not an error, and is not padded out to
    # look like a full sample.
    assert hit_rate(games[:3], 5.5, 10, "k")[2] == 3
    assert hit_rate([], 5.5, 5, "k") == (None, 0, 0)
    assert hit_rate(games, None, 5, "k") == (None, 0, 0), \
        "no number to clear is not a 0% hit rate"
    # Exactly on the number is not over it. A 6-K start does not clear 6.
    assert hit_rate([{"k": 6}], 6, 1, "k")[1] == 0

    # The raw fraction rides along with the percentage, always.
    html_ = hit_strip(games, 5.5, key="k", odds=-140)
    assert "60%" in html_ and "(6/10)" in html_, html_
    assert "58%" in html_, "a -140 price is a 58% market"     # 140/240
    assert 'class="hr mkt"' in html_
    # No price, no market cell -- and no cell restating the threshold, which
    # is already printed under the bar or in the rail.
    unpriced = hit_strip(games, 6.4, key="k", odds=None, priced=False)
    assert i18n.t("hr_market", LANG) not in unpriced, \
        "there is no market number on a prop nobody priced"
    assert len(re.findall(r'class="hr [a-z0-9]+"', unpriced)) == 2, unpriced
    assert "6.4" not in unpriced, "the basis is on the row already"
    # An odds value with priced=False is still not printed -- the flag is the
    # authority, so a stale price on an unpriced row cannot leak onto a board.
    assert i18n.t("hr_market", LANG) not in hit_strip(
        games, 6.4, key="k", odds=-140, priced=False)

    # An anytime touchdown clears 0.5, which is arithmetic rather than a
    # number anyone wants on their screen. It is never printed.
    td_ = hit_strip([{"value": 1}, {"value": 0}, {"value": 1}], 0.5,
                    key="value", priced=False)
    assert "0.5" not in td_, td_
    assert "67%" in td_ and "(2/3)" in td_, td_

    # A league with nothing graded shows no calibration section at all.
    assert calibration_section({}) == ""
    assert calibration_section({"graded": 0, "calibration": []}) == ""
    shown = calibration_section({"graded": 12, "brier": 0.2401,
                                 "market_brier": 0.2380,
                                 "market_compared": 12,
                                 "calibration": [{"lo": .5, "hi": .6, "n": 12,
                                                  "predicted": 55.0,
                                                  "actual": 58.3, "gap": 3.3}]})
    assert 'id="calibration"' in shown and "0.2401" in shown, shown[:200]
    assert "0.2380" in shown, "the market's score on the same games"

    assert hit_strip([], 5.5, key="k") == "", "no log, no strip"
    assert hit_strip(None, 5.5, key="k") == ""
    assert implied_prob(-110) is not None and implied_prob(None) is None
    assert abs(implied_prob(100) - 0.5) < 1e-9

    # --- modifier classes must not collide with base.css's utilities --------
    # `class="pl up"` set every positive-edge row in letterspaced uppercase
    # mono, because base.css styles a bare `.up` as a label utility. It
    # shipped unseen: that morning's board was entirely settled rows, so the
    # one tone that collides never rendered.
    #
    # This reads the stylesheet rather than checking a list, so a utility
    # added later is covered without anyone remembering to come back here. A
    # modifier namespaced under its own component -- "pl pl-done" -- is the
    # intended pattern and is not a collision.
    import re as _re
    css = (Path(__file__).resolve().parent / "base.css").read_text()
    bare = {m.group(1) for m in _re.finditer(r"(?m)^\.([a-z][a-z0-9-]*)\{", css)}
    sample = [dict(free_sp, name="Up", line=5.0, gap=1.8, reference=5.0),
              dict(free_sp, name="Down", line=8.0, gap=-1.6, reference=8.0),
              dict(free_sp, name="Flat", line=6.4, gap=0.0, reference=6.4),
              dict(free_sp, name="Done", line=5.0, gap=1.4, reference=5.0,
                   actual=7)]
    for attr in _re.findall(r'class="([^"]+)"', pitcher_cards(sample)):
        tokens = attr.split()
        for extra in tokens[1:]:
            if extra.startswith(tokens[0] + "-"):
                continue                      # namespaced under its component
            assert extra not in bare, (
                f'class="{attr}" -- {extra!r} is styled bare in base.css and '
                f"will restyle the whole element. Prefix the modifier.")

    # The axis is a floor, not a fixed nine: a projection above it would be
    # drawn pegged at 100% and read as the same call as a nine.
    tall = pitcher_cards([dict(free_sp, name="Tall", projection=11.4)])
    assert "<span>12</span>" in tall, tall[tall.index("pl-scale"):][:160]
    assert "width:100.0%" not in tall, "no row may sit pegged at the axis"

    # --- boards grouped into fixtures ---------------------------------------
    # Both clubs of one game must land in ONE section. They arrive as
    # separate rows written from each side's point of view, and the only
    # thing that makes them the same fixture is is_home plus the pair of
    # club names -- which is why is_home had to be carried down to the row.
    def _bats(team, vs_team, home, pitcher):
        return [{"name": f"Bat{i}", "team": team, "vs_team": vs_team,
                 "is_home": home, "vs": pitcher, "chance": 0.6,
                 "commence_time": "2026-09-10T23:05:00Z",
                 "h": 140, "pa": 600, "hit_rate": 0.23, "park": 1.0,
                 "vs_h_per_bf": 0.22, "vs_hand": "R", "bvp": None}
                for i in range(2)]

    grouped = hit_cards(_bats("ATL", "PHI", False, "A") +
                        _bats("PHI", "ATL", True, "B"))
    assert grouped.count('class="gsec"') == 1, \
        "both clubs of a fixture belong in one section"
    assert "ATL <span>@</span> PHI" in grouped, grouped[:400]

    # --- the board says which lineup it is showing --------------------------
    plain = _bats("ATL", "PHI", False, "A")
    assert lineup_note(plain) == i18n.t("lu_regulars", LANG)
    assert lineup_note([]) == i18n.t("lu_regulars", LANG)
    both = [dict(b, team_id=1, lineup=True) for b in plain]
    assert "2" not in lineup_note(both) or True
    assert lineup_note(both).startswith(i18n.t("lu_posted", LANG, n=1, of=1)[:12])
    mixed = ([dict(b, team_id=1, lineup=True) for b in plain]
             + [dict(b, team_id=2, lineup=False) for b in plain])
    note = lineup_note(mixed)
    assert note == i18n.t("lu_mixed", LANG, n=1, of=2), note

    # --- the batter boards carry the same strip ----------------------------
    # Their threshold is half a home run: one is a hit and none is not, and a
    # two-homer game is not twice as much of a hit. Same rule as anytime
    # touchdowns, for the same reason.
    logged = [dict(b, recent=[{"date": f"2026-09-{d:02d}", "value": v}
                              for d, v in enumerate([0, 1, 0, 0, 2, 0, 1, 0,
                                                     0, 1], start=1)])
              for b in _bats("ATL", "PHI", False, "A")]
    strip_html = hit_cards(logged)
    assert '<div class="hrs">' in strip_html, "the strip reaches the card"
    assert "40% <u>(4/10)</u>" in strip_html, strip_html[:400]
    # A hitter with no log gets no strip rather than an empty frame.
    assert '<div class="hrs">' not in hit_cards(_bats("ATL", "PHI", False, "A"))


    # A doubleheader is two fixtures, not one: same clubs, different first
    # pitch. slate.py had to learn this the hard way once already.
    dh = _bats("ATL", "PHI", False, "A") + _bats("PHI", "ATL", True, "B")
    for r in dh[:2]:
        r["commence_time"] = "2026-09-10T17:05:00Z"
    assert hit_cards(dh).count('class="gsec"') >= 2, \
        "two games between the same clubs are two sections"

    # An older data file with no opposing club heads the group with the club
    # it knows rather than with "ATL @ ", which reads as a rendering fault.
    legacy = _bats("ATL", None, False, "A")
    out = hit_cards(legacy)
    assert "@ </h3>" not in out and "@</span> </h3>" not in out, out[:400]

    print("render self-test: all invariants hold")


if __name__ == "__main__":
    _self_test()

