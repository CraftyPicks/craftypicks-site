#!/usr/bin/env python3
"""The college basketball System: rules that passed a six-season test.

Chosen on 2020-21 through 2024-25 and checked on 2025-26, which chose
nothing (research/search_ncaab_angles.py, search_ncaab_totals.py, on
CollegeBasketballData history; every stat as of the game, closing lines):

  BIGDOG  The underdog getting 10 or more, when it allows fewer points per
          game than the favourite, or has more steals AND forces more
          turnovers. 1656-1351 (55.1%), break-even or better in all six
          seasons, 57% in the held-out one. All season.
  UNDER   The under in a non-conference game when both teams defend shots
          poorly: both allow an above-median effective FG% and 3PT%.
          449-330 (57.6%), 55%+ in every season. Non-conference games are
          nearly all November-December; where the flag is unknown, those
          months stand in (56.6% over the same seasons).
  ROADFAV The away favourite giving under 10 points in a conference game
          when the teams are within 25 spots in the power rank: 341-275
          (55.4%), break-even or better in every season (2023: 51%),
          55% in the held-out one. Close teams where the road team is still
          favoured: the home dogs within 25 spots lost 46.7% ATS. Where the
          conference flag is unknown, January-April stand in (55.9%). Added
          Nov 2026, after a wider search (140 versions tried; only the
          25-spot ones qualified, so it is the shakiest of the three).
  FAVTT   In an UNDER game with a spread under 10 and a total of 140 to
          169.5, the favourite's team total under, at its implied number
          (total/2 + spread/2): 223-118 (65.4%), 60%+ in five of six
          seasons. It rides with UNDER -- the two tend to win and lose
          together -- so it is not a separate edge. Graded at the implied
          number; books may post a point either side. Added Nov 2026, after
          looking at 12 splits of the under games.

They replace the Nov 2026 rules (small dog, defense dog, road dog, favourite
vs 300+), which looked like 61-69% on two weeks but went 50.3% over six
seasons once graded without hindsight. The bar for -110 is 52.4%.

Every number a play uses comes from games that started BEFORE it, so a
page rebuilt after the game cannot leak the result into its own pick.
Stdlib only.
"""
from __future__ import annotations

import statistics
from datetime import datetime, timedelta, timezone

BIG_DOG = 10.0       # BIGDOG: the underdog gets at least this many
MIN_BOX = 3          # box scores a team needs before its stats are used
UNDER_MONTHS = (11, 12)   # UNDER's window when the conference flag is unknown
ROADFAV_MAX = 10.0        # ROADFAV: the favourite gives less than this
ROADFAV_GAP = 25          # ... with the teams fewer than this many ranks apart
CONF_MONTHS = (1, 2, 3, 4)   # ROADFAV's window when the conference flag is unknown
ROADFAV_FROM = "2026-11-25"  # ROADFAV's first live day (ET): no plays on earlier games
FAVTT_MAX_SPREAD = 10.0      # FAVTT: the spread is under this
FAVTT_TOTALS = (140.0, 170.0)   # ... and the total in [140, 170)
FAVTT_FROM = "2026-11-26"    # FAVTT's first live day (ET)

BACKTEST = {"spread": [1997, 1626, 0], "total": [449, 330, 0],
            "through": "2026-04-06", "seasons": "2020-21 to 2025-26",
            "by_reason": {"bigdog": [1656, 1351], "roadfav": [341, 275], "under": [449, 330],
                          "favtt": [223, 118]}}


def _ts(stamp) -> float | None:
    try:
        return datetime.fromisoformat(str(stamp).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def team_forms(store: dict, before) -> dict:
    """{team id: form} from finals that started before `before` (a timestamp):
    n and pa (points allowed) from every final; stl and tovf (turnovers
    forced) from box scores (`box`); oefg and otpp (opponents' effective
    FG% and 3PT%) from box scores carrying three-pointers (`shot`)."""
    acc: dict[str, dict] = {}
    for g in (store or {}).get("games", {}).values():
        t = _ts(g.get("commence_time"))
        if (not g.get("completed") or g.get("home_score") is None or t is None
                or before is None or t >= before):
            continue
        box = g.get("box") or {}
        for me, ot in (("home", "away"), ("away", "home")):
            tid, oid = str(g[me]["id"]), str(g[ot]["id"])
            a = acc.setdefault(tid, {"n": 0, "pa": 0.0, "box": 0, "stl": 0.0, "tovf": 0.0,
                                     "shot": 0, "ofgm": 0, "ofga": 0, "otpm": 0, "otpa": 0})
            a["n"] += 1
            a["pa"] += g[f"{ot}_score"]
            mb, ob = box.get(tid) or {}, box.get(oid) or {}
            if mb.get("stl") is not None and ob.get("tov") is not None:
                a["box"] += 1
                a["stl"] += mb["stl"]
                a["tovf"] += ob["tov"]
            if all(ob.get(k) is not None for k in ("fgm", "fga", "tpm", "tpa")) and ob["fga"]:
                a["shot"] += 1
                for k in ("fgm", "fga", "tpm", "tpa"):
                    a[f"o{k}"] += ob[k]
    out = {}
    for tid, a in acc.items():
        out[tid] = {
            "n": a["n"], "pa": a["pa"] / a["n"], "box": a["box"],
            "stl": a["stl"] / a["box"] if a["box"] else None,
            "tovf": a["tovf"] / a["box"] if a["box"] else None,
            "shot": a["shot"],
            "oefg": (a["ofgm"] + 0.5 * a["otpm"]) / a["ofga"] if a["ofga"] else None,
            "otpp": a["otpm"] / a["otpa"] if a["otpa"] else None}
    return out


def medians(forms: dict) -> dict:
    """The median team's oefg and otpp, over teams with MIN_BOX shot boxes."""
    pool = [f for f in forms.values() if f["shot"] >= MIN_BOX]
    return {k: statistics.median(f[k] for f in pool) if pool else None for k in ("oefg", "otpp")}


def _bigdog(dog: dict | None, fav: dict | None) -> bool:
    if not dog or not fav or min(dog["box"], fav["box"]) < MIN_BOX:
        return False
    if dog["pa"] < fav["pa"]:
        return True
    return dog["stl"] > fav["stl"] and dog["tovf"] > fav["tovf"]


def _poor_shot_defense(f: dict | None, med: dict) -> bool:
    return (bool(f) and f["shot"] >= MIN_BOX and med.get("oefg") is not None
            and f["oefg"] > med["oefg"] and f["otpp"] > med["otpp"])


def plays(spread_home, neutral: bool, home_form: dict | None, away_form: dict | None,
          ranks=(None, None), total=None, conf=None, month=None, med=None,
          roadfav: bool = True, favtt: bool = True) -> dict:
    """The System's plays for one game: {"side": "home"/"away" or None,
    "reasons": ["bigdog"], ["roadfav"] or [], "under": bool}. `conf` is
    whether it is a conference game (None when unknown); `month` the game's
    month; `roadfav` / `favtt` False turn those rules off (games before they
    went live). "fav_tt" is {"side", "line"} for FAVTT, else None."""
    out = {"side": None, "reasons": [], "under": False, "fav_tt": None}
    if spread_home not in (None, 0) and abs(spread_home) >= BIG_DOG:
        dog, fav = ("home", "away") if spread_home > 0 else ("away", "home")
        forms = {"home": home_form, "away": away_form}
        if _bigdog(forms[dog], forms[fav]):
            out["side"], out["reasons"] = dog, ["bigdog"]
    rh, ra = ranks or (None, None)
    in_conf = (conf is True) if conf is not None else (month in CONF_MONTHS)
    if (roadfav and not out["side"] and not neutral and spread_home is not None
            and 0 < spread_home < ROADFAV_MAX and rh is not None and ra is not None
            and abs(rh - ra) < ROADFAV_GAP and in_conf):
        out["side"], out["reasons"] = "away", ["roadfav"]
    window = (conf is False) if conf is not None else (month in UNDER_MONTHS)
    if (total is not None and window and med
            and _poor_shot_defense(home_form, med) and _poor_shot_defense(away_form, med)):
        out["under"] = True
        if (favtt and spread_home not in (None, 0) and abs(spread_home) < FAVTT_MAX_SPREAD
                and FAVTT_TOTALS[0] <= total < FAVTT_TOTALS[1]):
            out["fav_tt"] = {"side": "home" if spread_home < 0 else "away",
                             "line": round((total + abs(spread_home)) / 2 * 2) / 2}
    return out


def for_game(store: dict, home_id, away_id, commence, spread_home, neutral: bool,
             ranks=(None, None), total=None, conf=None) -> dict:
    """plays() for a game, with each team's form as of its start."""
    t = _ts(commence)
    forms = team_forms(store, t)
    et = datetime.fromtimestamp(t, timezone.utc) - timedelta(hours=5) if t is not None else None
    return plays(spread_home, neutral, forms.get(str(home_id)), forms.get(str(away_id)),
                 ranks, total, conf, et.month if et else None, medians(forms),
                 roadfav=bool(et) and et.date().isoformat() >= ROADFAV_FROM,
                 favtt=bool(et) and et.date().isoformat() >= FAVTT_FROM)


def grade(play: dict, spread_home, home_score, away_score, total=None) -> dict:
    """{"spread": "W"/"L"/"P" or None, "total": ..., "fav_tt": ...} for a
    finished game."""
    out = {"spread": None, "total": None, "fav_tt": None}
    if play.get("side") and spread_home is not None:
        e = home_score - away_score + spread_home
        if play["side"] == "away":
            e = -e
        out["spread"] = "W" if e > 0 else "L" if e < 0 else "P"
    if play.get("under") and total is not None:
        d = home_score + away_score - total
        out["total"] = "W" if d < 0 else "L" if d > 0 else "P"
    ft = play.get("fav_tt")
    if ft:
        d = (home_score if ft["side"] == "home" else away_score) - ft["line"]
        out["fav_tt"] = "W" if d < 0 else "L" if d > 0 else "P"
    return out


def _self_test() -> None:
    def g(eid, day, h, a, hs, as_, hbox, abox):
        return {"event_id": eid, "commence_time": f"2026-11-{day:02d}T23:00Z", "completed": True,
                "home": {"id": h}, "away": {"id": a}, "home_score": hs, "away_score": as_,
                "box": {h: hbox, a: abox}}

    def bx(stl, tov, fgm, fga, tpm, tpa):
        return {"stl": stl, "tov": tov, "fgm": fgm, "fga": fga, "tpm": tpm, "tpa": tpa}
    store = {"games": {}}
    # D: allows 60, 9 steals, forces 15; opponents shoot 20-60 (5-20 from 3).
    # B: allows 85, 5 steals, forces 10; opponents shoot 32-60 (10-25 from 3).
    # P: allows 80; opponents shoot 30-60 (9-24). Two more average teams set the median.
    for i in range(3):
        d = 2 + i
        store["games"][f"d{i}"] = g(f"d{i}", d, "D", f"x{i}", 75, 60, bx(9, 10, 28, 60, 7, 20), bx(4, 15, 20, 60, 5, 20))
        store["games"][f"b{i}"] = g(f"b{i}", d, "B", f"y{i}", 90, 85, bx(5, 10, 33, 60, 9, 22), bx(6, 10, 32, 60, 10, 25))
        store["games"][f"p{i}"] = g(f"p{i}", d, "P", f"z{i}", 82, 80, bx(6, 11, 31, 60, 8, 21), bx(6, 11, 30, 60, 9, 24))
        store["games"][f"m{i}"] = g(f"m{i}", d, "M", f"w{i}", 70, 70, bx(6, 11, 25, 60, 6, 20), bx(6, 11, 25, 60, 6, 20))
        store["games"][f"n{i}"] = g(f"n{i}", d, "N", f"v{i}", 70, 70, bx(6, 11, 26, 60, 6, 21), bx(6, 11, 26, 60, 6, 21))
    f = team_forms(store, _ts("2026-11-10T00:00Z"))
    assert f["D"]["n"] == 3 and f["D"]["pa"] == 60 and f["D"]["stl"] == 9 and f["D"]["tovf"] == 15
    assert abs(f["D"]["oefg"] - (20 + 2.5) / 60) < 1e-9 and f["D"]["otpp"] == 0.25
    med = medians(f)
    # BIGDOG: D getting 12 at B -- fewer points allowed.
    p = plays(-12.0, False, f["B"], f["D"], med=med, month=11)
    assert p["side"] == "away" and p["reasons"] == ["bigdog"], p
    assert plays(-9.5, False, f["B"], f["D"], med=med)["side"] is None, "under 10 points"
    assert plays(12.0, False, f["B"], f["D"], med=med)["side"] is None, "the dog B is worse"
    # Steals AND turnovers forced also qualify, either alone does not.
    dog = dict(f["B"], pa=99.0, stl=10.0, tovf=16.0)   # beats D's 9 and 15
    assert plays(12.0, False, dog, f["D"], med=med)["side"] == "home"
    assert plays(12.0, False, dict(dog, tovf=1.0), f["D"], med=med)["side"] is None
    thin = dict(f["D"], box=2)
    assert plays(-12.0, False, f["B"], thin, med=med)["side"] is None, "too few box scores"
    # UNDER: B and P both defend shots poorly; non-conference, total posted.
    assert plays(-3.0, False, f["B"], f["P"], total=150.0, conf=False, med=med)["under"]
    assert not plays(-3.0, False, f["B"], f["P"], total=150.0, conf=True, med=med)["under"], "conference game"
    assert not plays(-3.0, False, f["B"], f["D"], total=150.0, conf=False, med=med)["under"], "D defends well"
    assert not plays(-3.0, False, f["B"], f["P"], total=None, conf=False, med=med)["under"], "no total"
    assert plays(-3.0, False, f["B"], f["P"], total=150.0, month=12, med=med)["under"], "flag unknown: December"
    assert not plays(-3.0, False, f["B"], f["P"], total=150.0, month=1, med=med)["under"], "flag unknown: January"
    # ROADFAV: the away favourite giving under 10 to a home team within 25
    # ranks, in a conference game (January-April when the flag is unknown).
    rf = plays(4.5, False, f["M"], f["N"], ranks=(120, 100), conf=True, med=med)
    assert rf["side"] == "away" and rf["reasons"] == ["roadfav"], rf
    assert plays(4.5, False, f["M"], f["N"], ranks=(120, 95), conf=True, med=med)["side"] is None, "25 apart"
    assert plays(4.5, False, f["M"], f["N"], ranks=(120, 100), conf=False, med=med)["side"] is None, "non-conference"
    assert plays(4.5, True, f["M"], f["N"], ranks=(120, 100), conf=True, med=med)["side"] is None, "neutral site"
    assert plays(-4.5, False, f["M"], f["N"], ranks=(120, 100), conf=True, med=med)["side"] is None, "home favourite"
    assert plays(10.0, False, f["M"], f["N"], ranks=(120, 100), conf=True, med=med)["side"] is None, "10 is too many"
    assert plays(9.5, False, f["M"], f["N"], ranks=(120, 100), conf=True, med=med)["side"] == "away"
    assert plays(4.5, False, f["M"], f["N"], conf=True, med=med)["side"] is None, "no ranks"
    assert plays(4.5, False, f["M"], f["N"], ranks=(100, 120), conf=True, med=med)["side"] == "away", \
        "either team may be ranked higher"
    assert plays(4.5, False, f["M"], f["N"], ranks=(120, 100), month=2, med=med)["side"] == "away", "flag unknown: Feb"
    assert plays(4.5, False, f["M"], f["N"], ranks=(120, 100), month=12, med=med)["side"] is None, "flag unknown: Dec"
    assert plays(4.5, False, f["M"], f["N"], ranks=(120, 100), conf=True, med=med, roadfav=False)["side"] is None
    # BIGDOG still takes a 10+ point game, so the two never meet.
    assert plays(-12.0, False, f["B"], f["D"], ranks=(100, 110), conf=True, med=med)["reasons"] == ["bigdog"]
    # ROADFAV starts on its go-live day: no plays on earlier games.
    store["games"]["mn"] = {"event_id": "mn", "commence_time": "2026-11-23T23:00Z", "completed": False,
                            "home": {"id": "M"}, "away": {"id": "N"}}
    assert for_game(store, "M", "N", "2026-11-23T23:00Z", 4.5, False, (120, 100), conf=True)["side"] is None
    assert for_game(store, "M", "N", "2026-11-26T00:30Z", 4.5, False, (120, 100), conf=True)["side"] == "away"
    # FAVTT: in an UNDER game with a spread under 10 and a total of 140 to
    # 169.5, the favourite's team total under, at its implied number.
    ft = plays(-3.5, False, f["B"], f["P"], total=143.5, conf=False, med=med)
    assert ft["under"] and ft["fav_tt"] == {"side": "home", "line": 73.5}, ft
    assert plays(4.0, False, f["B"], f["P"], total=150.0, conf=False, med=med)["fav_tt"] == {"side": "away", "line": 77.0}
    assert plays(-10.0, False, f["B"], f["P"], total=150.0, conf=False, med=med)["fav_tt"] is None, "spread 10"
    assert plays(-3.5, False, f["B"], f["P"], total=170.0, conf=False, med=med)["fav_tt"] is None, "total 170"
    assert plays(-3.5, False, f["B"], f["P"], total=139.5, conf=False, med=med)["fav_tt"] is None, "total under 140"
    assert plays(-3.5, False, f["B"], f["D"], total=150.0, conf=False, med=med)["fav_tt"] is None, "no under, no FAVTT"
    assert plays(0, False, f["B"], f["P"], total=150.0, conf=False, med=med)["fav_tt"] is None, "pick'em: no favourite"
    assert plays(-3.5, False, f["B"], f["P"], total=150.0, conf=False, med=med, favtt=False)["fav_tt"] is None
    assert grade({"fav_tt": {"side": "home", "line": 73.5}}, -3.5, 70, 60, 143.5)["fav_tt"] == "W"
    assert grade({"fav_tt": {"side": "away", "line": 77.0}}, 4.0, 70, 77, 150.0)["fav_tt"] == "P"
    assert grade({"fav_tt": None}, 4.0, 70, 77, 150.0)["fav_tt"] is None
    store["games"]["bp"] = {"event_id": "bp", "commence_time": "2026-11-24T23:00Z", "completed": False,
                            "home": {"id": "B"}, "away": {"id": "P"}}
    assert for_game(store, "B", "P", "2026-11-24T23:00Z", -3.5, False, total=143.5, conf=False)["fav_tt"] is None, \
        "before FAVTT went live"
    assert for_game(store, "B", "P", "2026-11-27T00:00Z", -3.5, False, total=143.5, conf=False)["fav_tt"]
    # for_game: forms as of the start; no leak from the game itself.
    store["games"]["late"] = g("late", 20, "B", "D", 90, 60, bx(5, 10, 33, 60, 9, 22), bx(4, 15, 20, 60, 5, 20))
    q = for_game(store, "B", "D", "2026-11-20T23:00Z", -12.0, False, total=150.0, conf=True)
    assert q["side"] == "away" and not q["under"]
    assert team_forms(store, _ts("2026-11-20T23:00Z"))["B"]["n"] == 3, "its own result is not in"
    # Grading both kinds.
    assert grade({"side": "away", "under": True}, -12.0, 80, 70, 155.0) == {"spread": "W", "total": "W", "fav_tt": None}
    assert grade({"side": "home", "under": False}, 12.0, 60, 75, 140.0) == {"spread": "L", "total": None, "fav_tt": None}
    assert grade({"side": None, "under": True}, -3.0, 80, 70, 150.0) == {"spread": None, "total": "P", "fav_tt": None}
    print("ncaab_rules self-test: all invariants hold")


if __name__ == "__main__":
    _self_test()
